<?php

namespace App\Libraries;

use CodeIgniter\Encryption\Exceptions\EncryptionException;
use Config\Services;

/**
 * Enkripsi level-field (SEC-006).
 *
 * Dipakai untuk kolom sensitif identitas: `pasien.nik`, `pasien.suami_nik`
 * sesuai PRD (data terenkripsi saat disimpan — at-rest encryption).
 *
 * Format nilai tersimpan: 'ENC1$' . <hasil CI4 Encryption (base64+HMAC)>
 * Nilai legacy (tanpa penanda) dianggap plaintext dan tidak di-decrypt,
 * sehingga data lama tetap terbaca tanpa migrasi massal.
 */
class FieldEncryption
{
    public const PREFIX = 'ENC1$';

    /**
     * Enkripsi nilai untuk disimpan ke kolom.
     */
    public function encryptValue(?string $plain): ?string
    {
        if ($plain === null || $plain === '') {
            return $plain;
        }

        if ($this->isEncrypted($plain)) {
            return $plain;
        }

        try {
            $cipher = Services::encrypter()->encrypt($plain);
        } catch (EncryptionException $e) {
            log_message('error', 'FieldEncryption gagal mengenkripsi: ' . $e->getMessage());

            return $plain;
        }

        return $cipher === false ? $plain : self::PREFIX . $cipher;
    }

    /**
     * Dekripsi nilai hasil penyimpanan.
     * Bila bukan format terenkripsi (data legacy) → dikembalikan apa adanya.
     */
    public function decryptValue(?string $value): ?string
    {
        if ($value === null || $value === '') {
            return $value;
        }

        if (! $this->isEncrypted($value)) {
            return $value;
        }

        try {
            $plain = Services::encrypter()->decrypt(substr($value, strlen(self::PREFIX)));
        } catch (EncryptionException $e) {
            log_message('error', 'FieldEncryption gagal mendekripsi: ' . $e->getMessage());

            return null;
        }

        return $plain === false ? null : $plain;
    }

    public function isEncrypted(string $value): bool
    {
        return str_starts_with($value, self::PREFIX);
    }
}
