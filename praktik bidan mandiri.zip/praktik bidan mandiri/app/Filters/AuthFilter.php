<?php

namespace App\Filters;

use CodeIgniter\Filters\FilterInterface;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;

/**
 * Filter autentikasi global: semua halaman wajib login
 * kecuali yang dikecualikan pada config/Filters.php ($filters['auth']).
 *
 * Memenuhi FR-001 & SEC-010 (least privilege).
 */
class AuthFilter implements FilterInterface
{
    public function before(RequestInterface $request, $arguments = null)
    {
        if (! is_logged_in()) {
            set_flash('danger', 'Sesi Anda telah berakhir. Silakan login terlebih dahulu.');

            return redirect()->to(site_url('login'));
        }

        return null;
    }

    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
    {
        // Tidak ada aksi setelah request.
    }
}
