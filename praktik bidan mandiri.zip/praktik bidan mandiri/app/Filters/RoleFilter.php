<?php

namespace App\Filters;

use CodeIgniter\Filters\FilterInterface;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;

/**
 * Filter otorisasi berbasis peran (RBAC), dipakai per-route:
 *
 *   $routes->get('master/users', 'Master::users')->middleware('role:admin,bidan_pj');
 *
 * Memenuhi FR-004 (RBAC) & SEC-010 (least privilege).
 */
class RoleFilter implements FilterInterface
{
    public function before(RequestInterface $request, $arguments = null)
    {
        if (! is_logged_in()) {
            return redirect()->to(site_url('login'));
        }

        if (empty($arguments)) {
            return null;
        }

        if (! in_array(get_role(), $arguments, true)) {
            set_flash('danger', 'Akses ditolak. Halaman ini hanya untuk peran: ' . implode(', ', $arguments) . '.');

            return redirect()->to(site_url('dashboard'));
        }

        return null;
    }

    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
    {
        // Tidak ada aksi setelah request.
    }
}
