<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 *
 * Skema URL aplikasi RME Praktik Mandiri Bidan (PMB)
 * --------------------------------------------------
 * Halaman publik  : / (redirect), /login
 * Area terproteksi: di dalam group dengan filter 'auth'
 *   /dashboard            Dashboard KPI PMB
 *   /pendaftaran...       Modul pendaftaran & data pasien
 *   /anc...               Modul antenatal (10T + skrining risti)
 *   /persalinan...        Modul persalinan & partograf      (Tahap 2)
 *   /nifas...             Modul nifas & neonatal            (Tahap 2)
 *   /kb...                Modul KB                          (Tahap 2)
 *   /imunisasi...         Modul imunisasi & pertumbuhan     (Tahap 2)
 *   /pelayanan...         Pelayanan umum / RME SOAP
 *   /laporan...           Laporan & register kohort
 *   /master...            Master data (RBAC: admin/bidan_pj)
 *   /rm...                Manajemen rekam medis             (Tahap 3)
 *   /kasir...             Billing & kasir                   (Tahap 3)
 *   /rujukan...           Modul rujukan                     (Tahap 4)
 */

// --------------------------------------------------------------------
// Halaman publik
// --------------------------------------------------------------------
$routes->get('/', 'Home::index');
$routes->get('login', 'Auth::login');
$routes->post('login', 'Auth::doLogin');

// --------------------------------------------------------------------
// Area terproteksi (wajib login)
// --------------------------------------------------------------------
$routes->group('/', ['filter' => 'auth'], static function ($routes): void {
    // Sesi & pengguna
    $routes->get('logout', 'Auth::logout');
    $routes->get('switch-role', 'Auth::switchRole');

    // Dashboard
    $routes->get('dashboard', 'Dashboard::index');

    // ============================================================
    // TAHAP 1 (Fase 1 PRD) - route modul dipindahkan bertahap:
    //   /pendaftaran, /anc, /pelayanan, /laporan, /master, /audit
    // ---------------------------------------------------------
    // Pendaftaran & data pasien
    $routes->get('pendaftaran', 'Pendaftaran::index');
    $routes->post('pendaftaran', 'Pendaftaran::simpan');
    $routes->get('pendaftaran/tambah', 'Pendaftaran::tambah');
    $routes->get('pendaftaran/antrean', 'Pendaftaran::antrean');
    $routes->post('pendaftaran/antrean', 'Pendaftaran::simpanAntrean');
    $routes->get('pendaftaran/edit/(:num)', 'Pendaftaran::edit/$1');
    $routes->post('pendaftaran/update', 'Pendaftaran::update');
    $routes->get('pendaftaran/kartu/(:num)', 'Pendaftaran::kartu/$1');
    $routes->get('pendaftaran/karcis/(:num)', 'Pendaftaran::karcis/$1');
    // ============================================================

    // Penangkap modul yang belum dimigrasikan (tampil sebagai
    // "sedang dalam migrasi" alih-alih 404).
    $routes->get('(:segment)', 'Home::underConstruction/$1');
    $routes->get('(:segment)/(:segment)', 'Home::underConstruction/$1/$2');
    $routes->get('(:segment)/(:segment)/(:segment)', 'Home::underConstruction/$1/$2/$3');
});
