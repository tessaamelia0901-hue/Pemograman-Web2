<?php

namespace App\Models;

use CodeIgniter\Model;

/**
 * Model tabel `anc_kunjungan` — pemeriksaan ANC 10T & Poedji Rochjati.
 */
class AncModel extends Model
{
    protected $table            = 'anc_kunjungan';
    protected $primaryKey       = 'id';
    protected $returnType       = 'array';
    protected $useAutoIncrement = true;
    protected $useTimestamps    = false;
    protected $allowedFields    = [
        'kehamilan_id', 'pasien_id', 'kunjungan_id', 'tgl_periksa',
        'kunjungan_ke', 'trimester', 'usia_kehamilan', 'bb', 'tb', 'imt',
        'status_gizi', 'tekanan_darah', 'nadi', 'suhu', 'pernapasan', 'lila',
        'status_kek', 'tfu', 'djj', 'letak_janin', 'penurunan_kepala',
        'status_tt', 'diberi_tt', 'pemberian_fe', 'hb', 'protein_urin',
        'glukosa_urin', 'gol_darah', 'hiv', 'sifilis', 'hbsag',
        'tata_laksana', 'terapi_obat', 'konseling', 'skor_kunjungan',
        'kategori_risiko', 'faktor_risiko_tercatat', 'tanda_bahaya', 'keluhan',
        'diagnosa_kebidanan', 'tindak_lanjut', 'tgl_kembali',
        'bidan_pemeriksa', 'user_id',
    ];

    protected $validationRules = [
        'kehamilan_id'        => 'required|integer|exists[kehamilan.id]',
        'pasien_id'           => 'required|integer|exists[pasien.id]',
        'tgl_periksa'         => 'required|valid_date',
        'kunjungan_ke'        => 'required|max_length[20]',
        'trimester'           => 'required|in_list[1,2,3]',
        'usia_kehamilan'      => 'required|integer|greater_than_equal[0]',
        'diagnosa_kebidanan'  => 'required',
        'bidan_pemeriksa'     => 'required|max_length[100]',
        'kategori_risiko'     => 'required|in_list[KRR,KRT,KRST]',
        'tindak_lanjut'       => 'in_list[Kontrol Rutin PMB,Konsultasi Dokter SpOG,Rujuk RS PONEK,Pemantauan Khusus]',
    ];

    /** Riwayat ANC satu kehamilan, terbaru di atas. */
    public function riwayat(int $kehamilanId): array
    {
        return $this->where('kehamilan_id', $kehamilanId)
            ->orderBy('tgl_periksa', 'DESC')
            ->orderBy('id', 'DESC')
            ->findAll();
    }

    /** Kunjungan ANC terakhir untuk kehamilan. */
    public function terakhir(int $kehamilanId): ?array
    {
        return $this->where('kehamilan_id', $kehamilanId)
            ->orderBy('tgl_periksa', 'DESC')
            ->orderBy('id', 'DESC')
            ->first();
    }

    /** Label kunjungan berikutnya (K1, K2, ...). */
    public function nextKunjunganLabel(int $kehamilanId): string
    {
        $jml = $this->where('kehamilan_id', $kehamilanId)->countAllResults();

        return 'K' . ($jml + 1);
    }

    /**
     * IMT dari BB (kg) & TB (cm) — 1 desimal.
     */
    public static function hitungImt(float $bb, float $tbCm): float
    {
        if ($tbCm <= 0) {
            return 0.0;
        }

        $m = $tbCm / 100;

        return round($bb / ($m * $m), 2);
    }
}
