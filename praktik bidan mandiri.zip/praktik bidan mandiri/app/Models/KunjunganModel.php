<?php

namespace App\Models;

use CodeIgniter\Model;

/**
 * Model tabel `kunjungan` — pendaftaran & antrean pelayanan (FR-013/FR-015).
 */
class KunjunganModel extends Model
{
    protected $table            = 'kunjungan';
    protected $primaryKey       = 'id';
    protected $returnType       = 'array';
    protected $useAutoIncrement = true;
    protected $useTimestamps    = false;
    protected $allowedFields    = [
        'no_registrasi', 'pasien_id', 'poli_id', 'dokter_id', 'tgl_kunjungan',
        'no_antrean', 'jenis_kunjungan', 'cara_bayar', 'keluhan_awal',
        'status_pelayanan', 'user_id',
    ];

    protected $validationRules = [
        'no_registrasi'   => 'required|max_length[30]|is_unique[kunjungan.no_registrasi,id,{id}]',
        'pasien_id'       => 'required|integer|exists[pasien.id]',
        'poli_id'         => 'required|integer|exists[poli.id]',
        'dokter_id'       => 'required|integer|exists[dokter.id]',
        'tgl_kunjungan'   => 'required|valid_date',
        'no_antrean'      => 'required|max_length[20]',
        'jenis_kunjungan' => 'required|in_list[Baru,Lama]',
        'cara_bayar'      => 'required|in_list[Umum,BPJS,Asuransi Lain]',
        'status_pelayanan' => 'in_list[Menunggu,Sedang Dilayani,Selesai,Batal]',
    ];

    /**
     * Daftar hari ini dengan data pasien/poli/bidan (untuk antrean & pelayanan).
     *
     * @return array<int, array<string, mixed>>
     */
    public function daftarHariIni(?string $tgl = null, ?string $status = null): array
    {
        $tgl = $tgl ?? date('Y-m-d');

        $builder = $this->select('kunjungan.*, pasien.no_rm, pasien.nama_pasien, pasien.jenis_kelamin,
                                  pasien.tanggal_lahir, pasien.no_hp, poli.kode_poli, poli.nama_poli,
                                  dokter.nama_dokter, dokter.sip')
            ->join('pasien', 'pasien.id = kunjungan.pasien_id', 'left')
            ->join('poli', 'poli.id = kunjungan.poli_id', 'left')
            ->join('dokter', 'dokter.id = kunjungan.dokter_id', 'left')
            ->where('kunjungan.tgl_kunjungan', $tgl)
            ->orderBy('kunjungan.no_antrean', 'ASC');

        if ($status !== null) {
            $builder->where('kunjungan.status_pelayanan', $status);
        }

        return $builder->findAll();
    }

    /** Pendaftaran hari ini (semua status) — untuk KPI dashboard. */
    public function hitungHariIni(?string $tgl = null): array
    {
        $tgl = $tgl ?? date('Y-m-d');

        return $this->select('status_pelayanan, COUNT(*) as jml', false)
            ->where('tgl_kunjungan', $tgl)
            ->groupBy('status_pelayanan')
            ->findAll();
    }

    /** Nomor registrasi berikutnya: REG-YYYYMMDD-001. */
    public function nextNoRegistrasi(?string $tgl = null): string
    {
        $tgl    = $tgl ?? date('Y-m-d');
        $prefix = 'REG-' . date('Ymd', strtotime($tgl));

        $last = $this->select('no_registrasi')
            ->like('no_registrasi', $prefix, 'after')
            ->orderBy('no_registrasi', 'DESC')
            ->first();

        $n = 1;
        if ($last !== null && preg_match('/-(\d+)$/', $last['no_registrasi'], $m)) {
            $n = ((int) $m[1]) + 1;
        }

        return $prefix . '-' . sprintf('%03d', $n);
    }

    /**
     * Nomor antrean berikutnya per unit layanan per hari (A-001, N-001, ...).
     */
    public function nextNoAntrean(string $tgl, int $poliId): string
    {
        $poli = (new PoliModel())->find($poliId);
        $kode = $poli['kode_poli'] ?? 'POL-01';

        // Huruf antrean per unit layanan (konsisten dengan data legacy A..E).
        $hurufMap = [
            'POL-01' => 'A', 'POL-02' => 'B', 'POL-03' => 'C',
            'POL-04' => 'D', 'POL-05' => 'E',
            'POL-ANC' => 'N', 'POL-INC' => 'L', 'POL-PNC' => 'F',
            'POL-KB' => 'K', 'POL-IMU' => 'I',
        ];
        $huruf = $hurufMap[$kode] ?? 'A';

        $prefix  = $huruf . '-';
        $jml = $this->where('tgl_kunjungan', $tgl)
            ->where('poli_id', $poliId)
            ->countAllResults();

        return $prefix . sprintf('%03d', $jml + 1);
    }

    /** Apakah pasien sudah terdaftar pada hari/tanggal itu (cegah dobel). */
    public function sudahTerdaftar(int $pasienId, string $tgl, int $poliId): bool
    {
        return $this->where([
                'pasien_id'     => $pasienId,
                'tgl_kunjungan' => $tgl,
                'poli_id'       => $poliId,
            ])->countAllResults() > 0;
    }
}
