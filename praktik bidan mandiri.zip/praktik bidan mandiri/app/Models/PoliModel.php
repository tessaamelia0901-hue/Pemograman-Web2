<?php

namespace App\Models;

use CodeIgniter\Model;

/** Model tabel `poli` — unit layanan PMB. */
class PoliModel extends Model
{
    protected $table            = 'poli';
    protected $primaryKey       = 'id';
    protected $returnType       = 'array';
    protected $useAutoIncrement = true;
    protected $useTimestamps    = false;
    protected $allowedFields    = ['kode_poli', 'nama_poli', 'keterangan', 'status'];

    protected $validationRules = [
        'kode_poli' => 'required|max_length[20]|is_unique[poli.kode_poli,id,{id}]',
        'nama_poli' => 'required|max_length[100]',
    ];
}
