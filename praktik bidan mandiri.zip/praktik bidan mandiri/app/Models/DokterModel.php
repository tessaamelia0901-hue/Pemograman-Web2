<?php

namespace App\Models;

use CodeIgniter\Model;

/** Model tabel `dokter` — bidan & tenaga kesehatan. */
class DokterModel extends Model
{
    protected $table            = 'dokter';
    protected $primaryKey       = 'id';
    protected $returnType       = 'array';
    protected $useAutoIncrement = true;
    protected $useTimestamps    = false;
    protected $allowedFields    = ['sip', 'nama_dokter', 'poli_id', 'no_hp', 'status'];

    protected $validationRules = [
        'sip'         => 'required|max_length[50]|is_unique[dokter.sip,id,{id}]',
        'nama_dokter' => 'required|max_length[100]',
        'poli_id'     => 'required|integer|exists[poli.id]',
    ];

    /** Daftar bidan/nakes + nama unit layanannya. */
    public function daftarDenganPoli(): array
    {
        return $this->select('dokter.*, poli.nama_poli')
            ->join('poli', 'poli.id = dokter.poli_id', 'left')
            ->orderBy('dokter.nama_dokter', 'ASC')
            ->findAll();
    }
}
