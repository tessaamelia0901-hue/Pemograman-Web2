<?php

namespace App\Models;

use CodeIgniter\Model;

/** Model tabel `master_icd10` (FR-00A). */
class Icd10Model extends Model
{
    protected $table            = 'master_icd10';
    protected $primaryKey       = 'id';
    protected $returnType       = 'array';
    protected $useAutoIncrement = true;
    protected $useTimestamps    = false;
    protected $allowedFields    = ['kode', 'nama_penyakit', 'nama_latin'];

    protected $validationRules = [
        'kode'         => 'required|max_length[10]|is_unique[master_icd10.kode,id,{id}]',
        'nama_penyakit' => 'required|max_length[255]',
    ];

    /** Cari diagnosis — prioritaskan kecocokan awalan kode. */
    public function cari(string $kata): array
    {
        $kata = trim($kata);
        if ($kata === '') {
            return [];
        }

        return $this->groupStart()
                ->like('kode', $kata, 'after')
                ->orLike('nama_penyakit', $kata, 'both')
            ->groupEnd()
            ->orderBy('kode', 'ASC')
            ->limit(30)
            ->findAll();
    }
}
