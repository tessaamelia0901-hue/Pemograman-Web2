<?php

namespace App\Models;

use CodeIgniter\Model;

/** Model tabel `master_obat` (FR-072). */
class ObatModel extends Model
{
    protected $table            = 'master_obat';
    protected $primaryKey       = 'id';
    protected $returnType       = 'array';
    protected $useAutoIncrement = true;
    protected $useTimestamps    = false;
    protected $allowedFields    = ['kode_obat', 'nama_obat', 'satuan', 'sediaan', 'stok', 'harga'];

    protected $validationRules = [
        'kode_obat' => 'required|max_length[20]|is_unique[master_obat.kode_obat,id,{id}]',
        'nama_obat' => 'required|max_length[150]',
        'stok'      => 'integer',
        'harga'     => 'decimal',
    ];
}
