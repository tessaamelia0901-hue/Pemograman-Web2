<?php

namespace App\Models;

use CodeIgniter\Model;

/**
 * Model tabel `users`.
 */
class UserModel extends Model
{
    protected $table            = 'users';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = false;
    protected $useTimestamps    = false;

    protected $allowedFields = [
        'username', 'password', 'nama_lengkap', 'role',
        'no_sipb', 'no_str', 'status', 'last_login',
        'gagal_login', 'locked_until',
    ];

    protected $validationRules = [
        'username'     => 'required|min_length[3]|max_length[50]|is_unique[users.username,id,{id}]',
        'password'     => 'required|min_length[6]',
        'nama_lengkap' => 'required|max_length[100]',
        'role'         => 'required',
    ];

    /**
     * Cari user aktif berdasarkan username (untuk proses login).
     *
     * @return array<string, mixed>|null
     */
    public function findByUsernameAktif(string $username): ?array
    {
        return $this->where([
            'username' => $username,
            'status'   => 'aktif',
        ])->first();
    }

    /**
     * Ambil satu user aktif tertentu berdasar peran (untuk demo switch role).
     *
     * @return array<string, mixed>|null
     */
    public function findFirstByRole(string $role): ?array
    {
        return $this->where([
            'role'   => $role,
            'status' => 'aktif',
        ])->first();
    }
}
