<?php

namespace App\Models;

use CodeIgniter\Model;

/** Model tabel `pengaturan` — profil praktik (FR-009). */
class PengaturanModel extends Model
{
    protected $table            = 'pengaturan';
    protected $primaryKey       = 'id';
    protected $returnType       = 'array';
    protected $useAutoIncrement = true;
    protected $useTimestamps    = false;
    protected $allowedFields    = [
        'nama_instansi', 'alamat_instansi', 'telepon', 'email',
        'pimpinan_nama', 'pimpinan_nip', 'pmik_nama', 'pmik_nip',
    ];

    protected $validationRules = [
        'nama_instansi' => 'required|max_length[150]',
        'telepon'       => 'required|max_length[30]',
    ];

    /** Profil PMB (baris pertama — tabel ini satu-baris untuk aplikasi ini). */
    public function profil(): ?array
    {
        return $this->first();
    }
}
