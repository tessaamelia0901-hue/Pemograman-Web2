<?php

namespace App\Models;

use CodeIgniter\Model;

/**
 * Model tabel `kehamilan` — registrasi kehamilan (FR-020 s.d. FR-024).
 */
class KehamilanModel extends Model
{
    protected $table            = 'kehamilan';
    protected $primaryKey       = 'id';
    protected $returnType       = 'array';
    protected $useAutoIncrement = true;
    protected $useTimestamps    = true;
    protected $allowedFields    = [
        'pasien_id', 'hpht', 'hpl', 'gpa_gravida', 'gpa_para', 'gpa_abortus',
        'jarak_kehamilan', 'status_kehamilan', 'skor_risiko_awal',
        'kategori_risiko', 'faktor_risiko', 'status_buku_kia', 'catatan_khusus',
    ];

    protected $validationRules = [
        'pasien_id'        => 'required|integer|exists[pasien.id]',
        'hpht'             => 'required|valid_date',
        'hpl'              => 'required|valid_date',
        'gpa_gravida'      => 'required|integer|greater_than[0]',
        'gpa_para'         => 'required|integer|greater_than_equal[0]',
        'gpa_abortus'      => 'required|integer|greater_than_equal[0]',
        'status_kehamilan' => 'in_list[Aktif,Melahirkan,Abortus]',
        'kategori_risiko'  => 'in_list[KRR,KRT,KRST]',
    ];

    /** Kehamilan aktif beserta data pasien & jumlah kunjungan ANC. */
    public function daftarAktif(?string $kata = null): array
    {
        $builder = $this->select('kehamilan.*, pasien.no_rm, pasien.nama_pasien, pasien.tanggal_lahir,
                                  pasien.no_hp, pasien.alamat')
            ->join('pasien', 'pasien.id = kehamilan.pasien_id', 'left')
            ->where('kehamilan.status_kehamilan', 'Aktif');

        if ($kata !== null && trim($kata) !== '') {
            $kata = trim($kata);
            $builder->groupStart()
                ->like('pasien.no_rm', $kata)
                ->orLike('pasien.nama_pasien', $kata)
                ->groupEnd();
        }

        return $builder->orderBy('kehamilan.hpl', 'ASC')->findAll();
    }

    /** Apakah pasien sedang hamil aktif (cegah kehamilan ganda). */
    public function sedangHamil(int $pasienId): bool
    {
        return $this->where([
                'pasien_id'        => $pasienId,
                'status_kehamilan' => 'Aktif',
            ])->countAllResults() > 0;
    }

    /**
     * Usia kehamilan hari ini berdasarkan HPHT (hari).
     */
    public function usiaHari(?string $hpht = null): int
    {
        $hpht = $hpht ?? ($this->first()['hpht'] ?? null);
        if ($hpht === null) {
            return 0;
        }

        return (int) ((time() - strtotime($hpht)) / 86400);
    }
}
