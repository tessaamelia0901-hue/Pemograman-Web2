<?php

namespace App\Models;

use App\Libraries\FieldEncryption;
use CodeIgniter\Model;

/**
 * Model tabel `pasien`.
 *
 * Enkripsi field-level (SEC-006): `nik` & `suami_nik` disimpan terenkripsi
 * (penanda ENC1$). Nilai legacy tanpa penanda dibiarkan apa adanya agar
 * data lama tetap terbaca tanpa migrasi massal.
 */
class PasienModel extends Model
{
    protected $table            = 'pasien';
    protected $primaryKey       = 'id';
    protected $returnType       = 'array';
    protected $useAutoIncrement = true;
    protected $useTimestamps    = false;
    protected $allowedFields    = [
        'no_rm', 'nik', 'no_bpjs', 'nama_pasien', 'jenis_kelamin',
        'tempat_lahir', 'tanggal_lahir', 'golongan_darah', 'rhesus',
        'alamat', 'no_hp', 'agama', 'pendidikan', 'pekerjaan',
        'status_perkawinan', 'penanggung_jawab',
        'suami_nama', 'suami_nik', 'suami_pekerjaan', 'hubungan_pj',
    ];

    protected $validationRules = [
        'no_rm'            => 'required|max_length[20]|is_unique[pasien.no_rm,id,{id}]',
        'nik'              => 'required|exact_length[16]|regex_match[/^[0-9]+$/]',
        'nama_pasien'      => 'required|max_length[100]',
        'jenis_kelamin'    => 'required|in_list[L,P]',
        'tempat_lahir'     => 'required|max_length[50]',
        'tanggal_lahir'    => 'required|valid_date',
        'alamat'           => 'required',
        'no_hp'            => 'required|max_length[20]',
        'golongan_darah'   => 'in_list[A,B,AB,O,-]',
        'status_perkawinan' => 'permit_empty|in_list[Menikah,Belum Menikah,Janda]',
        'suami_nik'        => 'permit_empty|exact_length[16]|regex_match[/^[0-9]+$/]',
    ];

    protected $beforeInsert = ['encodeNiks'];
    protected $beforeUpdate = ['encodeNiks'];
    protected $afterFind    = ['decodeNiks'];

    // ------------------------------------------------------------------
    // Enkripsi / dekripsi field sensitif
    // ------------------------------------------------------------------

    /**
     * @param array<string, mixed> $eventData
     *
     * @return array<string, mixed>
     */
    protected function encodeNiks(array $eventData): array
    {
        $data = $eventData['data'] ?? [];

        if (is_array($data)) {
            $crypto = new FieldEncryption();

            foreach (['nik', 'suami_nik'] as $field) {
                if (array_key_exists($field, $data)) {
                    $data[$field] = $crypto->encryptValue($data[$field]);
                }
            }

            $eventData['data'] = $data;
        }

        return $eventData;
    }

    /**
     * @param array<string, mixed> $eventData
     *
     * @return array<string, mixed>
     */
    protected function decodeNiks(array $eventData): array
    {
        $rows = $eventData['data'] ?? null;

        if ($rows === null || $rows === []) {
            return $eventData;
        }

        $crypto = new FieldEncryption();

        if (($eventData['singleton'] ?? false) === true) {
            $eventData['data'] = is_array($rows) ? $this->decodeRow($rows, $crypto) : $rows;

            return $eventData;
        }

        if (is_array($rows)) {
            foreach ($rows as $key => $row) {
                if (is_array($row)) {
                    $rows[$key] = $this->decodeRow($row, $crypto);
                }
            }

            $eventData['data'] = $rows;
        }

        return $eventData;
    }

    /**
     * @param array<string, mixed> $row
     *
     * @return array<string, mixed>
     */
    private function decodeRow(array $row, FieldEncryption $crypto): array
    {
        foreach (['nik', 'suami_nik'] as $field) {
            if (isset($row[$field]) && is_string($row[$field])) {
                $row[$field] = $crypto->decryptValue($row[$field]);
            }
        }

        return $row;
    }

    // ------------------------------------------------------------------
    // Pencarian
    // ------------------------------------------------------------------

    /**
     * Pencarian data pasien (no_rm, nama, no_hp; NIK dicocokkan di memori
     * karena nilai tersimpan terenkripsi — skala praktik kecil, aman).
     */
    public function cari(?string $kata): array
    {
        if ($kata === null || trim($kata) === '') {
            return $this->orderBy('id', 'DESC')->findAll();
        }

        $kata = trim($kata);

        $hasil = $this->groupStart()
                ->like('no_rm', $kata, 'both')
                ->orLike('nama_pasien', $kata, 'both')
                ->orLike('no_hp', $kata, 'both')
                ->orLike('no_bpjs', $kata, 'both')
            ->groupEnd()
            ->orderBy('id', 'DESC')
            ->findAll();

        // Pencocokan NIK (plaintext maupun terenkripsi) dilakukan di memori.
        if (preg_match('/^\d{6,}$/', $kata)) {
            $semua = $this->orderBy('id', 'DESC')->findAll();
            foreach ($semua as $p) {
                if (($p['nik'] ?? '') === $kata) {
                    array_unshift($hasil, $p);
                }
            }
            $hasil = array_values(array_unique($hasil, SORT_REGULAR));
        }

        return $hasil;
    }

    /** Nomor RM berikutnya (format RM-000001). */
    public function nextNoRm(): string
    {
        $last = $this->select('no_rm')
            ->where('no_rm LIKE', 'RM-%')
            ->orderBy('no_rm', 'DESC')
            ->first();

        $n = 1;
        if ($last !== null && preg_match('/^RM-(\d+)$/', $last['no_rm'], $m)) {
            $n = ((int) $m[1]) + 1;
        }

        return sprintf('RM-%06d', $n);
    }

    /**
     * Cek duplikasi NIK (data lama plaintext maupun baru terenkripsi)
     * — pembandingan dilakukan di memori karena nilai terenkripsi tidak
     * dapat dicocokkan lewat SQL.
     */
    public function nikTerdaftar(string $nik, ?int $exceptId = null): bool
    {
        $nik = trim($nik);
        if ($nik === '') {
            return false;
        }

        foreach ($this->findAll() as $row) {
            if ($exceptId !== null && (int) $row['id'] === $exceptId) {
                continue;
            }

            if (($row['nik'] ?? '') === $nik) {
                return true;
            }
        }

        return false;
    }

    /**
     * Cek duplikasi No. RM (kolom tidak dienkripsi — SQL biasa).
     */
    public function noRmTerdaftar(string $noRm, ?int $exceptId = null): bool
    {
        $builder = $this->where('no_rm', $noRm);
        if ($exceptId !== null) {
            $builder->where('id !=', $exceptId);
        }

        return $builder->countAllResults() > 0;
    }
}
