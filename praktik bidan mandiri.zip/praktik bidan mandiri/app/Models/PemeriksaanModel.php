<?php

namespace App\Models;

use CodeIgniter\Model;

/**
 * Model tabel `pemeriksaan` — RME SOAP (FR-070 s.d. FR-076).
 */
class PemeriksaanModel extends Model
{
    protected $table            = 'pemeriksaan';
    protected $primaryKey       = 'id';
    protected $returnType       = 'array';
    protected $useAutoIncrement = true;
    protected $useTimestamps    = false;
    protected $allowedFields    = [
        'kunjungan_id', 'tgl_pemeriksaan', 'keluhan_utama',
        'riwayat_penyakit_sekarang', 'riwayat_penyakit_dahulu', 'riwayat_alergi',
        'tekanan_darah', 'nadi', 'suhu', 'pernapasan', 'berat_badan',
        'tinggi_badan', 'imt', 'status_gizi', 'pemeriksaan_fisik',
        'diagnosa_utama_id', 'diagnosa_sekunder_id', 'edukasi',
        'tindak_lanjut', 'dokter_id', 'user_id',
    ];

    protected $validationRules = [
        'kunjungan_id'      => 'required|integer|is_unique[pemeriksaan.kunjungan_id,id,{id}]',
        'keluhan_utama'     => 'required',
        'tekanan_darah'     => 'required|max_length[20]',
        'nadi'              => 'required|integer|greater_than[0]',
        'suhu'              => 'required|decimal',
        'diagnosa_utama_id' => 'required|integer|exists[master_icd10.id]',
        'dokter_id'         => 'required|integer|exists[dokter.id]',
        'tindak_lanjut'     => 'in_list[Pulang/Sembuh,Kontrol Kembali,Rujuk RS,Rawat Inap]',
    ];

    /** Pemeriksaan sebuah kunjungan + data pendukung. */
    public function dariKunjungan(int $kunjunganId): ?array
    {
        return $this->select('pemeriksaan.*, diag.nama_penyakit as diagnosa_utama,
                              diag.kode as kode_diagnosa_utama,
                              diag2.nama_penyakit as diagnosa_sekunder,
                              dokter.nama_dokter')
            ->join('master_icd10 diag', 'diag.id = pemeriksaan.diagnosa_utama_id', 'left')
            ->join('master_icd10 diag2', 'diag2.id = pemeriksaan.diagnosa_sekunder_id', 'left')
            ->join('dokter', 'dokter.id = pemeriksaan.dokter_id', 'left')
            ->where('pemeriksaan.kunjungan_id', $kunjunganId)
            ->first();
    }

    /** Apakah kunjungan sudah memiliki catatan SOAP. */
    public function sudahDiperiksa(int $kunjunganId): bool
    {
        return $this->where('kunjungan_id', $kunjunganId)->countAllResults() > 0;
    }

    /**
     * Status gizi berdasarkan IMT (kategori dewasa — WHO).
     */
    public static function statusGizi(float $imt): string
    {
        return match (true) {
            $imt < 18.5       => 'Kurus',
            $imt < 25.0       => 'Normal',
            $imt < 30.0       => 'Gemuk',
            default           => 'Obesitas',
        };
    }
}
