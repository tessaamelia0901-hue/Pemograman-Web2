<?php

namespace App\Models;

use CodeIgniter\Model;

/** Model tabel `audit_log` (FR-100). */
class AuditLogModel extends Model
{
    protected $table            = 'audit_log';
    protected $primaryKey       = 'id';
    protected $returnType       = 'array';
    protected $useAutoIncrement = true;
    protected $useTimestamps    = false;
    protected $allowedFields    = [
        'user_id', 'username', 'role', 'module', 'action', 'table_name',
        'record_id', 'description', 'old_values', 'new_values',
        'ip_address', 'user_agent', 'created_at',
    ];

    /**
     * Daftar log dengan filter opsional (modul, aksi, kata kunci).
     *
     * @return array{rows: array<int, array<string, mixed>>, total: int}
     */
    public function daftar(?string $module = null, ?string $action = null, ?string $kata = null, int $perPage = 25, int $page = 1): array
    {
        $builder = $this->select('*');

        if ($module !== null && $module !== '') {
            $builder->where('module', $module);
        }

        if ($action !== null && $action !== '') {
            $builder->where('action', $action);
        }

        if ($kata !== null && trim($kata) !== '') {
            $kata = trim($kata);
            $builder->groupStart()
                ->like('username', $kata)
                ->orLike('description', $kata)
                ->orLike('record_id', $kata)
                ->groupEnd();
        }

        $total = (clone $builder)->countAllResults(false);

        $rows = $builder->orderBy('id', 'DESC')
            ->limit($perPage, max(0, ($page - 1) * $perPage))
            ->findAll();

        return ['rows' => $rows, 'total' => $total];
    }
}
