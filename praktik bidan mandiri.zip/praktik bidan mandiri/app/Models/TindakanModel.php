<?php

namespace App\Models;

use CodeIgniter\Model;

/** Model tabel `master_tindakan` (FR-071). */
class TindakanModel extends Model
{
    protected $table            = 'master_tindakan';
    protected $primaryKey       = 'id';
    protected $returnType       = 'array';
    protected $useAutoIncrement = true;
    protected $useTimestamps    = false;
    protected $allowedFields    = ['kode_tindakan', 'nama_tindakan', 'kategori', 'tarif'];

    protected $validationRules = [
        'kode_tindakan' => 'required|max_length[20]|is_unique[master_tindakan.kode_tindakan,id,{id}]',
        'nama_tindakan' => 'required|max_length[150]',
        'tarif'         => 'decimal',
    ];
}
