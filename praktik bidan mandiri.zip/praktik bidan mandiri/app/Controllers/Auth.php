<?php

namespace App\Controllers;

use App\Models\UserModel;

/**
 * Autentikasi (FR-001 s.d. FR-008) — hasil porting AuthController legacy.
 */
class Auth extends BaseController
{
    /**
     * Halaman login (GET /login).
     */
    public function login()
    {
        if (is_logged_in()) {
            return redirect()->to(site_url('dashboard'));
        }

        return view('auth/login');
    }

    /**
     * Proses login (POST /login).
     */
    public function doLogin()
    {
        if (strtolower($this->request->getMethod()) !== 'post') {
            return redirect()->to(site_url('login'));
        }

        $username = trim((string) $this->request->getPost('username'));
        $password = (string) $this->request->getPost('password');

        if ($username === '' || $password === '') {
            set_flash('danger', 'Username dan password wajib diisi.');

            return redirect()->to(site_url('login'));
        }

        $user = (new UserModel())->findByUsernameAktif($username);

        if ($user !== null && password_verify($password, $user['password'])) {
            // Regenerasi ID sesi mencegah session fixation (SEC-014).
            session()->regenerate(true);

            session()->set([
                'user_id'      => $user['id'],
                'username'     => $user['username'],
                'nama_lengkap' => $user['nama_lengkap'],
                'role'         => $user['role'],
            ]);

            (new UserModel())->update($user['id'], ['last_login' => date('Y-m-d H:i:s')]);

            set_flash('success', 'Selamat datang kembali, ' . clean($user['nama_lengkap']) . '!');

            return redirect()->to(site_url('dashboard'));
        }

        set_flash('danger', 'Username atau password yang Anda masukkan salah.');

        return redirect()->to(site_url('login'));
    }

    /**
     * Logout (GET /logout).
     */
    public function logout()
    {
        $session = session();
        $session->remove(['user_id', 'username', 'nama_lengkap', 'role']);
        $session->regenerate(true);

        set_flash('info', 'Anda telah berhasil logout dari sistem.');

        return redirect()->to(site_url('login'));
    }

    /**
     * Pergantian peran cepat untuk keperluan demo/uji (dokumentasikan di README).
     * GET /switch-role?role=bidan_pj
     */
    public function switchRole()
    {
        require_login();

        $targetRole = (string) $this->request->getGet('role');
        $allowed    = ['bidan_pj', 'bidan', 'asisten', 'admin', 'pmik'];

        if (! in_array($targetRole, $allowed, true)) {
            $targetRole = 'bidan_pj';
        }

        $user = (new UserModel())->findFirstByRole($targetRole);

        if ($user !== null) {
            session()->regenerate(true);
            session()->set([
                'user_id'      => $user['id'],
                'username'     => $user['username'],
                'nama_lengkap' => $user['nama_lengkap'],
                'role'         => $user['role'],
            ]);

            set_flash('success', 'Berhasil beralih mode sebagai: ' . strtoupper($targetRole) . ' (' . clean($user['nama_lengkap']) . ')');
        }

        return redirect()->to(site_url('dashboard'));
    }
}
