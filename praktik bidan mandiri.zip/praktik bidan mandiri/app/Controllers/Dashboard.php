<?php

namespace App\Controllers;

/**
 * Dashboard PMB (FR-120).
 * Tahap 0: ringkasan sementara; KPI lengkap diport pada Tahap 1.
 */
class Dashboard extends BaseController
{
    public function index()
    {
        require_role(['admin', 'bidan_pj', 'bidan', 'asisten', 'pmik']);

        return view('dashboard/index', [
            'pageTitle' => 'Dashboard PMB',
        ]);
    }
}
