<?php

namespace App\Controllers;

use App\Models\DokterModel;
use App\Models\KunjunganModel;
use App\Models\PasienModel;
use App\Models\PengaturanModel;
use App\Models\PoliModel;

/**
 * Pendaftaran — data pasien, pendaftaran antrean poli, kartu & karcis.
 * Porting dari controllers/PendaftaranController.php (legacy) ke CI4.
 *
 * FR-013 (pendaftaran), FR-014 (antrean), FR-015 (nomor urut),
 * plus pencatatan audit (FR-100).
 */
class Pendaftaran extends BaseController
{
    /**
     * Data pasien + pencarian (GET /pendaftaran?search=).
     */
    public function index()
    {
        $search = trim((string) $this->request->getGet('search'));

        $pasienList = (new PasienModel())->cari($search !== '' ? $search : null);
        $pasienList = array_slice($pasienList, 0, 100);

        return view('pendaftaran/index', [
            'pageTitle' => 'Data Pasien & Pendaftaran',
            'pasienList' => $pasienList,
            'search'    => $search,
        ]);
    }

    /**
     * Form pendaftaran pasien baru (GET /pendaftaran/tambah).
     */
    public function tambah()
    {
        $pasienModel = new PasienModel();

        return view('pendaftaran/tambah_pasien', [
            'pageTitle'  => 'Pendaftaran Pasien Baru',
            'autoNoRm'   => $pasienModel->nextNoRm(),
            'poliList'   => (new PoliModel())->where('status', 'aktif')->orderBy('nama_poli')->findAll(),
            'dokterList' => (new DokterModel())->where('status', 'aktif')->orderBy('nama_dokter')->findAll(),
        ]);
    }

    /**
     * Simpan pasien baru (POST /pendaftaran).
     */
    public function simpan()
    {
        if (strtolower($this->request->getMethod()) !== 'post') {
            return redirect()->to(site_url('pendaftaran'));
        }

        $pasienModel = new PasienModel();
        $data        = $this->pasienPayload();

        // Validasi kolom wajib (ringkas, gaya legacy).
        foreach (['no_rm', 'nik', 'nama_pasien', 'tanggal_lahir', 'alamat'] as $wajib) {
            if (($data[$wajib] ?? '') === '') {
                set_flash('danger', 'Harap isi semua kolom wajib (*).');

                return redirect()->to(site_url('pendaftaran/tambah'));
            }
        }

        if (strlen((string) $data['nik']) !== 16 || ! ctype_digit((string) $data['nik'])) {
            set_flash('danger', 'NIK harus terdiri dari 16 digit angka.');

            return redirect()->to(site_url('pendaftaran/tambah'));
        }

        if ($pasienModel->nikTerdaftar($data['nik']) || $pasienModel->noRmTerdaftar($data['no_rm'])) {
            set_flash('danger', 'NIK atau Nomor RM sudah terdaftar di sistem.');

            return redirect()->to(site_url('pendaftaran/tambah'));
        }

        $pasienId = $pasienModel->insert($data);
        if ($pasienId === false) {
            set_flash('danger', 'Gagal menyimpan data: ' . implode('; ', $pasienModel->errors()));

            return redirect()->to(site_url('pendaftaran/tambah'));
        }

        log_audit('pendaftaran', 'CREATE', 'pasien', $pasienId,
            'Tambah pasien baru ' . $data['nama_pasien'] . ' (' . $data['no_rm'] . ')',
            null, ['no_rm' => $data['no_rm'], 'nama_pasien' => $data['nama_pasien'], 'nik' => '***']);

        // Opsi langsung masuk antrean poli.
        if ((string) $this->request->getPost('langsung_antre') === '1') {
            $poliId   = (int) $this->request->getPost('poli_id');
            $dokterId = (int) $this->request->getPost('dokter_id');

            if ($poliId > 0 && $dokterId > 0) {
                $kunjunganId = $this->prosesDaftarkanAntrean(
                    $pasienId,
                    $poliId,
                    $dokterId,
                    (string) ($this->request->getPost('cara_bayar') ?: 'Umum'),
                    'Baru',
                    (string) $this->request->getPost('keluhan_awal'),
                );

                set_flash('success', 'Pasien baru berhasil didaftarkan dengan No. RM: ' . $data['no_rm']
                    . ' dan langsung masuk antrean unit layanan!');

                return redirect()->to(site_url('pendaftaran/karcis/' . $kunjunganId));
            }
        }

        set_flash('success', 'Pasien baru berhasil didaftarkan dengan No. RM: ' . $data['no_rm']);

        return redirect()->to(site_url('pendaftaran/kartu/' . $pasienId));
    }

    /**
     * Form edit pasien (GET /pendaftaran/edit/(:num)).
     */
    public function edit(?string $id = null)
    {
        $pasien = (new PasienModel())->find((int) $id);

        if ($pasien === null) {
            set_flash('danger', 'Data pasien tidak ditemukan.');

            return redirect()->to(site_url('pendaftaran'));
        }

        return view('pendaftaran/edit_pasien', [
            'pageTitle' => 'Edit Data Pasien - ' . $pasien['nama_pasien'],
            'pasien'    => $pasien,
        ]);
    }

    /**
     * Update data pasien (POST /pendaftaran/update).
     */
    public function update()
    {
        if (strtolower($this->request->getMethod()) !== 'post') {
            return redirect()->to(site_url('pendaftaran'));
        }

        $id       = (int) $this->request->getPost('id');
        $pasienModel = new PasienModel();
        $lama     = $pasienModel->find($id);

        if ($lama === null) {
            set_flash('danger', 'Data pasien tidak ditemukan.');

            return redirect()->to(site_url('pendaftaran'));
        }

        $data          = $this->pasienPayload();
        $data['nik']   = trim((string) $this->request->getPost('nik'));

        if (strlen($data['nik']) !== 16 || ! ctype_digit($data['nik'])) {
            set_flash('danger', 'NIK harus terdiri dari 16 digit angka.');

            return redirect()->to(site_url('pendaftaran/edit/' . $id));
        }

        if ($pasienModel->nikTerdaftar($data['nik'], $id)) {
            set_flash('danger', 'NIK sudah digunakan oleh pasien lain.');

            return redirect()->to(site_url('pendaftaran/edit/' . $id));
        }

        // no_rm tidak diubah pada form edit (identitas utama tetap).
        unset($data['no_rm']);

        $pasienModel->update($id, $data);

        $baru = $pasienModel->find($id);
        $selisih = audit_old_new(
            array_intersect_key($lama, $data),
            array_intersect_key($baru ?? [], $data)
        );

        log_audit('pendaftaran', 'UPDATE', 'pasien', $id,
            'Update data pasien ' . ($data['nama_pasien'] ?? ''),
            $selisih['old'] ?: null, $selisih['new'] ?: null);

        set_flash('success', 'Data pasien berhasil diperbarui.');

        return redirect()->to(site_url('pendaftaran'));
    }

    /**
     * Pendaftaran antrean unit layanan (GET /pendaftaran/antrean).
     */
    public function antrean()
    {
        $pasienId = (int) $this->request->getGet('pasien_id');
        $pasienModel = new PasienModel();

        return view('pendaftaran/daftar_poli', [
            'pageTitle'      => 'Pendaftaran Antrean Poli',
            'pasienSelected' => $pasienId > 0 ? $pasienModel->find($pasienId) : null,
            'pasienList'     => $pasienModel->orderBy('nama_pasien', 'ASC')->limit(200)->findAll(),
            'poliList'       => (new PoliModel())->where('status', 'aktif')->orderBy('nama_poli')->findAll(),
            'dokterList'     => (new DokterModel())->daftarDenganPoli(),
        ]);
    }

    /**
     * Simpan antrean unit layanan (POST /pendaftaran/antrean).
     */
    public function simpanAntrean()
    {
        if (strtolower($this->request->getMethod()) !== 'post') {
            return redirect()->to(site_url('pendaftaran/antrean'));
        }

        $pasienId = (int) $this->request->getPost('pasien_id');
        $poliId   = (int) $this->request->getPost('poli_id');
        $dokterId = (int) $this->request->getPost('dokter_id');

        if ($pasienId <= 0 || $poliId <= 0 || $dokterId <= 0) {
            set_flash('danger', 'Harap pilih pasien, unit layanan tujuan, dan bidan/nakes pemeriksa.');

            return redirect()->to(site_url('pendaftaran/antrean'));
        }

        $kunjunganModel = new KunjunganModel();
        $today          = date('Y-m-d');

        if ($kunjunganModel->sudahTerdaftar($pasienId, $today, $poliId)) {
            set_flash('danger', 'Pasien sudah terdaftar pada unit layanan yang sama hari ini.');

            return redirect()->to(site_url('pendaftaran/antrean'));
        }

        $jenis = $kunjunganModel->where('pasien_id', $pasienId)->countAllResults() > 0 ? 'Lama' : 'Baru';

        $kunjunganId = $this->prosesDaftarkanAntrean(
            $pasienId,
            $poliId,
            $dokterId,
            (string) ($this->request->getPost('cara_bayar') ?: 'Umum'),
            $jenis,
            (string) $this->request->getPost('keluhan_awal'),
        );

        set_flash('success', 'Pendaftaran antrean unit layanan berhasil dilakukan!');

        return redirect()->to(site_url('pendaftaran/karcis/' . $kunjunganId));
    }

    /**
     * Cetak kartu berobat pasien (GET /pendaftaran/kartu/(:num)).
     */
    public function kartu(?string $id = null)
    {
        $pasien = (new PasienModel())->find((int) $id);

        if ($pasien === null) {
            set_flash('danger', 'Data pasien tidak ditemukan.');

            return redirect()->to(site_url('pendaftaran'));
        }

        return view('pendaftaran/kartu_pasien', [
            'pageTitle'  => 'Kartu Berobat - ' . $pasien['nama_pasien'],
            'pasien'     => $pasien,
            'pengaturan' => (new PengaturanModel())->profil(),
        ]);
    }

    /**
     * Cetak karcis antrean (GET /pendaftaran/karcis/(:num)).
     */
    public function karcis(?string $id = null)
    {
        $kunjunganModel = new KunjunganModel();

        $kunjungan = $kunjunganModel->select('kunjungan.*, pasien.no_rm, pasien.nama_pasien,
                        pasien.jenis_kelamin, poli.nama_poli, poli.kode_poli, dokter.nama_dokter')
            ->join('pasien', 'pasien.id = kunjungan.pasien_id', 'left')
            ->join('poli', 'poli.id = kunjungan.poli_id', 'left')
            ->join('dokter', 'dokter.id = kunjungan.dokter_id', 'left')
            ->where('kunjungan.id', (int) $id)
            ->first();

        if ($kunjungan === null) {
            set_flash('danger', 'Data antrean tidak ditemukan.');

            return redirect()->to(site_url('pendaftaran'));
        }

        return view('pendaftaran/karcis_antrean', [
            'pageTitle'  => 'Karcis Antrean - ' . $kunjungan['no_antrean'],
            'kunjungan'  => $kunjungan,
            'pengaturan' => (new PengaturanModel())->profil(),
        ]);
    }

    // ------------------------------------------------------------------
    // Internal
    // ------------------------------------------------------------------

    /**
     * Ambil payload input form pasien (bersih, konsisten).
     *
     * @return array<string, mixed>
     */
    private function pasienPayload(): array
    {
        $post = fn (string $k, string $default = ''): string => clean((string) ($this->request->getPost($k) ?? $default));
        $emptyToNull = static fn (string $v): ?string => $v === '' ? null : $v;

        return [
            'no_rm'             => $post('no_rm'),
            'nik'               => $post('nik'),
            'no_bpjs'           => $emptyToNull($post('no_bpjs')),
            'nama_pasien'       => $post('nama_pasien'),
            'jenis_kelamin'     => $post('jenis_kelamin', 'L'),
            'tempat_lahir'      => $post('tempat_lahir'),
            'tanggal_lahir'     => $post('tanggal_lahir'),
            'golongan_darah'    => $post('golongan_darah', '-'),
            'rhesus'            => $post('rhesus', '+'),
            'alamat'            => $post('alamat'),
            'no_hp'             => $post('no_hp'),
            'agama'             => $post('agama', 'Islam'),
            'pendidikan'        => $post('pendidikan', '-'),
            'pekerjaan'         => $post('pekerjaan', '-'),
            'status_perkawinan' => $post('status_perkawinan', 'Menikah'),
            'penanggung_jawab'  => $post('penanggung_jawab'),
            'suami_nama'        => $emptyToNull($post('suami_nama')),
            'suami_nik'         => $emptyToNull($post('suami_nik')),
            'suami_pekerjaan'   => $emptyToNull($post('suami_pekerjaan')),
            'hubungan_pj'       => $post('hubungan_pj'),
        ];
    }

    /**
     * Buat kunjungan + nomor antrean otomatis (FR-014/FR-015), lalu audit.
     *
     * @return int id kunjungan baru
     */
    private function prosesDaftarkanAntrean(
        int $pasienId,
        int $poliId,
        int $dokterId,
        string $caraBayar,
        string $jenisKunjungan,
        string $keluhanAwal,
    ): int {
        $kunjunganModel = new KunjunganModel();
        $today          = date('Y-m-d');

        $kunjunganId = $kunjunganModel->insert([
            'no_registrasi'    => $kunjunganModel->nextNoRegistrasi($today),
            'pasien_id'        => $pasienId,
            'poli_id'          => $poliId,
            'dokter_id'        => $dokterId,
            'tgl_kunjungan'    => $today,
            'no_antrean'       => $kunjunganModel->nextNoAntrean($today, $poliId),
            'jenis_kunjungan'  => $jenisKunjungan,
            'cara_bayar'       => in_array($caraBayar, ['Umum', 'BPJS', 'Asuransi Lain'], true) ? $caraBayar : 'Umum',
            'keluhan_awal'     => $keluhanAwal,
            'status_pelayanan' => 'Menunggu',
            'user_id'          => get_user()['user_id'] ?? null,
        ]);

        log_audit('pendaftaran', 'CREATE', 'kunjungan', $kunjunganId,
            'Pendaftaran antrean pasien #' . $pasienId . ' ke unit layanan #' . $poliId,
            null, ['pasien_id' => $pasienId, 'poli_id' => $poliId, 'dokter_id' => $dokterId]);

        return (int) $kunjunganId;
    }
}
