<?php

namespace App\Controllers;

/**
 * Home — pemicu rute awal aplikasi RME PMB.
 *
 * - index()             : arahkan ke dashboard bila sudah login, ke login bila belum
 * - underConstruction() : halaman "Sedang dalam Migrasi" untuk modul bertahap
 */
class Home extends BaseController
{
    /**
     * Rute "/" — pengalihan sesuai status login.
     */
    public function index()
    {
        return redirect()->to(site_url(is_logged_in() ? 'dashboard' : 'login'));
    }

    /**
     * Penangkap rute modul yang belum dimigrasikan.
     *
     * @param string|null $seg1
     * @param string|null $seg2
     * @param string|null $seg3
     */
    public function underConstruction(?string $seg1 = null, ?string $seg2 = null, ?string $seg3 = null)
    {
        $module = implode('/', array_filter([$seg1, $seg2, $seg3]));

        return view('home/under_construction', [
            'pageTitle' => 'Sedang dalam Migrasi',
            'module'    => $module,
        ]);
    }
}
