<?php

/**
 * Helper Umum Aplikasi RME Praktik Mandiri Bidan (PMB)
 * Migrasi dari config/app.php (legacy) ke CodeIgniter 4.
 *
 * File: app/Helpers/pmb_helper.php
 */

if (! function_exists('clean')) {
    /**
     * Escape output (setara esc() milik CI4; dipertahankan agar view
     * hasil porting konsisten dengan kode legacy).
     */
    function clean($data): string
    {
        return htmlspecialchars((string) ($data ?? ''), ENT_QUOTES, 'UTF-8');
    }
}

if (! function_exists('tgl_indo')) {
    /**
     * Format tanggal ke Bahasa Indonesia.
     */
    function tgl_indo(?string $tanggal, bool $cetak_hari = false): string
    {
        if (empty($tanggal) || $tanggal === '0000-00-00' || $tanggal === '0000-00-00 00:00:00') {
            return '-';
        }

        $hari = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
        $bulan = [
            1 => 'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
            'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember',
        ];

        $timestamp = strtotime($tanggal);
        if ($timestamp === false) {
            return '-';
        }

        $hasil = date('d', $timestamp) . ' ' . $bulan[(int) date('m', $timestamp)] . ' ' . date('Y', $timestamp);

        if ($cetak_hari) {
            $hasil = $hari[(int) date('w', $timestamp)] . ', ' . $hasil;
        }

        if (strpos($tanggal, ':') !== false) {
            $hasil .= ' ' . date('H:i', $timestamp) . ' WIB';
        }

        return $hasil;
    }
}

if (! function_exists('format_rupiah')) {
    function format_rupiah($angka): string
    {
        return 'Rp ' . number_format((float) $angka, 0, ',', '.');
    }
}

if (! function_exists('hitung_usia')) {
    /**
     * Usia (tahun + bulan) dari tanggal lahir.
     */
    function hitung_usia(?string $tanggal_lahir): string
    {
        if (empty($tanggal_lahir)) {
            return '-';
        }

        try {
            $birthDate = new DateTime($tanggal_lahir);
            $today      = new DateTime('today');
            $diff       = $today->diff($birthDate);

            return $diff->y . ' Thn ' . $diff->m . ' Bln';
        } catch (Exception $e) {
            return '-';
        }
    }
}

if (! function_exists('usia_tahun')) {
    /**
     * Usia dalam tahun penuh (untuk skoring risiko, kategori lansia, dll).
     */
    function usia_tahun(?string $tanggal_lahir): int
    {
        if (empty($tanggal_lahir)) {
            return 0;
        }

        try {
            return (new DateTime($tanggal_lahir))->diff(new DateTime('today'))->y;
        } catch (Exception $e) {
            return 0;
        }
    }
}

if (! function_exists('hitung_hpl')) {
    /**
     * Hitung HPL dari HPHT (metode Naegele: HPHT + 280 hari).
     */
    function hitung_hpl(string $hpht): string
    {
        return date('Y-m-d', strtotime($hpht . ' +280 days'));
    }
}

if (! function_exists('usia_kehamilan')) {
    /**
     * Usia kehamilan (minggu) dari HPHT sampai tanggal pemeriksaan.
     *
     * @return int minggu
     */
    function usia_kehamilan(string $hpht, string $tgl_periksa): int
    {
        $hphtTs = strtotime($hpht);
        $tglTs  = strtotime($tgl_periksa);

        if ($hphtTs === false || $tglTs === false || $tglTs < $hphtTs) {
            return 0;
        }

        return (int) floor(($tglTs - $hphtTs) / (7 * 86400));
    }
}
