<?php

/**
 * Helper Autentikasi & Otorisasi (RBAC) Praktik Mandiri Bidan
 * Migrasi dari helpers/auth.php (legacy) ke CodeIgniter 4.
 *
 * File: app/Helpers/auth_helper.php
 */

if (! function_exists('is_logged_in')) {
    function is_logged_in(): bool
    {
        return session()->has('user_id') && session()->get('user_id') !== null;
    }
}

if (! function_exists('get_user')) {
    /**
     * @return array<string, mixed>|null
     */
    function get_user(): ?array
    {
        if (! is_logged_in()) {
            return null;
        }

        return [
            'id'           => session()->get('user_id'),
            'username'     => session()->get('username'),
            'nama_lengkap' => session()->get('nama_lengkap'),
            'role'         => session()->get('role'),
        ];
    }
}

if (! function_exists('get_role')) {
    function get_role(): ?string
    {
        return session()->get('role');
    }
}

if (! function_exists('is_admin')) {
    function is_admin(): bool
    {
        return get_role() === 'admin';
    }
}

if (! function_exists('is_bidan_pj')) {
    function is_bidan_pj(): bool
    {
        return get_role() === 'bidan_pj';
    }
}

if (! function_exists('is_bidan')) {
    function is_bidan(): bool
    {
        return in_array(get_role(), ['bidan_pj', 'bidan'], true);
    }
}

if (! function_exists('is_asisten')) {
    function is_asisten(): bool
    {
        return get_role() === 'asisten';
    }
}

if (! function_exists('is_pmik')) {
    function is_pmik(): bool
    {
        return in_array(get_role(), ['pmik', 'admin'], true);
    }
}

if (! function_exists('can_manage_clinical')) {
    /**
     * Boleh mengisi/mengubah data klinis (asesmen, diagnosis, tindakan).
     */
    function can_manage_clinical(): bool
    {
        return in_array(get_role(), ['bidan_pj', 'bidan', 'admin'], true);
    }
}

if (! function_exists('require_login')) {
    function require_login(): void
    {
        if (! is_logged_in()) {
            set_flash('danger', 'Silakan login terlebih dahulu untuk mengakses sistem.');
            redirect()->to(site_url('login'));
            exit;
        }
    }
}

if (! function_exists('require_role')) {
    /**
     * Gerbang otorisasi per-role (prinsip least privilege, SEC-010).
     *
     * @param string|string[] $allowed_roles
     */
    function require_role($allowed_roles): void
    {
        require_login();

        if (! is_array($allowed_roles)) {
            $allowed_roles = [$allowed_roles];
        }

        if (! in_array(get_role(), $allowed_roles, true)) {
            set_flash('danger', 'Akses ditolak. Anda tidak memiliki izin untuk halaman tersebut.');
            redirect()->to(site_url('dashboard'));
            exit;
        }
    }
}

if (! function_exists('set_flash')) {
    function set_flash(string $type, string $message): void
    {
        session()->setFlashdata('flash', [
            'type'    => $type,
            'message' => $message,
        ]);
    }
}

if (! function_exists('get_flash')) {
    /**
     * @return array{type: string, message: string}|null
     */
    function get_flash(): ?array
    {
        $flash = session()->getFlashdata('flash');

        return is_array($flash) ? $flash : null;
    }
}
