<?php

if (! function_exists('log_audit')) {
    /**
     * Catat aktivitas ke tabel audit_log (FR-100, SEC-014).
     *
     * Pemakaian:
     *   log_audit('pendaftaran', 'CREATE', 'pasien', $id, 'Tambah pasien baru Ahmad Fauzi');
     *   log_audit('anc', 'UPDATE', 'anc_kunjungan', $id, 'Update K3', $old, $new);
     *
     * @param array<string, mixed>|null $old nilai lama (sebelum update/delete)
     * @param array<string, mixed>|null $new nilai baru (sesudah create/update)
     */
    function log_audit(
        string $module,
        string $action,
        ?string $table = null,
        $recordId = null,
        ?string $description = null,
        ?array $old = null,
        ?array $new = null,
    ): void {
        try {
            $user   = get_user();
            $request = service('request');

            $db = db_connect();
            $db->table('audit_log')->insert([
                'user_id'     => $user['user_id'] ?? $user['id'] ?? null,
                'username'    => $user['username'] ?? null,
                'role'        => $user['role'] ?? null,
                'module'      => $module,
                'action'      => strtoupper($action),
                'table_name'  => $table,
                'record_id'   => $recordId !== null ? (string) $recordId : null,
                'description' => $description !== null ? mb_substr($description, 0, 255) : null,
                'old_values'  => $old !== null ? json_encode($old, JSON_UNESCAPED_UNICODE) : null,
                'new_values'  => $new !== null ? json_encode($new, JSON_UNESCAPED_UNICODE) : null,
                'ip_address'  => $request ? $request->getIPAddress() : null,
                'user_agent'  => $_SERVER['HTTP_USER_AGENT'] !== null ? mb_substr((string) ($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 255) : null,
                'created_at'  => date('Y-m-d H:i:s'),
            ]);
        } catch (Throwable $e) {
            // Audit tidak boleh menjatuhkan transaksi bisnis utama.
            log_message('error', 'log_audit gagal: ' . $e->getMessage());
        }
    }
}

if (! function_exists('audit_old_new')) {
    /**
     * Ambil selisih nilai lama vs baru untuk dicatat (hanya yang berubah).
     *
     * @param array<string, mixed> $old
     * @param array<string, mixed> $new
     *
     * @return array{old: array<string, mixed>, new: array<string, mixed>}
     */
    function audit_old_new(array $old, array $new): array
    {
        $changedOld = [];
        $changedNew = [];

        foreach ($new as $key => $value) {
            if (array_key_exists($key, $old) && $old[$key] !== $value) {
                $changedOld[$key] = $old[$key];
                $changedNew[$key] = $value;
            }
        }

        return ['old' => $changedOld, 'new' => $changedNew];
    }
}
