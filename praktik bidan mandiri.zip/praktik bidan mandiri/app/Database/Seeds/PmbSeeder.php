<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

/**
 * Data awal aplikasi RME PMB — hasil porting seed_database_data()
 * dan check_and_migrate_pmb_tables() dari config/database.php legacy.
 *
 * Seluruh bagian bersifat idempoten (aman dijalankan berulang):
 * data hanya ditambahkan bila belum ada.
 *
 * Jalankan: php spark db:seed PmbSeeder
 */
class PmbSeeder extends Seeder
{
    public function run(): void
    {
        $this->seedUsers();
        $this->seedPengaturan();
        $this->seedPoli();
        $this->seedDokter();
        $this->seedIcd10();
        $this->seedTindakan();
        $this->seedObat();
        $this->seedPasien();
        $this->seedKunjunganContoh();
        $this->seedKehamilanContoh();

        $this->writeln(' PmbSeeder selesai (semua bagian idempoten).');
    }

    private function writeln(string $msg): void
    {
        if (is_cli()) {
            fwrite(STDOUT, $msg . PHP_EOL);
        }
    }

    private function countOf(string $table): int
    {
        return (int) $this->db->table($table)->countAllResults();
    }

    /**
     * Insert satu baris hanya bila kunci uniknya belum ada
     * (aman untuk keadaan database parsial / gagal tengah jalan).
     *
     * @param array<string, mixed> $row
     */
    private function insertIfMissing(string $table, string $keyColumn, string $keyValue, array $row): void
    {
        $exists = $this->db->table($table)->where($keyColumn, $keyValue)->countAllResults();

        if ($exists === 0) {
            $this->db->table($table)->insert($row);
        }
    }

    // ----------------------------------------------------------------
    // 1. Pengguna (FR-003/FR-004/FR-008)
    // ----------------------------------------------------------------
    private function seedUsers(): void
    {
        $hashAdmin   = password_hash('admin123', PASSWORD_DEFAULT);
        $hashPmik    = password_hash('pmik123', PASSWORD_DEFAULT);
        $hashBidan   = password_hash('bidan123', PASSWORD_DEFAULT);
        $hashAsisten = password_hash('asisten123', PASSWORD_DEFAULT);

        $rows = [
            ['username' => 'admin', 'password' => $hashAdmin, 'nama_lengkap' => 'Administrator Utama', 'role' => 'admin', 'status' => 'aktif'],
            ['username' => 'pmik', 'password' => $hashPmik, 'nama_lengkap' => 'Siti Rahmawati, A.Md.RMIK', 'role' => 'pmik', 'status' => 'aktif'],
            ['username' => 'bidan_pj', 'password' => $hashBidan, 'nama_lengkap' => 'Bdn. Hj. Siti Hajar, S.Tr.Keb, Bdn', 'role' => 'bidan_pj', 'no_sipb' => '446/012/SIPB/DPMPTSP/2023', 'no_str' => '140252120-112233', 'status' => 'aktif'],
            ['username' => 'bidan', 'password' => $hashBidan, 'nama_lengkap' => 'Bdn. Rina Nurhaliza, A.Md.Keb', 'role' => 'bidan', 'no_sipb' => '446/015/SIPB/DPMPTSP/2023', 'no_str' => '140252120-445566', 'status' => 'aktif'],
            ['username' => 'asisten', 'password' => $hashAsisten, 'nama_lengkap' => 'Nurul Aini, S.Kep', 'role' => 'asisten', 'status' => 'aktif'],
        ];

        if ($this->countOf('users') === 0) {
            foreach ($rows as $row) {
                $this->db->table('users')->insert($row);
            }

            return;
        }

        // Database legacy mungkin hanya berisi admin & pmik.
        foreach ($rows as $row) {
            $exists = $this->db->table('users')->where('username', $row['username'])->countAllResults();
            if ($exists === 0) {
                $this->db->table('users')->insert($row);
            }
        }
    }

    // ----------------------------------------------------------------
    // 2. Pengaturan profil praktik (FR-009)
    // ----------------------------------------------------------------
    private function seedPengaturan(): void
    {
        $pmb = [
            'nama_instansi'   => 'Praktik Mandiri Bidan (PMB) Hj. Siti Hajar, S.Tr.Keb',
            'alamat_instansi' => 'Jl. Melati Raya No. 12, Kel. Sukamaju, Kec. Cilodong, Kota Depok',
            'telepon'         => '0812-3456-7890 / (021) 8765432',
            'email'           => 'pmb.sitihajar@gmail.com',
            'pimpinan_nama'   => 'Bdn. Hj. Siti Hajar, S.Tr.Keb, Bdn',
            'pimpinan_nip'    => 'SIPB: 446/012/SIPB/DPMPTSP/2023',
            'pmik_nama'       => 'Bdn. Rina Nurhaliza, A.Md.Keb',
            'pmik_nip'        => 'STR: 140252120-445566',
        ];

        if ($this->countOf('pengaturan') === 0) {
            $this->db->table('pengaturan')->insert($pmb);

            return;
        }

        // Perbarui profil lama (masih bertanda klinik lama) menjadi PMB.
        $row = $this->db->table('pengaturan')->get()->getRowArray();
        if ($row !== null && (str_contains($row['nama_instansi'], 'Klinik Pratama') || str_contains($row['nama_instansi'], 'Sehat Medika'))) {
            $this->db->table('pengaturan')->where('id', $row['id'])->update($pmb);
        }
    }

    // ----------------------------------------------------------------
    // 3. Unit layanan (poli)
    // ----------------------------------------------------------------
    private function seedPoli(): void
    {
        if ($this->countOf('poli') === 0) {
            $generic = [
                ['kode_poli' => 'POL-01', 'nama_poli' => 'Poli Umum', 'keterangan' => 'Pelayanan medis umum untuk segala usia', 'status' => 'aktif'],
                ['kode_poli' => 'POL-02', 'nama_poli' => 'Poli Gigi & Mulut', 'keterangan' => 'Pemeriksaan dan tindakan kesehatan gigi dan mulut', 'status' => 'aktif'],
                ['kode_poli' => 'POL-03', 'nama_poli' => 'Poli KIA / KB', 'keterangan' => 'Kesehatan Ibu, Anak, dan Keluarga Berencana', 'status' => 'aktif'],
                ['kode_poli' => 'POL-04', 'nama_poli' => 'Poli Penyakit Dalam', 'keterangan' => 'Pelayanan spesialis organ dalam dan penyakit kronis', 'status' => 'aktif'],
                ['kode_poli' => 'POL-05', 'nama_poli' => 'Poli Anak', 'keterangan' => 'Pelayanan spesialis kesehatan anak dan tumbuh kembang', 'status' => 'aktif'],
            ];
            foreach ($generic as $row) {
                $this->db->table('poli')->insert($row);
            }
        }

        $pmbPoli = [
            ['kode_poli' => 'POL-ANC', 'nama_poli' => 'Pemeriksaan Ibu Hamil (ANC 10T)', 'keterangan' => 'Pelayanan antenatal terpadu standar 10T dan skrining risiko kehamilan'],
            ['kode_poli' => 'POL-INC', 'nama_poli' => 'Pelayanan Persalinan Normal (APN 24 Jam)', 'keterangan' => 'Asuhan persalinan normal, observasi kala I-IV dan partograf'],
            ['kode_poli' => 'POL-PNC', 'nama_poli' => 'Pelayanan Nifas & Neonatus (KF & KN)', 'keterangan' => 'Perawatan ibu nifas KF1-KF4 dan neonatal KN1-KN3'],
            ['kode_poli' => 'POL-KB', 'nama_poli' => 'Pelayanan KB & Kesehatan Reproduksi', 'keterangan' => 'Pelayanan suntik KB, pil, implan, IUD, dan konseling'],
            ['kode_poli' => 'POL-IMU', 'nama_poli' => 'Imunisasi & Tumbuh Kembang Bayi', 'keterangan' => 'Imunisasi dasar lengkap dan pemantauan berat/panjang badan'],
        ];
        foreach ($pmbPoli as $row) {
            $exists = $this->db->table('poli')->where('kode_poli', $row['kode_poli'])->countAllResults();
            if ($exists === 0) {
                $this->db->table('poli')->insert($row + ['status' => 'aktif']);
            }
        }
    }

    // ----------------------------------------------------------------
    // 4. Bidan & tenaga kesehatan
    // ----------------------------------------------------------------
    private function seedDokter(): void
    {
        if ($this->countOf('dokter') === 0) {
            $generic = [
                ['sip' => 'SIP.440/102/DU/2021', 'nama_dokter' => 'dr. Farhan Maulana', 'poli_kode' => 'POL-01', 'no_hp' => '081234567891'],
                ['sip' => 'SIP.440/103/DU/2022', 'nama_dokter' => 'dr. Annisa Larasati', 'poli_kode' => 'POL-01', 'no_hp' => '081234567892'],
                ['sip' => 'SIP.440/201/DG/2020', 'nama_dokter' => 'drg. Maya Pratiwi', 'poli_kode' => 'POL-02', 'no_hp' => '081345678901'],
                ['sip' => 'SIP.440/301/OB/2019', 'nama_dokter' => 'dr. Budi Santoso, Sp.OG', 'poli_kode' => 'POL-03', 'no_hp' => '081398765432'],
                ['sip' => 'SIP.440/401/PD/2018', 'nama_dokter' => 'dr. Rudi Hartono, Sp.PD', 'poli_kode' => 'POL-04', 'no_hp' => '081255566677'],
                ['sip' => 'SIP.440/501/AK/2021', 'nama_dokter' => 'dr. Dian Kartika, Sp.A', 'poli_kode' => 'POL-05', 'no_hp' => '081322233344'],
            ];
            foreach ($generic as $row) {
                $poliId = $this->db->table('poli')->where('kode_poli', $row['poli_kode'])->get()->getRowArray()['id'] ?? 1;
                $this->db->table('dokter')->insert([
                    'sip'          => $row['sip'],
                    'nama_dokter'  => $row['nama_dokter'],
                    'poli_id'      => $poliId,
                    'no_hp'        => $row['no_hp'],
                    'status'       => 'aktif',
                ]);
            }
        }

        // Bidan (data praktisi PMB)
        $hasBidan = $this->db->table('dokter')->like('sip', 'SIPB')->countAllResults();
        if ($hasBidan === 0) {
            $ancPoliId = $this->db->table('poli')->where('kode_poli', 'POL-ANC')->get()->getRowArray()['id'] ?? 1;
            $this->db->table('dokter')->insert([
                'sip' => '446/012/SIPB/DPMPTSP/2023', 'nama_dokter' => 'Bdn. Hj. Siti Hajar, S.Tr.Keb, Bdn',
                'poli_id' => $ancPoliId, 'no_hp' => '081234567890', 'status' => 'aktif',
            ]);
            $this->db->table('dokter')->insert([
                'sip' => '446/015/SIPB/DPMPTSP/2023', 'nama_dokter' => 'Bdn. Rina Nurhaliza, A.Md.Keb',
                'poli_id' => $ancPoliId, 'no_hp' => '081398765432', 'status' => 'aktif',
            ]);
        }
    }

    // ----------------------------------------------------------------
    // 5. ICD-10 (FR-00A)
    // ----------------------------------------------------------------
    private function seedIcd10(): void
    {
        if ($this->countOf('master_icd10') === 0) {
            $umum = [
                ['J00', 'Nasofaringitis akut (Common cold / Batuk Pilek)', 'Acute nasopharyngitis'],
                ['I10', 'Hipertensi esensial (primer)', 'Essential (primary) hypertension'],
                ['E11', 'Diabetes melitus tipe 2 (NIDDM)', 'Type 2 diabetes mellitus'],
                ['K29.7', 'Gastritis tidak spesifik / Sakit Maag', 'Gastritis, unspecified'],
                ['A09', 'Diare dan gastroenteritis infeksius', 'Infectious gastroenteritis and colitis'],
                ['J06.9', 'Infeksi Saluran Pernapasan Akut (ISPA) Atas', 'Acute upper respiratory infection, unspecified'],
                ['M79.1', 'Mialgia / Nyeri Otot', 'Myalgia'],
                ['R51', 'Sakit kepala / Cephalea', 'Headache'],
                ['J45', 'Asma bronkial', 'Asthma'],
                ['L20', 'Dermatitis atopik / Eksim kulit', 'Atopic dermatitis'],
                ['K02.9', 'Karies gigi (Gigi berlubang)', 'Dental caries, unspecified'],
                ['K04.0', 'Pulpitis akut / radang pulpa gigi', 'Pulpitis'],
                ['B35.9', 'Dermatofitosis / Infeksi Jamur Kulit', 'Dermatophytosis, unspecified'],
                ['H10.9', 'Konjungtivitis tidak spesifik (Sakit mata)', 'Conjunctivitis, unspecified'],
                ['M10.9', 'Gout artritis / Asam Urat', 'Gout, unspecified'],
                ['Z00.0', 'Pemeriksaan kesehatan umum (General Medical Checkup)', 'General medical examination'],
                ['O80', 'Persalinan spontan tunggal normal', 'Single spontaneous delivery'],
                ['Z30.0', 'Konseling dan manajemen Keluarga Berencana (KB)', 'General counselling and advice on contraception'],
                ['R50.9', 'Demam yang tidak diketahui penyebabnya', 'Fever, unspecified'],
                ['A01.0', 'Demam tifoid (Tipes)', 'Typhoid fever'],
            ];
            foreach ($umum as $row) {
                $this->insertIfMissing('master_icd10', 'kode', $row[0], ['kode' => $row[0], 'nama_penyakit' => $row[1], 'nama_latin' => $row[2]]);
            }
        }

        $kebidanan = [
            ['Z34.0', 'Pengawasan kehamilan normal pertama (Primi)', 'Supervision of normal first pregnancy'],
            ['Z34.8', 'Pengawasan kehamilan normal lainnya (Multi)', 'Supervision of other normal pregnancy'],
            ['Z35.9', 'Pengawasan kehamilan risiko tinggi (Risti)', 'Supervision of high-risk pregnancy'],
            ['O21.0', 'Hiperemesis gravidarum ringan (Mual muntah hamil)', 'Mild hyperemesis gravidarum'],
            ['O14.0', 'Preeklamsia ringan / sedang pada kehamilan', 'Mild to moderate pre-eclampsia'],
            ['O14.1', 'Preeklamsia berat (PEB)', 'Severe pre-eclampsia'],
            ['O99.0', 'Anemia defisiensi besi pada masa kehamilan', 'Anaemia complicating pregnancy'],
            ['O26.8', 'Kurang Energi Kronis (KEK) pada kehamilan', 'Maternal nutritional deficiency in pregnancy'],
            ['O20.0', 'Abortus imminens (Ancaman keguguran)', 'Threatened abortion'],
            ['Z39.2', 'Pemeriksaan rutin pasca persalinan (Nifas)', 'Routine postpartum follow-up'],
            ['O80', 'Persalinan spontan tunggal normal (APN)', 'Single spontaneous delivery'],
        ];
        foreach ($kebidanan as $row) {
            $this->insertIfMissing('master_icd10', 'kode', $row[0], ['kode' => $row[0], 'nama_penyakit' => $row[1], 'nama_latin' => $row[2]]);
        }
    }

    // ----------------------------------------------------------------
    // 6. Tindakan & tarif
    // ----------------------------------------------------------------
    private function seedTindakan(): void
    {
        $rows = [
            ['TND-001', 'Pemeriksaan Fisik & Konsultasi Dokter Umum', 'Konsultasi', 35000],
            ['TND-002', 'Pemeriksaan & Konsultasi Dokter Spesialis', 'Konsultasi', 75000],
            ['TND-003', 'Pembersihan Karang Gigi (Scaling) Ringan', 'Gigi', 120000],
            ['TND-004', 'Penambalan Gigi Komposit / Sinar', 'Gigi', 90000],
            ['TND-005', 'Ekstraksi Gigi Sulung / Permanen', 'Gigi', 80000],
            ['TND-006', 'Nebulisasi / Terapi Uap Pernapasan', 'Poli Umum', 50000],
            ['TND-007', 'Pemeriksaan Gula Darah Sewaktu (GDS) Rapid', 'Laboratorium Sederhana', 20000],
            ['TND-008', 'Pemeriksaan Asam Urat Rapid', 'Laboratorium Sederhana', 25000],
            ['TND-009', 'Pemeriksaan Kolesterol Total Rapid', 'Laboratorium Sederhana', 30000],
            ['TND-010', 'Pembersihan & Perawatan Luka Ringan / Hecting', 'Bedah Minor', 60000],
            ['TND-011', 'Suntik KB 3 Bulan / 1 Bulan', 'KIA-KB', 35000],
            ['TND-012', 'Pemeriksaan USG Kehamilan Sederhana', 'KIA-KB', 85000],
            ['TND-ANC01', 'Pemeriksaan ANC Terpadu 10T & Konseling P4K', 'ANC Kebidanan', 50000],
            ['TND-ANC02', 'Skrining Laboratorium Dasar ANC (Hb & Protein Urin)', 'Laboratorium Kebidanan', 65000],
            ['TND-ANC03', 'Pemeriksaan USG Skrining Dasar 2D', 'Kebidanan', 90000],
            ['TND-ANC04', 'Injeksi Imunisasi Tetanus Toxoid (TT)', 'Imunisasi', 40000],
            ['TND-KB01', 'Suntik KB 3 Bulan (Triclofem / Depo)', 'Pelayanan KB', 35000],
            ['TND-KB02', 'Suntik KB 1 Bulan (Cyclofem)', 'Pelayanan KB', 40000],
            ['TND-KB03', 'Pemasangan IUD / AKDR (Copper T)', 'Pelayanan KB', 350000],
            ['TND-KB04', 'Pemasangan Implan / Susuk 2 Batang', 'Pelayanan KB', 300000],
            ['TND-INC01', 'Paket Persalinan Normal (APN 24 Jam & Rawat Gabung)', 'Persalinan', 1500000],
            ['TND-PNC01', 'Kunjungan Nifas & Perawatan Luka Perineum', 'Nifas', 60000],
            ['TND-BAYI01', 'Perawatan Bayi Baru Lahir + Vit K1 + Salep Mata', 'Neonatal', 100000],
        ];
        foreach ($rows as $row) {
            $this->insertIfMissing('master_tindakan', 'kode_tindakan', $row[0], [
                'kode_tindakan' => $row[0], 'nama_tindakan' => $row[1],
                'kategori' => $row[2], 'tarif' => $row[3],
            ]);
        }
    }

    // ----------------------------------------------------------------
    // 7. Obat & vaksin
    // ----------------------------------------------------------------
    private function seedObat(): void
    {
        $rows = [
            ['OBT-001', 'Paracetamol 500mg', 'Tablet', '500 mg', 500, 1500],
            ['OBT-002', 'Amoxicillin 500mg', 'Kapsul', '500 mg', 300, 3000],
            ['OBT-003', 'Antasida Doen', 'Tablet', 'Kunyah', 400, 1000],
            ['OBT-004', 'Omeprazole 20mg', 'Kapsul', '20 mg', 250, 4500],
            ['OBT-005', 'Amlodipine 10mg', 'Tablet', '10 mg', 350, 2500],
            ['OBT-006', 'Captopril 25mg', 'Tablet', '25 mg', 300, 1800],
            ['OBT-007', 'Metformin 500mg', 'Tablet', '500 mg', 280, 2000],
            ['OBT-008', 'Cetirizine 10mg', 'Tablet', '10 mg', 320, 2000],
            ['OBT-009', 'Dexamethasone 0.5mg', 'Tablet', '0.5 mg', 450, 1000],
            ['OBT-010', 'Oralit 200ml', 'Sachet', 'Bubuk', 200, 1500],
            ['OBT-011', 'Zinc 20mg Dispersible', 'Tablet', '20 mg', 200, 2000],
            ['OBT-012', 'Salbutamol 2mg', 'Tablet', '2 mg', 150, 1500],
            ['OBT-013', 'Vitamin B Kompleks', 'Tablet', 'Multivitamin', 600, 800],
            ['OBT-014', 'Ibuprofen 400mg', 'Tablet', '400 mg', 250, 2500],
            ['OBT-015', 'Ketoconazole 2% Salep', 'Tube', '10 gram', 120, 8500],
        ];
        foreach ($rows as $row) {
            $this->insertIfMissing('master_obat', 'kode_obat', $row[0], [
                'kode_obat' => $row[0], 'nama_obat' => $row[1], 'satuan' => $row[2],
                'sediaan' => $row[3], 'stok' => $row[4], 'harga' => $row[5],
            ]);
        }
    }

    // ----------------------------------------------------------------
    // 8. Pasien contoh
    // ----------------------------------------------------------------
    private function seedPasien(): void
    {
        if ($this->countOf('pasien') === 0) {
            $rows = [
                ['RM-000001', '3174012508850001', '0001234567891', 'Ahmad Fauzi', 'L', 'Jakarta', '1985-08-25', 'O', 'Jl. Tebet Timur No. 12, Jakarta Selatan', '081298765431', 'Islam', 'S1/D4', 'PNS', 'Dewi Susanti', 'Istri', -15],
                ['RM-000002', '3174026012920002', '0001234567892', 'Nur Hidayah', 'P', 'Bogor', '1992-12-20', 'A', 'Jl. Pasar Minggu Baru No. 8, Jakarta Selatan', '081387654321', 'Islam', 'D3', 'Pegawai Swasta', 'Bambang Kusuma', 'Suami', -14],
                ['RM-000003', '3174031505680003', null, 'Bambang Wijanarko', 'L', 'Solo', '1968-05-15', 'B', 'Jl. Fatmawati Raya No. 99, Cilandak', '081576543210', 'Islam', 'SMA/Sederajat', 'Wiraswasta', 'Sri Wahyuni', 'Istri', -10],
                ['RM-000004', '3174044503020004', '0001234567894', 'Rina Anggraini', 'P', 'Bandung', '2002-03-05', 'AB', 'Jl. Mampang Prapatan VI No. 23', '081865432109', 'Islam', 'SMA/Sederajat', 'Mahasiswa', 'Hadi Suwito', 'Orang Tua', -8],
                ['RM-000005', '3174051001180005', '0001234567895', 'Muhammad Rayyan', 'L', 'Jakarta', '2018-01-10', 'O', 'Jl. Pancoran Barat III No. 5', '081954321098', 'Islam', 'Belum Sekolah', 'Belum Bekerja', 'Ahmad Fauzi', 'Orang Tua', -5],
                ['RM-000006', '3174065507550006', '0001234567896', 'Siti Aminah', 'P', 'Yogyakarta', '1955-07-15', 'B', 'Jl. Pejaten Barat No. 71, Pasar Minggu', '081344455566', 'Islam', 'SMP/Sederajat', 'Pensiunan', 'Rahmat Hidayat', 'Anak', -3],
                ['RM-000007', '3174070204990007', null, 'David Pratama', 'L', 'Medan', '1999-04-02', 'O', 'Jl. Kemang Raya No. 14, Bangka', '081233344455', 'Kristen', 'S1/D4', 'Karyawan Swasta', 'Suryani', 'Ibu', -1],
            ];
            foreach ($rows as $row) {
                $this->db->table('pasien')->insert([
                    'no_rm' => $row[0], 'nik' => $row[1], 'no_bpjs' => $row[2],
                    'nama_pasien' => $row[3], 'jenis_kelamin' => $row[4],
                    'tempat_lahir' => $row[5], 'tanggal_lahir' => $row[6],
                    'golongan_darah' => $row[7], 'alamat' => $row[8], 'no_hp' => $row[9],
                    'agama' => $row[10], 'pendidikan' => $row[11], 'pekerjaan' => $row[12],
                    'penanggung_jawab' => $row[13], 'hubungan_pj' => $row[14],
                    'created_at' => date('Y-m-d H:i:s', strtotime($row[15] . ' days')),
                ]);
            }
        }

        // Ibu hamil risti contoh: Dewi Lestari (prima tua + KEK).
        // Guard memakai NIK; nomor RM dicari yang bebas bila RM-000008
        // sudah terpakai pasien lain di database legacy.
        if ($this->db->table('pasien')->where('nik', '3174086503880008')->countAllResults() === 0) {
            $noRm = null;
            for ($i = 8; $i < 10000; $i++) {
                $cand = sprintf('RM-%06d', $i);
                if ($this->db->table('pasien')->where('no_rm', $cand)->countAllResults() === 0) {
                    $noRm = $cand;
                    break;
                }
            }

            if ($noRm !== null) {
                $this->db->table('pasien')->insert([
                    'no_rm' => $noRm, 'nik' => '3174086503880008', 'no_bpjs' => '0001988776655',
                    'nama_pasien' => 'Dewi Lestari', 'jenis_kelamin' => 'P', 'tempat_lahir' => 'Jakarta',
                    'tanggal_lahir' => '1988-03-20', 'golongan_darah' => 'B', 'rhesus' => '+',
                    'alamat' => 'Jl. Sukamaju Permai No. 18, Depok', 'no_hp' => '081288776655',
                    'agama' => 'Islam', 'pendidikan' => 'S1/D4', 'pekerjaan' => 'Guru',
                    'status_perkawinan' => 'Menikah', 'penanggung_jawab' => 'Hendra Setiawan',
                    'hubungan_pj' => 'Suami', 'suami_nama' => 'Hendra Setiawan',
                    'suami_nik' => '3174081005850005', 'suami_pekerjaan' => 'Karyawan BUMN',
                ]);
            }
        }

        // Data suami Nur Hidayah (RM-000002) — replikasi pembaruan legacy
        $nur = $this->db->table('pasien')->where('no_rm', 'RM-000002')->get()->getRowArray();
        if ($nur !== null && $nur['suami_nama'] === null) {
            $this->db->table('pasien')->where('id', $nur['id'])->update([
                'suami_nama' => 'Bambang Kusuma', 'suami_nik' => '3174021204900001',
                'suami_pekerjaan' => 'Wiraswasta', 'rhesus' => '+', 'status_perkawinan' => 'Menikah',
            ]);
        }
    }

    // ----------------------------------------------------------------
    // 9. Kunjungan & pemeriksaan contoh (SOAP)
    // ----------------------------------------------------------------
    private function seedKunjunganContoh(): void
    {
        if ($this->countOf('kunjungan') !== 0) {
            return;
        }

        $idPasien = fn (string $noRm): int => (int) ($this->db->table('pasien')->where('no_rm', $noRm)->get()->getRowArray()['id'] ?? 0);
        $idPoli   = fn (string $kode): int => (int) ($this->db->table('poli')->where('kode_poli', $kode)->get()->getRowArray()['id'] ?? 1);
        $idDokter = fn (string $sip): int => (int) ($this->db->table('dokter')->where('sip', $sip)->get()->getRowArray()['id'] ?? 1);
        $idIcd    = fn (string $kode): int => (int) ($this->db->table('master_icd10')->where('kode', $kode)->get()->getRowArray()['id'] ?? 1);
        $idObat   = fn (string $kode): int => (int) ($this->db->table('master_obat')->where('kode_obat', $kode)->get()->getRowArray()['id'] ?? 1);
        $idTnd    = fn (string $kode): int => (int) ($this->db->table('master_tindakan')->where('kode_tindakan', $kode)->get()->getRowArray()['id'] ?? 1);
        $idUser   = fn (string $username): int => (int) ($this->db->table('users')->where('username', $username)->get()->getRowArray()['id'] ?? 1);

        $today    = date('Y-m-d');
        $yesterday = date('Y-m-d', strtotime('-1 day'));
        $day2     = date('Y-m-d', strtotime('-2 day'));
        $day3     = date('Y-m-d', strtotime('-3 day'));
        $pmikId   = $idUser('pmik');

        $kunjungan = [
            // no_registrasi, pasien, poli, dokter, tgl, antrean, jenis, bayar, keluhan, status, created
            ['REG-' . date('Ymd', strtotime('-3 day')) . '-001', 'RM-000001', 'POL-01', 'SIP.440/102/DU/2021', $day3, 'A-001', 'Lama', 'BPJS', 'Batuk kering, pilek, badan meriang sudah 3 hari', 'Selesai', $day3 . ' 08:30:00'],
            ['REG-' . date('Ymd', strtotime('-2 day')) . '-001', 'RM-000003', 'POL-04', 'SIP.440/401/PD/2018', $day2, 'D-001', 'Lama', 'Umum', 'Pusing tengkuk berat, riwayat tekanan darah tinggi', 'Selesai', $day2 . ' 09:15:00'],
            ['REG-' . date('Ymd', strtotime('-1 day')) . '-001', 'RM-000002', 'POL-02', 'SIP.440/201/DG/2020', $yesterday, 'B-001', 'Lama', 'BPJS', 'Gigi geraham kanan bawah ngilu saat minum dingin', 'Selesai', $yesterday . ' 10:00:00'],
            ['REG-' . date('Ymd', strtotime('-1 day')) . '-002', 'RM-000006', 'POL-01', 'SIP.440/103/DU/2022', $yesterday, 'A-002', 'Lama', 'BPJS', 'Nyeri lambung perih ulu hati mual kembung', 'Selesai', $yesterday . ' 10:45:00'],
            ['REG-' . date('Ymd') . '-001', 'RM-000004', 'POL-01', 'SIP.440/102/DU/2021', $today, 'A-001', 'Baru', 'BPJS', 'Demam tinggi dan pilek sejak kemarin sore', 'Sedang Dilayani', $today . ' 08:10:00'],
            ['REG-' . date('Ymd') . '-002', 'RM-000005', 'POL-05', 'SIP.440/501/AK/2021', $today, 'E-001', 'Baru', 'BPJS', 'Batuk grok-grok dan rewel nafsu makan turun', 'Menunggu', $today . ' 08:25:00'],
            ['REG-' . date('Ymd') . '-003', 'RM-000007', 'POL-01', 'SIP.440/103/DU/2022', $today, 'A-002', 'Baru', 'Umum', 'Diare cair 4x sejak tadi pagi lemas', 'Menunggu', $today . ' 08:40:00'],
        ];

        foreach ($kunjungan as $k) {
            $this->db->table('kunjungan')->insert([
                'no_registrasi' => $k[0], 'pasien_id' => $idPasien($k[1]), 'poli_id' => $idPoli($k[2]),
                'dokter_id' => $idDokter($k[3]), 'tgl_kunjungan' => $k[4], 'no_antrean' => $k[5],
                'jenis_kunjungan' => $k[6], 'cara_bayar' => $k[7], 'keluhan_awal' => $k[8],
                'status_pelayanan' => $k[9], 'user_id' => $pmikId, 'created_at' => $k[10],
            ]);
        }

        // Pemeriksaan SOAP (kunjungan 1-4 sudah selesai)
        $pemeriksaan = [
            [1, $day3 . ' 09:00:00', 'Batuk kering dan pilek 3 hari', 'Pasien mengeluh hidung tersumbat, batuk tidak berdahak, meriang', 'Tidak ada riwayat asma', 'Tidak Ada', '120/80', 82, 37.6, 20, 68.00, 170.00, 23.53, 'Normal', 'Faring hiperemis (+), sekret hidung serous (+), ronki (-), wheezing (-)', 'J00', 'J06.9', 'Istirahat cukup, banyak minum air hangat, gunakan masker saat beraktivitas', 'Pulang/Sembuh', 'SIP.440/102/DU/2021', $day3 . ' 09:15:00'],
            [2, $day2 . ' 09:40:00', 'Pusing dan tengkuk terasa berat tegang', 'Keluhan dirasakan sejak 2 hari lalu setelah lembur kerja', 'Hipertensi sejak 3 tahun lalu rutin kontrol', 'Alergi Seafood', '150/95', 88, 36.6, 18, 74.00, 168.00, 26.22, 'Gemuk', 'Keadaan umum baik, konjungtiva anemis (-), ikterik (-), murmur (-), gallop (-)', 'I10', null, 'Kurangi konsumsi garam dan makanan berlemak, minum obat teratur tiap pagi', 'Kontrol Kembali', 'SIP.440/401/PD/2018', $day2 . ' 09:55:00'],
            [3, $yesterday . ' 10:20:00', 'Gigi geraham kanan bawah ngilu berlubang', 'Sakit terutama jika kena makanan manis dan air es', 'Disangkal', 'Tidak Ada', '118/78', 76, 36.4, 18, 54.00, 158.00, 21.63, 'Normal', 'Gigi 46 karies media kedalaman dentin, sondasi (+), perkusi (-), palpasi (-)', 'K02.9', null, 'Sikat gigi 2 kali sehari, hindari mengunyah di sisi kanan sebelum tambalan permanen', 'Kontrol Kembali', 'SIP.440/201/DG/2020', $yesterday . ' 10:40:00'],
            [4, $yesterday . ' 11:10:00', 'Nyeri ulu hati melilit disertai mual', 'Keluhan timbul setelah terlambat makan siang dan minum kopi', 'Riwayat sakit maag berulang', 'Tidak Ada', '130/85', 80, 36.5, 20, 58.00, 152.00, 25.10, 'Gemuk', 'Nyeri tekan epigastrium (+), bising usus normal 12x/menit', 'K29.7', null, 'Makan teratur dengan porsi kecil tapi sering, hindari pedas, asam, kopi, dan santan', 'Pulang/Sembuh', 'SIP.440/103/DU/2022', $yesterday . ' 11:30:00'],
        ];

        foreach ($pemeriksaan as $p) {
            $this->db->table('pemeriksaan')->insert([
                'kunjungan_id' => $p[0], 'tgl_pemeriksaan' => $p[1], 'keluhan_utama' => $p[2],
                'riwayat_penyakit_sekarang' => $p[3], 'riwayat_penyakit_dahulu' => $p[4],
                'riwayat_alergi' => $p[5], 'tekanan_darah' => $p[6], 'nadi' => $p[7],
                'suhu' => $p[8], 'pernapasan' => $p[9], 'berat_badan' => $p[10],
                'tinggi_badan' => $p[11], 'imt' => $p[12], 'status_gizi' => $p[13],
                'pemeriksaan_fisik' => $p[14], 'diagnosa_utama_id' => $idIcd($p[15]),
                'diagnosa_sekunder_id' => $p[16] !== null ? $idIcd($p[16]) : null,
                'edukasi' => $p[17], 'tindak_lanjut' => $p[18],
                'dokter_id' => $idDokter($p[19]), 'user_id' => $pmikId, 'created_at' => $p[20],
            ]);
        }

        $resep = [
            [1, 'OBT-001', '3 x 1 tablet sesudah makan', 10, 'Bila demam / nyeri'],
            [1, 'OBT-008', '1 x 1 tablet malam hari', 10, 'Untuk alergi / bersin'],
            [2, 'OBT-005', '1 x 1 tablet pagi hari', 30, 'Rutin diminum'],
            [3, 'OBT-001', '3 x 1 tablet sesudah makan', 10, 'Pereda nyeri'],
            [4, 'OBT-004', '2 x 1 kapsul 30 menit sebelum makan', 14, 'Pagi dan malam'],
            [4, 'OBT-003', '3 x 1 tablet dikunyah 1 jam sebelum makan', 15, 'Saat lambung perih'],
        ];
        foreach ($resep as $r) {
            $this->db->table('pemeriksaan_resep')->insert([
                'pemeriksaan_id' => $r[0], 'obat_id' => $idObat($r[1]),
                'aturan_pakai' => $r[2], 'jumlah' => $r[3], 'catatan' => $r[4],
            ]);
        }

        $tindakan = [
            [1, 'TND-001', 'Pemeriksaan umum dan edukasi', 35000],
            [2, 'TND-002', 'Konsultasi spesialis penyakit dalam', 75000],
            [3, 'TND-004', 'Tambalan sementara & medikasi saluran pulpa', 90000],
            [4, 'TND-001', 'Pemeriksaan fisik abdomen', 35000],
        ];
        foreach ($tindakan as $t) {
            $this->db->table('pemeriksaan_tindakan')->insert([
                'pemeriksaan_id' => $t[0], 'tindakan_id' => $idTnd($t[1]),
                'catatan' => $t[2], 'biaya' => $t[3],
            ]);
        }
    }

    // ----------------------------------------------------------------
    // 10. Registrasi kehamilan & ANC contoh (termasuk ibu risti)
    // ----------------------------------------------------------------
    private function seedKehamilanContoh(): void
    {
        if ($this->countOf('kehamilan') !== 0) {
            return;
        }

        // --- Nur Hidayah (G2P1A0, normal) dengan 3 kali kunjungan ANC ---
        $nur = $this->db->table('pasien')->where('no_rm', 'RM-000002')->get()->getRowArray();
        if ($nur !== null) {
            $hpht = date('Y-m-d', strtotime('-24 weeks'));
            $hpl  = date('Y-m-d', strtotime($hpht . ' +280 days'));

            $this->db->table('kehamilan')->insert([
                'pasien_id' => $nur['id'], 'hpht' => $hpht, 'hpl' => $hpl,
                'gpa_gravida' => 2, 'gpa_para' => 1, 'gpa_abortus' => 0,
                'jarak_kehamilan' => '3 Tahun', 'status_kehamilan' => 'Aktif',
                'skor_risiko_awal' => 2, 'kategori_risiko' => 'KRR',
                'faktor_risiko' => 'Tidak ada faktor risiko berat', 'status_buku_kia' => 'Memiliki',
                'catatan_khusus' => 'Kehamilan kedua berjalan baik, gerakan janin aktif',
            ]);
            $kehamilanId = (int) $this->db->insertID();

            $anc = [
                // tgl, kunjungan_ke, trimester, usia, bb, tb, imt, gizi, td, nadi, suhu, napas, lila, kek, tfu, djj, letak, tt, diberi_tt, fe, hb, tata_laksana, terapi, konseling, skor, kategori, keluhan, diagnosa, tindak_lanjut, tgl_kembali, bidan
                [date('Y-m-d', strtotime($hpht . ' +10 weeks')), 'K1', '1', 10, 52.00, 158.00, 20.83, 'Normal', '110/70', 80, 36.5, 18, 25.0, 'Normal', 'Belum teraba', null, 'Kepala', 'TT3', 0, 30, 12.2, 'Konseling gizi seimbang, pemberian asam folat', 'Asam Folat 1x1, Vitamin B6 1x1', 'Pola istirahat dan nutrisi trimester 1', 2, 'KRR', 'Mual ringan di pagi hari', 'G2P1A0 hamil 10 minggu normal', 'Kontrol Rutin PMB', date('Y-m-d', strtotime(date('Y-m-d', strtotime($hpht . ' +10 weeks')) . ' +8 weeks')), 'Bdn. Hj. Siti Hajar, S.Tr.Keb, Bdn'],
                [date('Y-m-d', strtotime($hpht . ' +18 weeks')), 'K2', '2', 18, 55.50, 158.00, 22.23, 'Normal', '115/75', 82, 36.6, 18, 25.2, 'Normal', '16 cm (2 jari bawah pusat)', 140, 'Kepala', 'TT4', 1, 30, 11.8, 'Pemberian TT4 dan Tablet Tambah Darah', 'Tablet Fe 1x1, Kalk 1x1', 'Tanda bahaya kehamilan dan P4K', 2, 'KRR', 'Tidak ada keluhan berarti', 'G2P1A0 hamil 18 minggu normal', 'Kontrol Rutin PMB', date('Y-m-d', strtotime(date('Y-m-d', strtotime($hpht . ' +18 weeks')) . ' +6 weeks')), 'Bdn. Rina Nurhaliza, A.Md.Keb'],
                [date('Y-m-d', strtotime($hpht . ' +24 weeks')), 'K3', '2', 24, 58.00, 158.00, 23.23, 'Normal', '120/80', 80, 36.5, 20, 25.5, 'Normal', '21 cm (setinggi pusat)', 144, 'Kepala', 'TT Lengkap', 0, 30, 12.0, 'Pemantauan DJJ dan gerak janin', 'Tablet Fe 1x1, Kalsium 1x1', 'Senam hamil mandiri, persiapan ASI eksklusif', 2, 'KRR', 'Pegal di pinggang saat berdiri lama', 'G2P1A0 hamil 24 minggu normal', 'Kontrol Rutin PMB', date('Y-m-d', strtotime('+4 weeks')), 'Bdn. Hj. Siti Hajar, S.Tr.Keb, Bdn'],
            ];

            foreach ($anc as $a) {
                $this->db->table('anc_kunjungan')->insert([
                    'kehamilan_id' => $kehamilanId, 'pasien_id' => $nur['id'],
                    'tgl_periksa' => $a[0], 'kunjungan_ke' => $a[1], 'trimester' => $a[2],
                    'usia_kehamilan' => $a[3], 'bb' => $a[4], 'tb' => $a[5], 'imt' => $a[6],
                    'status_gizi' => $a[7], 'tekanan_darah' => $a[8], 'nadi' => $a[9],
                    'suhu' => $a[10], 'pernapasan' => $a[11], 'lila' => $a[12],
                    'status_kek' => $a[13], 'tfu' => $a[14], 'djj' => $a[15],
                    'letak_janin' => $a[16], 'status_tt' => $a[17], 'diberi_tt' => $a[18],
                    'pemberian_fe' => $a[19], 'hb' => $a[20],
                    'tata_laksana' => $a[21], 'terapi_obat' => $a[22], 'konseling' => $a[23],
                    'skor_kunjungan' => $a[24], 'kategori_risiko' => $a[25],
                    'keluhan' => $a[26], 'diagnosa_kebidanan' => $a[27],
                    'tindak_lanjut' => $a[28], 'tgl_kembali' => $a[29], 'bidan_pemeriksa' => $a[30],
                ]);
            }
        }

        // --- Dewi Lestari: ibu hamil RISTI (prima tua 37 th + KEK) ---
        $dewi = $this->db->table('pasien')->where('nik', '3174086503880008')->get()->getRowArray();
        if ($dewi !== null) {
            $hpht        = date('Y-m-d', strtotime('-33 weeks'));
            $hpl         = date('Y-m-d', strtotime($hpht . ' +280 days'));
            $faktorRisti = json_encode(['Primi tua (Hamil pertama usia ≥ 35 tahun)', 'Kurang Energi Kronis (LILA < 23.5 cm)']);

            $this->db->table('kehamilan')->insert([
                'pasien_id' => $dewi['id'], 'hpht' => $hpht, 'hpl' => $hpl,
                'gpa_gravida' => 1, 'gpa_para' => 0, 'gpa_abortus' => 0,
                'jarak_kehamilan' => 'Hamil Pertama', 'status_kehamilan' => 'Aktif',
                'skor_risiko_awal' => 6, 'kategori_risiko' => 'KRT',
                'faktor_risiko' => $faktorRisti, 'status_buku_kia' => 'Memiliki',
                'catatan_khusus' => 'Ibu hamil risiko tinggi: Usia 37 tahun hamil pertama dan LILA 22.8 cm (KEK). Perlu pengawasan ketat dan rujukan terencana SpOG/RS.',
            ]);
            $kehamilanId = (int) $this->db->insertID();

            $this->db->table('anc_kunjungan')->insert([
                'kehamilan_id' => $kehamilanId, 'pasien_id' => $dewi['id'],
                'tgl_periksa' => date('Y-m-d', strtotime('-2 days')), 'kunjungan_ke' => 'K4',
                'trimester' => '3', 'usia_kehamilan' => 33, 'bb' => 53.00, 'tb' => 153.00,
                'imt' => 22.64, 'status_gizi' => 'Normal', 'tekanan_darah' => '125/80',
                'nadi' => 84, 'suhu' => 36.6, 'pernapasan' => 20, 'lila' => 22.8,
                'status_kek' => 'KEK', 'tfu' => '28 cm (pertengahan pusat-px)', 'djj' => 146,
                'letak_janin' => 'Kepala', 'penurunan_kepala' => 'Konvergen',
                'status_tt' => 'TT Lengkap', 'diberi_tt' => 0, 'pemberian_fe' => 30,
                'hb' => 10.9, 'protein_urin' => 'Negatif', 'gol_darah' => 'B',
                'tata_laksana' => 'Konseling PMT Pemulihan KEK, anjurkan konsultasi SpOG untuk rencana persalinan',
                'terapi_obat' => 'Tablet Fe 2x1, Kalsium 1x1, B Kompleks',
                'konseling' => 'Persiapan persalinan terencana, tanda bahaya trimester 3',
                'skor_kunjungan' => 6, 'kategori_risiko' => 'KRT',
                'faktor_risiko_tercatat' => $faktorRisti,
                'tanda_bahaya' => 'Perhatikan bengkak pada kaki atau pusing',
                'keluhan' => 'Cepat lelah, nafsu makan agak kurang',
                'diagnosa_kebidanan' => 'G1P0A0 hamil 33 minggu dengan KRT (Primi Tua Usia 37 Thn + KEK)',
                'tindak_lanjut' => 'Konsultasi Dokter SpOG',
                'tgl_kembali' => date('Y-m-d', strtotime('+2 weeks')),
                'bidan_pemeriksa' => 'Bdn. Hj. Siti Hajar, S.Tr.Keb, Bdn',
            ]);
        }
    }
}
