<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

/**
 * Tahap 1 — Catatan Audit (Audit Trail, FR-100/SEC-014).
 *
 * Setiap aksi tulis/baca-sensitif pada data pasien & RME dicatat di sini:
 * siapa, kapan, dari IP mana, tabel apa, dan nilai lama/baru (JSON).
 */
class CreateAuditLog extends Migration
{
    public function up(): void
    {
        $this->db->query("CREATE TABLE IF NOT EXISTS `audit_log` (
            `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            `user_id` INT NULL,
            `username` VARCHAR(50) NULL,
            `role` VARCHAR(30) NULL,
            `module` VARCHAR(50) NOT NULL,
            `action` VARCHAR(20) NOT NULL,
            `table_name` VARCHAR(50) NULL,
            `record_id` VARCHAR(30) NULL,
            `description` VARCHAR(255) NULL,
            `old_values` TEXT NULL,
            `new_values` TEXT NULL,
            `ip_address` VARCHAR(45) NULL,
            `user_agent` VARCHAR(255) NULL,
            `created_at` DATETIME NOT NULL,
            KEY `idx_audit_user` (`user_id`),
            KEY `idx_audit_module` (`module`),
            KEY `idx_audit_created` (`created_at`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    }

    public function down(): void
    {
        $this->db->query('DROP TABLE IF EXISTS `audit_log`');
    }
}
