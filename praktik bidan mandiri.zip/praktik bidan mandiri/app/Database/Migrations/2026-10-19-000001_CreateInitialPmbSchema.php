<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

/**
 * Skema awal aplikasi RME Praktik Mandiri Bidan (PMB).
 *
 * Bersifat IDEMPOTEN (CREATE TABLE IF NOT EXISTS + pemeriksaan kolom),
 * sehingga aman dijalankan sebagai baseline pada database legacy
 * `db_rekam_medis` yang dibuat aplikasi versi sebelumnya (PDO murni),
 * maupun pada database baru kosong.
 *
 * Skema mengikuti keadaan AKHIR dari migrasi legacy
 * (config/database.php: initialize_database + check_and_migrate_pmb_tables).
 */
class CreateInitialPmbSchema extends Migration
{
    public function up(): void
    {
        // ------------------------------------------------------------
        // 1. users — identitas pengguna & tenaga (FR-003, FR-008)
        // ------------------------------------------------------------
        $this->db->query("CREATE TABLE IF NOT EXISTS `users` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `username` VARCHAR(50) NOT NULL UNIQUE,
            `password` VARCHAR(255) NOT NULL,
            `nama_lengkap` VARCHAR(100) NOT NULL,
            `role` VARCHAR(30) NOT NULL DEFAULT 'bidan',
            `no_sipb` VARCHAR(50) NULL,
            `no_str` VARCHAR(50) NULL,
            `status` ENUM('aktif','nonaktif') NOT NULL DEFAULT 'aktif',
            `last_login` DATETIME NULL,
            `gagal_login` INT NOT NULL DEFAULT 0,
            `locked_until` DATETIME NULL,
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        // ------------------------------------------------------------
        // 2. poli — unit layanan PMB
        // ------------------------------------------------------------
        $this->db->query("CREATE TABLE IF NOT EXISTS `poli` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `kode_poli` VARCHAR(20) NOT NULL UNIQUE,
            `nama_poli` VARCHAR(100) NOT NULL,
            `keterangan` TEXT,
            `status` ENUM('aktif','nonaktif') NOT NULL DEFAULT 'aktif'
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        // ------------------------------------------------------------
        // 3. dokter / bidan & tenaga kesehatan
        // ------------------------------------------------------------
        $this->db->query("CREATE TABLE IF NOT EXISTS `dokter` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `sip` VARCHAR(50) NOT NULL UNIQUE,
            `nama_dokter` VARCHAR(100) NOT NULL,
            `poli_id` INT NOT NULL,
            `no_hp` VARCHAR(20),
            `status` ENUM('aktif','nonaktif') NOT NULL DEFAULT 'aktif',
            FOREIGN KEY (`poli_id`) REFERENCES `poli`(`id`) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        // ------------------------------------------------------------
        // 4. pasien (identitas ibu, bayi, akseptor KB, dll.)
        // ------------------------------------------------------------
        $this->db->query("CREATE TABLE IF NOT EXISTS `pasien` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `no_rm` VARCHAR(20) NOT NULL UNIQUE,
            `nik` VARCHAR(16) NOT NULL UNIQUE,
            `no_bpjs` VARCHAR(30) NULL,
            `nama_pasien` VARCHAR(100) NOT NULL,
            `jenis_kelamin` ENUM('L','P') NOT NULL,
            `tempat_lahir` VARCHAR(50) NOT NULL,
            `tanggal_lahir` DATE NOT NULL,
            `golongan_darah` ENUM('A','B','AB','O','-') DEFAULT '-',
            `rhesus` VARCHAR(10) DEFAULT '+',
            `alamat` TEXT NOT NULL,
            `no_hp` VARCHAR(20) NOT NULL,
            `agama` VARCHAR(30) DEFAULT 'Islam',
            `pendidikan` VARCHAR(30) DEFAULT 'SMA/Sederajat',
            `pekerjaan` VARCHAR(50) DEFAULT 'Karyawan Swasta',
            `status_perkawinan` ENUM('Menikah','Belum Menikah','Janda') DEFAULT 'Menikah',
            `penanggung_jawab` VARCHAR(100) NULL,
            `suami_nama` VARCHAR(100) NULL,
            `suami_nik` VARCHAR(16) NULL,
            `suami_pekerjaan` VARCHAR(100) NULL,
            `hubungan_pj` VARCHAR(50) NULL,
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        // ------------------------------------------------------------
        // 5. master_icd10 (FR-00A)
        // ------------------------------------------------------------
        $this->db->query("CREATE TABLE IF NOT EXISTS `master_icd10` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `kode` VARCHAR(10) NOT NULL UNIQUE,
            `nama_penyakit` VARCHAR(255) NOT NULL,
            `nama_latin` VARCHAR(255) NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        // ------------------------------------------------------------
        // 6. master_tindakan (FR-00A)
        // ------------------------------------------------------------
        $this->db->query("CREATE TABLE IF NOT EXISTS `master_tindakan` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `kode_tindakan` VARCHAR(20) NOT NULL UNIQUE,
            `nama_tindakan` VARCHAR(150) NOT NULL,
            `kategori` VARCHAR(50) DEFAULT 'Umum',
            `tarif` DECIMAL(12,2) NOT NULL DEFAULT 0.00
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        // ------------------------------------------------------------
        // 7. master_obat (FR-00B)
        // ------------------------------------------------------------
        $this->db->query("CREATE TABLE IF NOT EXISTS `master_obat` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `kode_obat` VARCHAR(20) NOT NULL UNIQUE,
            `nama_obat` VARCHAR(150) NOT NULL,
            `satuan` VARCHAR(50) NOT NULL DEFAULT 'Tablet',
            `sediaan` VARCHAR(50) NULL,
            `stok` INT NOT NULL DEFAULT 0,
            `harga` DECIMAL(12,2) NOT NULL DEFAULT 0.00
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        // ------------------------------------------------------------
        // 8. kunjungan / pendaftaran (FR-013, FR-015)
        // ------------------------------------------------------------
        $this->db->query("CREATE TABLE IF NOT EXISTS `kunjungan` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `no_registrasi` VARCHAR(30) NOT NULL UNIQUE,
            `pasien_id` INT NOT NULL,
            `poli_id` INT NOT NULL,
            `dokter_id` INT NOT NULL,
            `tgl_kunjungan` DATE NOT NULL,
            `no_antrean` VARCHAR(20) NOT NULL,
            `jenis_kunjungan` ENUM('Baru','Lama') NOT NULL DEFAULT 'Baru',
            `cara_bayar` ENUM('Umum','BPJS','Asuransi Lain') NOT NULL DEFAULT 'Umum',
            `keluhan_awal` TEXT NULL,
            `status_pelayanan` ENUM('Menunggu','Sedang Dilayani','Selesai','Batal') NOT NULL DEFAULT 'Menunggu',
            `user_id` INT NULL,
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (`pasien_id`) REFERENCES `pasien`(`id`) ON DELETE CASCADE,
            FOREIGN KEY (`poli_id`) REFERENCES `poli`(`id`) ON DELETE CASCADE,
            FOREIGN KEY (`dokter_id`) REFERENCES `dokter`(`id`) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        // ------------------------------------------------------------
        // 9. pemeriksaan (RME SOAP) (FR-070 s.d. FR-076)
        // ------------------------------------------------------------
        $this->db->query("CREATE TABLE IF NOT EXISTS `pemeriksaan` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `kunjungan_id` INT NOT NULL UNIQUE,
            `tgl_pemeriksaan` DATETIME NOT NULL,
            `keluhan_utama` TEXT NOT NULL,
            `riwayat_penyakit_sekarang` TEXT NULL,
            `riwayat_penyakit_dahulu` TEXT NULL,
            `riwayat_alergi` VARCHAR(255) DEFAULT 'Tidak Ada',
            `tekanan_darah` VARCHAR(20) NOT NULL DEFAULT '120/80',
            `nadi` INT NOT NULL DEFAULT 80,
            `suhu` DECIMAL(4,1) NOT NULL DEFAULT 36.5,
            `pernapasan` INT NOT NULL DEFAULT 20,
            `berat_badan` DECIMAL(5,2) NOT NULL DEFAULT 60.00,
            `tinggi_badan` DECIMAL(5,2) NOT NULL DEFAULT 165.00,
            `imt` DECIMAL(4,2) NOT NULL DEFAULT 22.04,
            `status_gizi` VARCHAR(30) NOT NULL DEFAULT 'Normal',
            `pemeriksaan_fisik` TEXT NULL,
            `diagnosa_utama_id` INT NOT NULL,
            `diagnosa_sekunder_id` INT NULL,
            `edukasi` TEXT NULL,
            `tindak_lanjut` ENUM('Pulang/Sembuh','Kontrol Kembali','Rujuk RS','Rawat Inap') NOT NULL DEFAULT 'Pulang/Sembuh',
            `dokter_id` INT NOT NULL,
            `user_id` INT NULL,
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (`kunjungan_id`) REFERENCES `kunjungan`(`id`) ON DELETE CASCADE,
            FOREIGN KEY (`diagnosa_utama_id`) REFERENCES `master_icd10`(`id`) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        // ------------------------------------------------------------
        // 10. pemeriksaan_tindakan (FR-071)
        // ------------------------------------------------------------
        $this->db->query("CREATE TABLE IF NOT EXISTS `pemeriksaan_tindakan` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `pemeriksaan_id` INT NOT NULL,
            `tindakan_id` INT NOT NULL,
            `catatan` VARCHAR(255) NULL,
            `biaya` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
            FOREIGN KEY (`pemeriksaan_id`) REFERENCES `pemeriksaan`(`id`) ON DELETE CASCADE,
            FOREIGN KEY (`tindakan_id`) REFERENCES `master_tindakan`(`id`) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        // ------------------------------------------------------------
        // 11. pemeriksaan_resep (FR-072)
        // ------------------------------------------------------------
        $this->db->query("CREATE TABLE IF NOT EXISTS `pemeriksaan_resep` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `pemeriksaan_id` INT NOT NULL,
            `obat_id` INT NOT NULL,
            `aturan_pakai` VARCHAR(100) NOT NULL,
            `jumlah` INT NOT NULL DEFAULT 1,
            `catatan` VARCHAR(255) NULL,
            FOREIGN KEY (`pemeriksaan_id`) REFERENCES `pemeriksaan`(`id`) ON DELETE CASCADE,
            FOREIGN KEY (`obat_id`) REFERENCES `master_obat`(`id`) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        // ------------------------------------------------------------
        // 12. pengaturan — profil praktik (FR-009)
        // ------------------------------------------------------------
        $this->db->query("CREATE TABLE IF NOT EXISTS `pengaturan` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `nama_instansi` VARCHAR(150) NOT NULL,
            `alamat_instansi` TEXT NOT NULL,
            `telepon` VARCHAR(30) NOT NULL,
            `email` VARCHAR(100) NOT NULL,
            `pimpinan_nama` VARCHAR(100) NOT NULL,
            `pimpinan_nip` VARCHAR(50) NOT NULL,
            `pmik_nama` VARCHAR(100) NOT NULL,
            `pmik_nip` VARCHAR(50) NOT NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        // ------------------------------------------------------------
        // 13. kehamilan — registrasi kehamilan (FR-020 s.d. FR-024)
        // ------------------------------------------------------------
        $this->db->query("CREATE TABLE IF NOT EXISTS `kehamilan` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `pasien_id` INT NOT NULL,
            `hpht` DATE NOT NULL,
            `hpl` DATE NOT NULL,
            `gpa_gravida` INT NOT NULL DEFAULT 1,
            `gpa_para` INT NOT NULL DEFAULT 0,
            `gpa_abortus` INT NOT NULL DEFAULT 0,
            `jarak_kehamilan` VARCHAR(50) DEFAULT 'Normal (≥ 2 Thn)',
            `status_kehamilan` ENUM('Aktif','Melahirkan','Abortus') NOT NULL DEFAULT 'Aktif',
            `skor_risiko_awal` INT NOT NULL DEFAULT 2,
            `kategori_risiko` ENUM('KRR','KRT','KRST') NOT NULL DEFAULT 'KRR',
            `faktor_risiko` TEXT NULL,
            `status_buku_kia` ENUM('Memiliki','Belum Ada') NOT NULL DEFAULT 'Memiliki',
            `catatan_khusus` TEXT NULL,
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (`pasien_id`) REFERENCES `pasien`(`id`) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        // ------------------------------------------------------------
        // 14. anc_kunjungan — pemeriksaan ANC 10T & Poedji Rochjati
        // ------------------------------------------------------------
        $this->db->query("CREATE TABLE IF NOT EXISTS `anc_kunjungan` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `kehamilan_id` INT NOT NULL,
            `pasien_id` INT NOT NULL,
            `kunjungan_id` INT NULL,
            `tgl_periksa` DATE NOT NULL,
            `kunjungan_ke` VARCHAR(20) NOT NULL,
            `trimester` ENUM('1','2','3') NOT NULL DEFAULT '1',
            `usia_kehamilan` INT NOT NULL,
            `bb` DECIMAL(5,2) NOT NULL DEFAULT 50.00,
            `tb` DECIMAL(5,2) NOT NULL DEFAULT 155.00,
            `imt` DECIMAL(4,2) NULL,
            `status_gizi` VARCHAR(30) DEFAULT 'Normal',
            `tekanan_darah` VARCHAR(20) NOT NULL DEFAULT '120/80',
            `nadi` INT DEFAULT 80,
            `suhu` DECIMAL(4,1) DEFAULT 36.5,
            `pernapasan` INT DEFAULT 20,
            `lila` DECIMAL(4,1) NOT NULL DEFAULT 24.5,
            `status_kek` ENUM('Normal','KEK') DEFAULT 'Normal',
            `tfu` VARCHAR(30) NULL,
            `djj` INT NULL,
            `letak_janin` VARCHAR(50) DEFAULT 'Kepala',
            `penurunan_kepala` VARCHAR(50) DEFAULT 'Konvergen',
            `status_tt` VARCHAR(30) DEFAULT 'TT Lengkap',
            `diberi_tt` TINYINT(1) DEFAULT 0,
            `pemberian_fe` INT DEFAULT 30,
            `hb` DECIMAL(4,1) NULL,
            `protein_urin` VARCHAR(20) DEFAULT 'Negatif',
            `glukosa_urin` VARCHAR(20) DEFAULT 'Negatif',
            `gol_darah` VARCHAR(10) DEFAULT '-',
            `hiv` VARCHAR(30) DEFAULT 'Non Reaktif',
            `sifilis` VARCHAR(30) DEFAULT 'Non Reaktif',
            `hbsag` VARCHAR(30) DEFAULT 'Non Reaktif',
            `tata_laksana` TEXT NULL,
            `terapi_obat` TEXT NULL,
            `konseling` TEXT NULL,
            `skor_kunjungan` INT NOT NULL DEFAULT 2,
            `kategori_risiko` ENUM('KRR','KRT','KRST') NOT NULL DEFAULT 'KRR',
            `faktor_risiko_tercatat` TEXT NULL,
            `tanda_bahaya` VARCHAR(255) NULL,
            `keluhan` TEXT NULL,
            `diagnosa_kebidanan` VARCHAR(255) NOT NULL,
            `tindak_lanjut` ENUM('Kontrol Rutin PMB','Konsultasi Dokter SpOG','Rujuk RS PONEK','Pemantauan Khusus') NOT NULL DEFAULT 'Kontrol Rutin PMB',
            `tgl_kembali` DATE NULL,
            `bidan_pemeriksa` VARCHAR(100) NOT NULL,
            `user_id` INT NULL,
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (`kehamilan_id`) REFERENCES `kehamilan`(`id`) ON DELETE CASCADE,
            FOREIGN KEY (`pasien_id`) REFERENCES `pasien`(`id`) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        // ------------------------------------------------------------
        // Baseline: pastikan kolom hasil migrasi legacy ikut tersedia
        // pada database lama (tabel sudah ada sehingga CREATE dilewati).
        // ------------------------------------------------------------
        $this->ensureRoleVarchar();

        // users: kolom identitas bidan + jejak login (FR-007/FR-008)
        $this->ensureColumn('users', 'no_sipb', 'role', 'VARCHAR(50) NULL');
        $this->ensureColumn('users', 'no_str', 'no_sipb', 'VARCHAR(50) NULL');
        $this->ensureColumn('users', 'last_login', 'status', 'DATETIME NULL');
        $this->ensureColumn('users', 'gagal_login', 'last_login', "INT NOT NULL DEFAULT 0");
        $this->ensureColumn('users', 'locked_until', 'gagal_login', 'DATETIME NULL');

        // pasien: identitas suami & penunjang maternal
        $this->ensureColumn('pasien', 'rhesus', 'golongan_darah', "VARCHAR(10) DEFAULT '+'");
        $this->ensureColumn('pasien', 'status_perkawinan', 'pekerjaan', "ENUM('Menikah','Belum Menikah','Janda') DEFAULT 'Menikah'");
        $this->ensureColumn('pasien', 'suami_nama', 'penanggung_jawab', 'VARCHAR(100) NULL');
        $this->ensureColumn('pasien', 'suami_nik', 'suami_nama', 'VARCHAR(16) NULL');
        $this->ensureColumn('pasien', 'suami_pekerjaan', 'suami_nik', 'VARCHAR(100) NULL');
    }

    public function down(): void
    {
        // Hapus berdasarkan urutan dependensi FK (hanya tabel milik aplikasi ini).
        foreach ([
            'anc_kunjungan', 'kehamilan',
            'pemeriksaan_resep', 'pemeriksaan_tindakan', 'pemeriksaan',
            'kunjungan', 'pengaturan', 'master_obat', 'master_tindakan',
            'master_icd10', 'pasien', 'dokter', 'poli', 'users',
        ] as $table) {
            $this->db->query("DROP TABLE IF EXISTS `{$table}`");
        }
    }

    /**
     * Ubah kolom role dari ENUM legacy menjadi VARCHAR (multi-role PMB).
     */
    private function ensureRoleVarchar(): void
    {
        if (! $this->db->tableExists('users')) {
            return;
        }

        foreach ($this->db->getFieldData('users') as $field) {
            if ($field->name === 'role' && stripos((string) $field->type, 'enum') !== false) {
                $this->db->query("ALTER TABLE `users` MODIFY COLUMN `role` VARCHAR(30) NOT NULL DEFAULT 'bidan'");
                break;
            }
        }
    }

    /**
     * Tambah kolom hanya jika tabel ada dan kolom belum tersedia.
     */
    private function ensureColumn(string $table, string $column, string $after, string $definition): void
    {
        if (! $this->db->tableExists($table)) {
            return;
        }

        $fields = array_map(static fn ($f) => $f->name, $this->db->getFieldData($table));

        if (! in_array($column, $fields, true)) {
            $this->db->query(
                "ALTER TABLE `{$table}` ADD COLUMN `{$column}` {$definition} AFTER `{$after}`"
            );
        }
    }
}
