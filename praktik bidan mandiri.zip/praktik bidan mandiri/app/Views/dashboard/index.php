<?php
/**
 * Dashboard PMB — versi Tahap 0 (fondasi CodeIgniter 4).
 * KPI lengkap (FR-120) diport pada Tahap 1.
 */
$this->extend('layouts/main');
$this->section('content');

$user = get_user();
?>

<!-- Welcome Banner PMB -->
<div class="card-modern p-4 mb-4 text-white position-relative overflow-hidden" style="background: linear-gradient(135deg, #0d9488 0%, #059669 50%, #0284c7 100%);">
    <div class="row align-items-center position-relative" style="z-index: 2;">
        <div class="col-lg-8">
            <span class="badge bg-white text-dark fw-bold mb-2 px-3 py-1 shadow-sm">
                <i class="fa-solid fa-person-breastfeeding me-1 text-success"></i> RME PRAKTIK MANDIRI BIDAN (PMB)
            </span>
            <h2 class="fw-bold mb-2">Selamat Datang, <?= clean($user['nama_lengkap'] ?? '') ?>!</h2>
            <p class="mb-0 opacity-90 fs-6">
                Sistem Rekam Medis Elektronik berstandar <strong>Permenkes No. 24/2022</strong>.
                Migrasi ke <strong>CodeIgniter 4</strong> (<?= APP_VERSION ?>) sedang berjalan bertahap mengikuti roadmap PRD.
            </p>
        </div>
        <div class="col-lg-4 text-lg-end mt-3 mt-lg-0">
            <a href="<?= site_url('pendaftaran/tambah') ?>" class="btn btn-light fw-bold me-2 shadow-sm text-success">
                <i class="fa-solid fa-user-plus me-1"></i> Pasien Baru
            </a>
            <a href="<?= site_url('anc') ?>" class="btn btn-warning fw-bold text-dark shadow-sm">
                <i class="fa-solid fa-person-pregnant me-1"></i> Periksa ANC
            </a>
        </div>
    </div>
</div>

<!-- Status Pengerjaan Bertahap (Roadmap PRD §13) -->
<div class="row g-3 mb-4">
    <div class="col-xl-3 col-sm-6">
        <div class="stat-card" style="border-left: 4px solid #10b981;">
            <div class="stat-icon" style="background: #d1fae5; color: #059669;"><i class="fa-solid fa-check"></i></div>
            <div class="stat-data">
                <div class="stat-value" style="font-size: 1.1rem;">Tahap 0</div>
                <div class="stat-label">Fondasi CodeIgniter 4, Auth, Layout &amp; Database</div>
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-sm-6">
        <div class="stat-card" style="border-left: 4px solid #0284c7;">
            <div class="stat-icon" style="background: #e0f2fe; color: #0284c7;"><i class="fa-solid fa-shield-halved"></i></div>
            <div class="stat-data">
                <div class="stat-value" style="font-size: 1.1rem;">Tahap 1</div>
                <div class="stat-label">Fase 1 PRD: Pendaftaran, ANC, RME SOAP, Audit &amp; Enkripsi</div>
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-sm-6">
        <div class="stat-card" style="border-left: 4px solid #f59e0b;">
            <div class="stat-icon" style="background: #fef3c7; color: #d97706;"><i class="fa-solid fa-baby"></i></div>
            <div class="stat-data">
                <div class="stat-value" style="font-size: 1.1rem;">Tahap 2</div>
                <div class="stat-label">Persalinan &amp; Partograf, Nifas, KB, Imunisasi</div>
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-sm-6">
        <div class="stat-card" style="border-left: 4px solid #64748b;">
            <div class="stat-icon" style="background: #f1f5f9; color: #64748b;"><i class="fa-solid fa-boxes-stacked"></i></div>
            <div class="stat-data">
                <div class="stat-value" style="font-size: 1.1rem;">Tahap 3&ndash;4</div>
                <div class="stat-label">Farmasi, Billing, Manajemen RM, Rujukan &amp; Integrasi</div>
            </div>
        </div>
    </div>
</div>

<div class="card-modern p-4">
    <h5 class="fw-bold mb-3"><i class="fa-solid fa-circle-info text-primary me-2"></i>Informasi Migrasi</h5>
    <p class="mb-2">Aplikasi ini kini berjalan di atas <strong>CodeIgniter 4 (<?= \CodeIgniter\CodeIgniter::CI_VERSION ?>)</strong> dengan:</p>
    <ul class="mb-2">
        <li>Routing RESTful (URL bersih), filter <strong>CSRF</strong>, <strong>Auth</strong>, dan <strong>RBAC</strong> per-role.</li>
        <li>Skema database dikelola melalui <strong>migrasi &amp; seeder</strong> (<code>php spark migrate</code>).</li>
        <li>Kunci enkripsi disimpan di file <code>.env</code> di luar repositori (SEC-005).</li>
    </ul>
    <p class="mb-0 text-muted small">Menu modul yang belum dimigrasikan akan menampilkan halaman &ldquo;Sedang dalam Migrasi&rdquo; beserta tahap pengerjaannya.</p>
</div>

<?php $this->endSection(); ?>
