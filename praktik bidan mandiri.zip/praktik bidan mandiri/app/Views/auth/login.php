<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - <?= APP_NAME ?> | Sistem Rekam Medis</title>
    <meta name="csrf-hash" content="<?= csrf_hash() ?>">
    <!-- Favicon -->
    <link rel="icon" href="https://cdn-icons-png.flaticon.com/512/2966/2966327.png" type="image/png">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <!-- Bootstrap 5.3 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome 6 -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <style>
        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background: linear-gradient(135deg, #0f172a 0%, #1e293b 50%, #0369a1 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 2rem 1rem;
        }
        .login-card {
            width: 100%;
            max-width: 460px;
            background: rgba(255, 255, 255, 0.98);
            border-radius: 20px;
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.4);
            overflow: hidden;
            border: 1px solid rgba(255, 255, 255, 0.2);
        }
        .login-header {
            background: linear-gradient(135deg, #0284c7 0%, #0d9488 100%);
            padding: 2.25rem 2rem;
            color: #fff;
            text-align: center;
            position: relative;
        }
        .brand-icon-large {
            width: 68px;
            height: 68px;
            border-radius: 18px;
            background: rgba(255, 255, 255, 0.2);
            backdrop-filter: blur(8px);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 2.2rem;
            margin: 0 auto 1rem;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.15);
        }
        .login-body {
            padding: 2rem;
        }
        .form-control-custom {
            padding: 0.75rem 1rem;
            border-radius: 10px;
            border: 1.5px solid #e2e8f0;
            font-size: 0.95rem;
        }
        .form-control-custom:focus {
            border-color: #0284c7;
            box-shadow: 0 0 0 4px rgba(2, 132, 199, 0.12);
        }
        .btn-login {
            background: linear-gradient(90deg, #0284c7 0%, #0369a1 100%);
            color: #fff;
            font-weight: 700;
            padding: 0.8rem;
            border-radius: 10px;
            border: none;
            width: 100%;
            font-size: 1rem;
            box-shadow: 0 4px 12px rgba(2, 132, 199, 0.35);
            transition: all 0.2s;
        }
        .btn-login:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(2, 132, 199, 0.45);
            color: #fff;
        }
        .quick-login-badge {
            background: #f1f5f9;
            border: 1px solid #e2e8f0;
            padding: 0.6rem 0.8rem;
            border-radius: 10px;
            cursor: pointer;
            transition: all 0.2s;
            text-align: left;
            width: 100%;
        }
        .quick-login-badge:hover {
            background: #e0f2fe;
            border-color: #38bdf8;
            transform: translateY(-2px);
        }
    </style>
</head>
<body>

<div class="login-card">
    <div class="login-header" style="background: linear-gradient(135deg, #0d9488 0%, #059669 50%, #0284c7 100%);">
        <div class="brand-icon-large">
            <i class="fa-solid fa-person-breastfeeding"></i>
        </div>
        <h3 class="fw-bold mb-1"><?= APP_NAME ?></h3>
        <p class="mb-0 opacity-75 small">Rekam Medis Elektronik Praktik Mandiri Bidan</p>
    </div>

    <div class="login-body">
        <?php $flash = get_flash(); if ($flash): ?>
            <div class="alert alert-<?= clean($flash['type']) ?> alert-dismissible fade show small py-2 mb-3" role="alert">
                <?= $flash['message'] ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <form action="<?= site_url('login') ?>" method="POST" id="loginForm">
            <?= csrf_field() ?>
            <div class="mb-3">
                <label for="username" class="form-label small fw-bold text-secondary">Username</label>
                <div class="input-group">
                    <span class="input-group-text bg-light border-end-0"><i class="fa-solid fa-user text-muted"></i></span>
                    <input type="text" class="form-control form-control-custom border-start-0" id="username" name="username" placeholder="Masukkan username" required autofocus>
                </div>
            </div>

            <div class="mb-4">
                <label for="password" class="form-label small fw-bold text-secondary">Password</label>
                <div class="input-group">
                    <span class="input-group-text bg-light border-end-0"><i class="fa-solid fa-lock text-muted"></i></span>
                    <input type="password" class="form-control form-control-custom border-start-0" id="password" name="password" placeholder="Masukkan password" required>
                </div>
            </div>

            <button type="submit" class="btn btn-login mb-4" style="background: linear-gradient(90deg, #0d9488 0%, #059669 100%);">
                <i class="fa-solid fa-right-to-bracket me-2"></i> Masuk ke Sistem PMB
            </button>
        </form>

        <div class="border-top pt-3">
            <div class="small fw-bold text-muted mb-2 text-center">Pilihan Akun Cepat (Klik untuk masuk):</div>
            <div class="row g-2">
                <div class="col-6">
                    <button type="button" class="quick-login-badge" onclick="fillLogin('bidan_pj', 'bidan123')">
                        <div class="d-flex align-items-center gap-2 mb-1">
                            <i class="fa-solid fa-user-nurse text-success"></i>
                            <strong class="small text-dark">Bidan PJ</strong>
                        </div>
                        <div class="text-muted" style="font-size: 0.72rem;">User: bidan_pj<br>Pass: bidan123</div>
                    </button>
                </div>
                <div class="col-6">
                    <button type="button" class="quick-login-badge" onclick="fillLogin('bidan', 'bidan123')">
                        <div class="d-flex align-items-center gap-2 mb-1">
                            <i class="fa-solid fa-stethoscope text-primary"></i>
                            <strong class="small text-dark">Bidan Pelaksana</strong>
                        </div>
                        <div class="text-muted" style="font-size: 0.72rem;">User: bidan<br>Pass: bidan123</div>
                    </button>
                </div>
                <div class="col-6">
                    <button type="button" class="quick-login-badge" onclick="fillLogin('asisten', 'asisten123')">
                        <div class="d-flex align-items-center gap-2 mb-1">
                            <i class="fa-solid fa-notes-medical text-info"></i>
                            <strong class="small text-dark">Asisten Bidan</strong>
                        </div>
                        <div class="text-muted" style="font-size: 0.72rem;">User: asisten<br>Pass: asisten123</div>
                    </button>
                </div>
                <div class="col-6">
                    <button type="button" class="quick-login-badge" onclick="fillLogin('admin', 'admin123')">
                        <div class="d-flex align-items-center gap-2 mb-1">
                            <i class="fa-solid fa-shield-halved text-danger"></i>
                            <strong class="small text-dark">Admin PMB</strong>
                        </div>
                        <div class="text-muted" style="font-size: 0.72rem;">User: admin<br>Pass: admin123</div>
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
function fillLogin(user, pass) {
    document.getElementById('username').value = user;
    document.getElementById('password').value = pass;
    document.getElementById('loginForm').submit();
}
</script>
</body>
</html>
