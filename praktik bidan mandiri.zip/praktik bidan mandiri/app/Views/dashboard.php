<?php
/**
 * Dashboard utama — Clustera
 * Menampilkan ringkasan status data, grafik Elbow & distribusi klaster,
 * scatter hasil klasterisasi, metrik evaluasi, dan tabel hasil terakhir.
 */

$this->extend('layout/main');

// Data contoh (nantinya diisi dari model/database)
$stats        = $stats ?? [];
$run          = $run ?? [];
$elbow        = $elbow ?? [];
$distribution = $distribution ?? [];
$scatter      = $scatter ?? [];
$features     = $features ?? ['X1', 'X2', 'X3', 'X4'];
$rows         = $rows ?? [];
$metrics      = $metrics ?? [];
$dataset      = $dataset ?? [];
$clusterNames = $clusterNames ?? [];

$clusterBadge = static fn (int $c): string => 'bg-cluster-' . (($c - 1) % 5 + 1);

$this->section('content');
?>
<div class="dash">

    <!-- ================= Sidebar ================= -->
    <aside class="sidebar" id="sidebar">
        <a class="brand" href="<?= site_url('/') ?>">
            <span class="brand-mark"><i class="bi bi-diagram-3-fill"></i></span>
            <span>Clustera<small>Pengolah Data Penelitian</small></span>
        </a>

        <nav class="sidebar-nav">
            <div class="nav-caption">Menu Utama</div>
            <a class="side-link active" href="<?= site_url('dashboard') ?>">
                <i class="bi bi-grid-1x2-fill"></i> Dashboard
            </a>
            <a class="side-link" href="#" title="Modul dalam pengembangan">
                <i class="bi bi-database"></i> Data Penelitian <span class="soon">segera</span>
            </a>
            <a class="side-link" href="#" title="Modul dalam pengembangan">
                <i class="bi bi-funnel"></i> Preprocessing <span class="soon">segera</span>
            </a>

            <div class="nav-caption">Proses K-Means</div>
            <a class="side-link" href="#" title="Modul dalam pengembangan">
                <i class="bi bi-rulers"></i> Normalisasi Data <span class="soon">segera</span>
            </a>
            <a class="side-link" href="#" title="Modul dalam pengembangan">
                <i class="bi bi-graph-up-arrow"></i> Penentuan K (Elbow) <span class="soon">segera</span>
            </a>
            <a class="side-link" href="#" title="Modul dalam pengembangan">
                <i class="bi bi-bullseye"></i> Klasterisasi <span class="soon">segera</span>
            </a>
            <a class="side-link" href="#" title="Modul dalam pengembangan">
                <i class="bi bi-clipboard2-data"></i> Hasil &amp; Evaluasi <span class="soon">segera</span>
            </a>

            <div class="nav-caption">Keluaran</div>
            <a class="side-link" href="#" title="Modul dalam pengembangan">
                <i class="bi bi-file-earmark-pdf"></i> Laporan / Ekspor <span class="soon">segera</span>
            </a>
        </nav>

        <div class="sidebar-foot">
            <div class="user-chip">
                <span class="avatar">MR</span>
                <span>
                    <b>Peneliti</b>
                    <span>Administrator</span>
                </span>
            </div>
            <div><i class="bi bi-code-square me-1"></i> CodeIgniter 4 · K-Means v1.0</div>
        </div>
    </aside>
    <div class="sidebar-overlay" id="sidebarOverlay"></div>

    <!-- ================= Main ================= -->
    <div class="dash-main">

        <!-- Topbar -->
        <header class="topbar">
            <button class="menu-btn" id="menuBtn" type="button" aria-label="Buka sidebar">
                <i class="bi bi-list"></i>
            </button>
            <div>
                <div class="breadcrumb-soft">Beranda / Dashboard</div>
                <h1>Dashboard Utama</h1>
            </div>

            <div class="topbar-actions">
                <span class="search-box">
                    <i class="bi bi-search"></i>
                    <input type="search" id="tableSearch" placeholder="Cari data / klaster…" aria-label="Cari data">
                </span>
                <button class="btn btn-brand" type="button" id="runBtn">
                    <i class="bi bi-play-fill me-1"></i> <span class="btn-label">Jalankan K-Means</span>
                </button>
            </div>
        </header>

        <!-- Content -->
        <main class="content">

            <div class="page-intro">
                <div>
                    <h2>Selamat datang kembali 👋</h2>
                    <p>Ringkasan proses pengolahan data penelitian dan hasil klasterisasi terakhir.</p>
                </div>
                <?php if (! empty($run['status'])): ?>
                    <span class="run-chip"><span class="pulse"></span> <?= esc($run['status']) ?></span>
                <?php endif; ?>
            </div>

            <div class="info-strip">
                <i class="bi bi-info-circle-fill"></i>
                <span>
                    Dataset aktif: <b><?= esc($dataset['name'] ?? 'dataset_contoh_penelitian.csv') ?></b>
                    · <?= esc($dataset['rows'] ?? 150) ?> baris
                    · <?= esc($dataset['cols'] ?? 5) ?> kolom
                    <?php if (! empty($run['time'])): ?>
                        · Proses terakhir <?= esc($run['time']) ?>
                        · Konvergen pada iterasi ke-<?= esc($run['iteration']) ?>
                    <?php endif; ?>
                </span>
            </div>

            <!-- Stat cards -->
            <div class="stats-grid">
                <div class="stat-card s1 glow-card">
                    <div class="stat-icon i-indigo"><i class="bi bi-table"></i></div>
                    <div>
                        <div class="stat-label">Total Data</div>
                        <div class="stat-value"><?= esc($stats['total_data'] ?? 0) ?><span class="trend t-up"><i class="bi bi-arrow-up-right"></i> valid</span></div>
                        <div class="stat-note">baris responden valid</div>
                    </div>
                </div>
                <div class="stat-card s2 glow-card">
                    <div class="stat-icon i-cyan"><i class="bi bi-collection-fill"></i></div>
                    <div>
                        <div class="stat-label">Variabel</div>
                        <div class="stat-value"><?= esc($stats['total_features'] ?? 0) ?><span class="trend t-info"><i class="bi bi-check2-circle"></i> siap</span></div>
                        <div class="stat-note">fitur numerik ternormalisasi</div>
                    </div>
                </div>
                <div class="stat-card s3 glow-card">
                    <div class="stat-icon i-amber"><i class="bi bi-bullseye"></i></div>
                    <div>
                        <div class="stat-label">Jumlah Klaster</div>
                        <div class="stat-value">k = <?= esc($stats['clusters'] ?? 0) ?><span class="trend t-warn"><i class="bi bi-graph-up-arrow"></i> elbow</span></div>
                        <div class="stat-note">optimal via metode Elbow</div>
                    </div>
                </div>
                <div class="stat-card s4 glow-card">
                    <div class="stat-icon i-green"><i class="bi bi-clipboard2-check-fill"></i></div>
                    <div>
                        <div class="stat-label">Silhouette</div>
                        <div class="stat-value"><?= esc($stats['silhouette'] ?? 0) ?><span class="trend t-up"><i class="bi bi-emoji-smile"></i> baik</span></div>
                        <div class="stat-note"><span class="up">Baik</span> · kualitas klaster</div>
                    </div>
                </div>
            </div>

            <!-- Charts: Elbow + Distribusi -->
            <div class="grid-2">
                <section class="panel">
                    <div class="panel-head">
                        <div>
                            <h3>Metode Elbow — SSE vs Jumlah Klaster</h3>
                            <span class="sub">Titik siku (elbow) menentukan k optimal</span>
                        </div>
                        <span class="hv-tag">k optimal = <?= esc($stats['clusters'] ?? 3) ?></span>
                    </div>
                    <div class="panel-body">
                        <div class="chart-box">
                            <canvas id="elbowChart"></canvas>
                            <div class="chart-fallback" id="elbowFallback">
                                Grafik tidak dapat dimuat (library Chart.js tidak tersedia).<br>
                                Pastikan perangkat terhubung internet untuk memuat CDN.
                            </div>
                        </div>
                    </div>
                </section>

                <section class="panel">
                    <div class="panel-head">
                        <div>
                            <h3>Distribusi Data per Klaster</h3>
                            <span class="sub">Jumlah anggota tiap klaster hasil K-Means</span>
                        </div>
                    </div>
                    <div class="panel-body">
                        <div class="chart-box-sm">
                            <canvas id="donutChart"></canvas>
                            <div class="chart-fallback" id="donutFallback">
                                Grafik tidak dapat dimuat (library Chart.js tidak tersedia).
                            </div>
                        </div>
                        <ul class="legend-list">
                            <?php foreach ($distribution as $i => $item): ?>
                                <li>
                                    <i class="dot" style="background:<?= esc($item['color'] ?? '#6366f1') ?>"></i>
                                    <?= esc($item['label'] ?? ('Klaster ' . ($i + 1))) ?>
                                    <b><?= esc($item['value'] ?? 0) ?> data</b>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                </section>
            </div>

            <!-- Scatter + Evaluasi -->
            <div class="grid-2 grid-2-equal">
                <section class="panel">
                    <div class="panel-head">
                        <div>
                            <h3>Sebaran Data Hasil Klasterisasi</h3>
                            <span class="sub">Proyeksi <?= esc($features[0] ?? 'X1') ?> terhadap <?= esc($features[1] ?? 'X2') ?></span>
                        </div>
                        <span class="hv-tag">150 titik data</span>
                    </div>
                    <div class="panel-body">
                        <div class="chart-box">
                            <canvas id="scatterChart"></canvas>
                            <div class="chart-fallback" id="scatterFallback">
                                Grafik tidak dapat dimuat (library Chart.js tidak tersedia).
                            </div>
                        </div>
                    </div>
                </section>

                <section class="panel">
                    <div class="panel-head">
                        <div>
                            <h3>Evaluasi Kualitas Klaster</h3>
                            <span class="sub">Metrik validasi hasil klasterisasi</span>
                        </div>
                    </div>
                    <div class="panel-body">
                        <?php foreach ($metrics as $m): ?>
                            <div class="metric-row">
                                <span><?= esc($m['label']) ?> <span class="metric-tag"><?= esc($m['tag']) ?></span></span>
                                <b><?= esc($m['value']) ?></b>
                            </div>
                        <?php endforeach; ?>

                        <div class="mt-4">
                            <div class="d-flex justify-content-between align-items-center mb-2">
                                <span style="font-size:.82rem;font-weight:700;color:#334155;">Skor Silhouette (skala 0–1)</span>
                                <span style="font-size:.82rem;font-weight:800;color:var(--primary);">
                                    <?= esc($stats['silhouette'] ?? 0) ?>
                                </span>
                            </div>
                            <div class="progress-thin">
                                <span style="width: <?= (int) round(((float) ($stats['silhouette'] ?? 0)) * 100) ?>%"></span>
                            </div>
                            <small class="text-muted d-block mt-2" style="font-size:.76rem;">
                                Interpretasi: 0,41–0,60 = sedang · 0,61–0,80 = baik · 0,81–1,00 = sangat baik.
                            </small>
                        </div>

                        <div class="info-strip mt-4 mb-0" style="background:#f8fafc;border-color:var(--border);color:#475569;">
                            <i class="bi bi-lightbulb-fill" style="color:#f59e0b;"></i>
                            <span>SSE akhir turun hingga <b><?= esc($run['final_sse'] ?? '-') ?></b> setelah
                            <?= esc($run['iteration'] ?? '-') ?> iterasi (perpindahan data = 0).</span>
                        </div>
                    </div>
                </section>
            </div>

            <!-- Tabel hasil -->
            <section class="panel">
                <div class="panel-head">
                    <div>
                        <h3>Hasil Klasterisasi Terakhir</h3>
                        <span class="sub">10 dari <?= esc($stats['total_data'] ?? 0) ?> baris data · nilai setelah normalisasi Min-Max</span>
                    </div>
                    <a class="link-soft" href="#" title="Modul dalam pengembangan">Lihat semua <i class="bi bi-arrow-right"></i></a>
                </div>

                <div class="table-responsive">
                    <table class="table" id="resultTable">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>ID Data</th>
                                <?php foreach ($features as $f): ?>
                                    <th><?= esc($f) ?></th>
                                <?php endforeach; ?>
                                <th>Klaster</th>
                                <th>Nama Klaster</th>
                                <th>Jarak ke Centroid</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($rows as $i => $row): ?>
                                <?php $c = (int) ($row['cluster'] ?? 1); ?>
                                <tr>
                                    <td class="num-cell"><?= $i + 1 ?></td>
                                    <td class="table-id"><?= esc($row['id'] ?? '-') ?></td>
                                    <?php foreach ($features as $f): ?>
                                        <td class="num-cell"><?= esc($row['values'][$f] ?? '-') ?></td>
                                    <?php endforeach; ?>
                                    <td><span class="badge-cluster <?= $clusterBadge($c) ?>">Klaster <?= $c ?></span></td>
                                    <td><?= esc($clusterNames[$c] ?? '-') ?></td>
                                    <td class="num-cell"><?= esc($row['distance'] ?? '-') ?></td>
                                </tr>
                            <?php endforeach; ?>

                            <?php if (empty($rows)): ?>
                                <tr>
                                    <td colspan="<?= 4 + count($features) ?>" class="text-center text-muted py-4">
                                        Belum ada data hasil klasterisasi.
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <div class="table-foot">
                    <span>Menampilkan <?= count($rows) ?> data terakhir</span>
                    <span class="d-flex gap-3">
                        <span><i class="bi bi-circle-fill text-indigo me-1" style="color:#6366f1;font-size:.6rem;"></i> Klaster 1</span>
                        <span><i class="bi bi-circle-fill me-1" style="color:#06b6d4;font-size:.6rem;"></i> Klaster 2</span>
                        <span><i class="bi bi-circle-fill me-1" style="color:#f59e0b;font-size:.6rem;"></i> Klaster 3</span>
                    </span>
                </div>
            </section>

        </main>

        <footer class="dash-footer">
            <span>© <?= date('Y') ?> Clustera — Aplikasi Pengolah Data Penelitian (K-Means)</span>
            <span>Data contoh untuk keperluan demonstrasi dashboard.</span>
        </footer>
    </div>

    <!-- Toast notifikasi -->
    <div class="toast-container position-fixed bottom-0 end-0 p-3">
        <div id="runToast" class="toast align-items-center border-0" role="alert" style="background:#0f172a;color:#fff;">
            <div class="d-flex">
                <div class="toast-body" id="runToastBody">
                    Menjalankan proses K-Means…
                </div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
            </div>
        </div>
    </div>

</div>
<?php $this->endSection(); ?>

<?php $this->section('scripts'); ?>
<script>
    /* ===== Sidebar mobile ===== */
    (function () {
        var sidebar = document.getElementById('sidebar');
        var overlay = document.getElementById('sidebarOverlay');
        var btn = document.getElementById('menuBtn');

        function close() {
            sidebar.classList.remove('open');
            overlay.classList.remove('show');
        }

        if (btn) {
            btn.addEventListener('click', function () {
                sidebar.classList.toggle('open');
                overlay.classList.toggle('show');
            });
        }
        if (overlay) overlay.addEventListener('click', close);
    })();

    /* ===== Pencarian pada tabel hasil ===== */
    (function () {
        var input = document.getElementById('tableSearch');
        var table = document.getElementById('resultTable');
        if (!input || !table) return;

        input.addEventListener('input', function () {
            var q = this.value.toLowerCase().trim();
            table.querySelectorAll('tbody tr').forEach(function (tr) {
                tr.style.display = tr.innerText.toLowerCase().indexOf(q) === -1 ? 'none' : '';
            });
        });
    })();

    /* ===== Toast tombol "Jalankan K-Means" ===== */
    (function () {
        var btn = document.getElementById('runBtn');
        var toastEl = document.getElementById('runToast');
        var body = document.getElementById('runToastBody');
        if (!btn || !toastEl) return;

        btn.addEventListener('click', function () {
            body.textContent = 'Modul klasterisasi belum aktif — dashboard ini menampilkan hasil proses terakhir (data contoh).';
            new bootstrap.Toast(toastEl, {delay: 4000}).show();
        });
    })();

    /* ===== Chart.js ===== */
    (function () {
        if (typeof Chart === 'undefined') {
            document.querySelectorAll('.chart-box canvas, .chart-box-sm canvas')
                .forEach(function (c) { c.style.display = 'none'; });
            document.querySelectorAll('.chart-fallback')
                .forEach(function (f) { f.style.display = 'grid'; });
            return;
        }

        Chart.defaults.font.family = "'Plus Jakarta Sans', sans-serif";
        Chart.defaults.color = '#64748b';

        var elbowData     = <?= json_encode($elbow ?? []) ?>;
        var distData      = <?= json_encode($distribution ?? []) ?>;
        var scatterData   = <?= json_encode($scatter ?? []) ?>;
        var bestK         = <?= json_encode((int) ($stats['clusters'] ?? 3)) ?>;

        /* 1. Elbow (SSE) */
        var elbowCanvas = document.getElementById('elbowChart');
        if (elbowCanvas) {
            new Chart(elbowCanvas, {
                type: 'line',
                data: {
                    labels: elbowData.map(function (d) { return 'k = ' + d.k; }),
                    datasets: [{
                        label: 'SSE',
                        data: elbowData.map(function (d) { return d.sse; }),
                        borderColor: '#4f46e5',
                        backgroundColor: 'rgba(79, 70, 229, .12)',
                        fill: true,
                        tension: .35,
                        borderWidth: 3,
                        pointRadius: elbowData.map(function (d) { return d.k === bestK ? 7 : 4; }),
                        pointBackgroundColor: elbowData.map(function (d) { return d.k === bestK ? '#f59e0b' : '#4f46e5'; }),
                        pointBorderColor: '#fff',
                        pointBorderWidth: 2
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {display: false},
                        tooltip: {
                            callbacks: {
                                afterLabel: function (ctx) {
                                    return ctx.dataIndex + 1 === bestK ? '→ k optimal (titik siku)' : '';
                                }
                            }
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            title: {display: true, text: 'SSE (Sum of Squared Errors)', font: {size: 11, weight: '600'}}
                        },
                        x: {title: {display: true, text: 'Jumlah klaster (k)', font: {size: 11, weight: '600'}}}
                    }
                }
            });
        }

        /* 2. Donut distribusi klaster */
        var donutCanvas = document.getElementById('donutChart');
        if (donutCanvas) {
            new Chart(donutCanvas, {
                type: 'doughnut',
                data: {
                    labels: distData.map(function (d) { return d.label; }),
                    datasets: [{
                        data: distData.map(function (d) { return d.value; }),
                        backgroundColor: distData.map(function (d) { return d.color; }),
                        borderWidth: 3,
                        borderColor: '#fff',
                        hoverOffset: 8
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    cutout: '66%',
                    plugins: {
                        legend: {display: false}
                    }
                }
            });
        }

        /* 3. Scatter hasil klasterisasi */
        var scatterCanvas = document.getElementById('scatterChart');
        if (scatterCanvas) {
            new Chart(scatterCanvas, {
                type: 'scatter',
                data: {
                    datasets: scatterData.map(function (c) {
                        return {
                            label: c.label,
                            data: c.points,
                            backgroundColor: c.color + 'D9',
                            borderColor: c.color,
                            pointRadius: 5,
                            pointHoverRadius: 7
                        };
                    })
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'bottom',
                            labels: {usePointStyle: true, boxWidth: 8, font: {size: 11, weight: '600'}}
                        }
                    },
                    scales: {
                        x: {title: {display: true, text: '<?= esc($features[0] ?? 'X1') ?>', font: {size: 11, weight: '600'}}, min: 0, max: 10},
                        y: {title: {display: true, text: '<?= esc($features[1] ?? 'X2') ?>', font: {size: 11, weight: '600'}}, min: 0, max: 10}
                    }
                }
            });
        }
    })();
</script>
<?php $this->endSection(); ?>
