<?php
/**
 * Template utama (layout) untuk halaman Clustera.
 * Digunakan via template inheritance:
 *   $this->extend('layout/main');
 *   $this->section('content') ... $this->endSection();
 */
$title = $title ?? 'Clustera';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Clustera — aplikasi pengolah data penelitian berbasis algoritma K-Means: preprocessing, normalisasi, penentuan K (Elbow/Silhouette), klasterisasi, dan evaluasi.">
    <title><?= esc($title) ?></title>
    <link rel="icon" href="<?= base_url('favicon.ico') ?>">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="<?= base_url('css/app.css') ?>?v=color4" rel="stylesheet">

    <?= $this->renderSection('head') ?>
</head>
<body>

    <?= $this->renderSection('content') ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>

    <?= $this->renderSection('scripts') ?>
</body>
</html>
