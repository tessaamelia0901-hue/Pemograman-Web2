<?php
/**
 * Template utama (layout) aplikasi RME PMB.
 *
 * View lain memanggil:
 *   $this->extend('layouts/main');
 *   $this->section('content');
 *   ... isi halaman ...
 *   $this->endSection();
 */
echo $this->include('layouts/header');
echo $this->include('layouts/sidebar');
echo $this->include('layouts/navbar');
echo $this->renderSection('content');
echo $this->include('layouts/footer');
