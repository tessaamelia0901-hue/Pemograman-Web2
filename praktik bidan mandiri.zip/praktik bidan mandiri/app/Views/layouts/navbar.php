<?php
/**
 * Navbar atas + pembuka area konten (termasuk pesan flash)
 * Hasil porting dari views/layouts/navbar.php (legacy) ke CodeIgniter 4.
 */
$user = get_user();
?>
<div class="app-main">
    <header class="app-navbar">
        <div class="nav-left">
            <button class="btn-sidebar-toggle" id="sidebarToggle" type="button" title="Buka/Tutup Menu">
                <i class="fa-solid fa-bars"></i>
            </button>
            <h1 class="navbar-page-title mb-0 fs-5">
                <?= isset($pageTitle) ? clean($pageTitle) : 'Sistem Rekam Medis' ?>
            </h1>
        </div>

        <div class="nav-right">
            <div class="live-clock-badge d-none d-md-flex">
                <i class="fa-regular fa-clock"></i>
                <span id="liveClock">Memuat...</span>
            </div>

            <!-- Role demo switcher for easy testing -->
            <div class="dropdown">
                <button class="btn btn-sm btn-outline-secondary dropdown-toggle d-flex align-items-center gap-2" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                    <i class="fa-solid fa-circle-user text-primary"></i>
                    <span class="d-none d-sm-inline fw-semibold"><?= clean($user['nama_lengkap'] ?? '') ?></span>
                </button>
                <ul class="dropdown-menu dropdown-menu-end shadow-sm">
                    <li class="dropdown-header">Login sebagai: <strong><?= strtoupper($user['role'] ?? '') ?></strong></li>
                    <li><hr class="dropdown-divider"></li>
                    <li class="dropdown-header text-muted small">Cepat Ganti Peran (Uji Coba PMB):</li>
                    <li>
                        <a class="dropdown-item d-flex align-items-center gap-2" href="<?= site_url('switch-role?role=bidan_pj') ?>">
                            <i class="fa-solid fa-user-nurse text-success"></i> Bidan PJ / Pemilik
                        </a>
                    </li>
                    <li>
                        <a class="dropdown-item d-flex align-items-center gap-2" href="<?= site_url('switch-role?role=bidan') ?>">
                            <i class="fa-solid fa-stethoscope text-primary"></i> Bidan Pelaksana
                        </a>
                    </li>
                    <li>
                        <a class="dropdown-item d-flex align-items-center gap-2" href="<?= site_url('switch-role?role=asisten') ?>">
                            <i class="fa-solid fa-notes-medical text-info"></i> Asisten Bidan
                        </a>
                    </li>
                    <li>
                        <a class="dropdown-item d-flex align-items-center gap-2" href="<?= site_url('switch-role?role=admin') ?>">
                            <i class="fa-solid fa-shield-halved text-danger"></i> Administrator PMB
                        </a>
                    </li>
                    <li><hr class="dropdown-divider"></li>
                    <li>
                        <a class="dropdown-item text-danger d-flex align-items-center gap-2" href="<?= site_url('logout') ?>">
                            <i class="fa-solid fa-arrow-right-from-bracket"></i> Logout
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </header>

    <main class="app-content">
        <?php $flash = get_flash(); if ($flash): ?>
            <div class="alert alert-<?= clean($flash['type']) ?> alert-dismissible fade show flash-alert mb-4 shadow-sm" role="alert">
                <div class="d-flex align-items-center gap-2">
                    <i class="fa-solid <?= $flash['type'] === 'success' ? 'fa-circle-check text-success' : ($flash['type'] === 'danger' ? 'fa-triangle-exclamation text-danger' : 'fa-circle-info text-info') ?> fs-5"></i>
                    <div><?= $flash['message'] ?></div>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
