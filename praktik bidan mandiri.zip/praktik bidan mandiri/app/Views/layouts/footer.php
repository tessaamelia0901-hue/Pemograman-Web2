    </main>

    <footer class="py-3 px-4 bg-white border-top text-center text-muted small mt-auto no-print">
        <div class="d-flex flex-wrap justify-content-between align-items-center gap-2">
            <div>
                &copy; <?= date('Y') ?> <strong><?= APP_NAME ?></strong> - <?= APP_TITLE ?> (RME).
            </div>
            <div>
                CodeIgniter <?= \CodeIgniter\CodeIgniter::CI_VERSION ?> | Peran: <strong>PMB</strong> | v<?= APP_VERSION ?>
            </div>
        </div>
    </footer>
</div><!-- end .app-main -->
</div><!-- end .app-wrapper -->

<!-- Bootstrap 5.3 JS Bundle -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<!-- Custom Healthcare Script -->
<script src="<?= base_url('assets/js/app.js') ?>"></script>
</body>
</html>
