<?php
/**
 * Sidebar utama aplikasi RME Praktik Mandiri Bidan (PMB)
 * Hasil porting dari views/layouts/sidebar.php (legacy) ke CodeIgniter 4.
 *
 * Menu dikelompokkan mengikuti roadmap PRD (§13): modul yang belum
 * dimigrasikan tetap tampil dengan lencana tahap dan akan menampilkan
 * halaman "Sedang dalam Migrasi".
 */
$user         = get_user();
$roleNames    = [
    'bidan_pj' => 'Bidan PJ / Pemilik',
    'bidan'    => 'Bidan Pelaksana',
    'asisten'  => 'Asisten Bidan',
    'admin'    => 'Administrator',
    'pmik'     => 'Perekam Medis',
];
$roleName     = $roleNames[$user['role'] ?? ''] ?? strtoupper($user['role'] ?? 'Bidan');
?>
<aside class="app-sidebar">
    <div class="sidebar-brand">
        <div class="brand-icon" style="background: linear-gradient(135deg, #0d9488, #059669); color: #fff;">
            <i class="fa-solid fa-person-breastfeeding"></i>
        </div>
        <div>
            <div class="brand-title"><?= APP_SHORT_NAME ?></div>
            <div class="brand-subtitle">Praktik Mandiri Bidan</div>
        </div>
    </div>

    <div class="sidebar-profile">
        <div class="profile-avatar" style="background: linear-gradient(135deg, #0284c7, #0d9488); color: #fff;">
            <?= strtoupper(substr($user['nama_lengkap'] ?? 'B', 0, 2)) ?>
        </div>
        <div class="profile-info">
            <div class="profile-name text-truncate" style="max-width: 160px;" title="<?= clean($user['nama_lengkap'] ?? 'Bidan') ?>"><?= clean($user['nama_lengkap'] ?? 'Bidan') ?></div>
            <span class="profile-badge badge-<?= in_array($user['role'] ?? '', ['bidan_pj', 'bidan']) ? 'primary' : ($user['role'] === 'admin' ? 'danger' : 'info') ?>" style="font-size: 0.72rem;">
                <i class="fa-solid <?= in_array($user['role'] ?? '', ['bidan_pj', 'bidan']) ? 'fa-user-nurse' : ($user['role'] === 'admin' ? 'fa-shield-halved' : 'fa-id-card-clip') ?>"></i>
                <?= $roleName ?>
            </span>
        </div>
    </div>

    <ul class="sidebar-menu">
        <li class="menu-header">Menu Utama</li>
        <li class="menu-item">
            <a href="<?= site_url('dashboard') ?>" class="menu-link <?= url_is('dashboard') ? 'active' : '' ?>">
                <i class="fa-solid fa-chart-pie"></i>
                <span>Dashboard PMB</span>
            </a>
        </li>

        <li class="menu-header">Pelayanan Kesehatan Ibu &amp; Anak (KIA)</li>
        <li class="menu-item">
            <a href="<?= site_url('anc') ?>" class="menu-link <?= url_is('anc*') ? 'active' : '' ?>" style="border-left: 3px solid #10b981;">
                <i class="fa-solid fa-person-pregnant text-emerald"></i>
                <span class="fw-semibold">Pemeriksaan ANC (10T)</span>
                <span class="badge bg-success ms-auto" style="font-size: 0.68rem;">T1</span>
            </a>
        </li>
        <li class="menu-item">
            <a href="<?= site_url('pendaftaran') ?>" class="menu-link <?= url_is('pendaftaran*') ? 'active' : '' ?>">
                <i class="fa-solid fa-hospital-user"></i>
                <span>Data Pasien &amp; Ibu Hamil</span>
            </a>
        </li>
        <li class="menu-item">
            <a href="<?= site_url('pendaftaran/tambah') ?>" class="menu-link <?= url_is('pendaftaran/tambah*') ? 'active' : '' ?>">
                <i class="fa-solid fa-user-plus"></i>
                <span>Daftar Pasien Baru</span>
            </a>
        </li>
        <li class="menu-item">
            <a href="<?= site_url('pendaftaran/antrean') ?>" class="menu-link <?= url_is('pendaftaran/antrean*') ? 'active' : '' ?>">
                <i class="fa-solid fa-ticket"></i>
                <span>Antrean Pelayanan PMB</span>
            </a>
        </li>
        <li class="menu-item">
            <a href="<?= site_url('pelayanan') ?>" class="menu-link <?= url_is('pelayanan*') ? 'active' : '' ?>">
                <i class="fa-solid fa-stethoscope"></i>
                <span>Pelayanan Umum &amp; RME</span>
            </a>
        </li>

        <li class="menu-header">Persalinan, Nifas, KB &amp; Anak</li>
        <li class="menu-item">
            <a href="<?= site_url('persalinan') ?>" class="menu-link <?= url_is('persalinan*') ? 'active' : '' ?>">
                <i class="fa-solid fa-baby-cutting"></i>
                <span>Persalinan &amp; Partograf</span>
                <span class="badge bg-warning text-dark ms-auto" style="font-size: 0.68rem;">T2</span>
            </a>
        </li>
        <li class="menu-item">
            <a href="<?= site_url('nifas') ?>" class="menu-link <?= url_is('nifas*') ? 'active' : '' ?>">
                <i class="fa-solid fa-hands-holding-child"></i>
                <span>Nifas &amp; Bayi Baru Lahir</span>
                <span class="badge bg-warning text-dark ms-auto" style="font-size: 0.68rem;">T2</span>
            </a>
        </li>
        <li class="menu-item">
            <a href="<?= site_url('kb') ?>" class="menu-link <?= url_is('kb*') ? 'active' : '' ?>">
                <i class="fa-solid fa-venus"></i>
                <span>KB &amp; Kesehatan Reproduksi</span>
                <span class="badge bg-warning text-dark ms-auto" style="font-size: 0.68rem;">T2</span>
            </a>
        </li>
        <li class="menu-item">
            <a href="<?= site_url('imunisasi') ?>" class="menu-link <?= url_is('imunisasi*') ? 'active' : '' ?>">
                <i class="fa-solid fa-syringe"></i>
                <span>Imunisasi &amp; Tumbuh Kembang</span>
                <span class="badge bg-warning text-dark ms-auto" style="font-size: 0.68rem;">T2</span>
            </a>
        </li>

        <li class="menu-header">Laporan &amp; Register Kohort</li>
        <li class="menu-item">
            <a href="<?= site_url('laporan_layanan') ?>" class="menu-link <?= url_is('laporan_layanan*') ? 'active' : '' ?>">
                <i class="fa-solid fa-book-bookmark"></i>
                <span>Register &amp; Kunjungan</span>
            </a>
        </li>
        <li class="menu-item">
            <a href="<?= site_url('laporan_pasien') ?>" class="menu-link <?= url_is('laporan_pasien*') ? 'active' : '' ?>">
                <i class="fa-solid fa-chart-line"></i>
                <span>Morbiditas &amp; Demografi</span>
            </a>
        </li>

        <li class="menu-header">Manajemen RM, Logistik &amp; Keuangan</li>
        <li class="menu-item">
            <a href="<?= site_url('rm') ?>" class="menu-link <?= url_is('rm*') ? 'active' : '' ?>">
                <i class="fa-solid fa-folder-open"></i>
                <span>Manajemen Rekam Medis</span>
                <span class="badge bg-info text-dark ms-auto" style="font-size: 0.68rem;">T3</span>
            </a>
        </li>
        <li class="menu-item">
            <a href="<?= site_url('farmasi') ?>" class="menu-link <?= url_is('farmasi*') ? 'active' : '' ?>">
                <i class="fa-solid fa-boxes-stacked"></i>
                <span>Farmasi, Vaksin &amp; Stok</span>
                <span class="badge bg-info text-dark ms-auto" style="font-size: 0.68rem;">T3</span>
            </a>
        </li>
        <li class="menu-item">
            <a href="<?= site_url('kasir') ?>" class="menu-link <?= url_is('kasir*') ? 'active' : '' ?>">
                <i class="fa-solid fa-cash-register"></i>
                <span>Billing &amp; Kasir</span>
                <span class="badge bg-info text-dark ms-auto" style="font-size: 0.68rem;">T3</span>
            </a>
        </li>
        <li class="menu-item">
            <a href="<?= site_url('rujukan') ?>" class="menu-link <?= url_is('rujukan*') ? 'active' : '' ?>">
                <i class="fa-solid fa-truck-medical"></i>
                <span>Rujukan &amp; Rujuk Balik</span>
                <span class="badge bg-secondary ms-auto" style="font-size: 0.68rem;">T4</span>
            </a>
        </li>

        <?php if (is_admin() || is_bidan_pj()): ?>
        <li class="menu-header">Master Data &amp; Pengaturan</li>
        <li class="menu-item">
            <a href="<?= site_url('master/poli') ?>" class="menu-link <?= url_is('master/poli*') ? 'active' : '' ?>">
                <i class="fa-solid fa-hospital"></i>
                <span>Unit Layanan PMB</span>
            </a>
        </li>
        <li class="menu-item">
            <a href="<?= site_url('master/dokter') ?>" class="menu-link <?= url_is('master/dokter*') ? 'active' : '' ?>">
                <i class="fa-solid fa-user-nurse"></i>
                <span>Data Bidan &amp; Nakes</span>
            </a>
        </li>
        <li class="menu-item">
            <a href="<?= site_url('master/icd10') ?>" class="menu-link <?= url_is('master/icd10*') ? 'active' : '' ?>">
                <i class="fa-solid fa-book-medical"></i>
                <span>ICD-10 Kebidanan</span>
            </a>
        </li>
        <li class="menu-item">
            <a href="<?= site_url('master/tindakan') ?>" class="menu-link <?= url_is('master/tindakan*') ? 'active' : '' ?>">
                <i class="fa-solid fa-hand-holding-medical"></i>
                <span>Tarif &amp; Tindakan Kebidanan</span>
            </a>
        </li>
        <li class="menu-item">
            <a href="<?= site_url('master/obat') ?>" class="menu-link <?= url_is('master/obat*') ? 'active' : '' ?>">
                <i class="fa-solid fa-pills"></i>
                <span>Obat &amp; Vaksin</span>
            </a>
        </li>
        <li class="menu-item">
            <a href="<?= site_url('master/users') ?>" class="menu-link <?= url_is('master/users*') ? 'active' : '' ?>">
                <i class="fa-solid fa-users-gear"></i>
                <span>Pengguna &amp; Hak Akses</span>
            </a>
        </li>
        <li class="menu-item">
            <a href="<?= site_url('master/pengaturan') ?>" class="menu-link <?= url_is('master/pengaturan*') ? 'active' : '' ?>">
                <i class="fa-solid fa-id-card"></i>
                <span>Profil Praktik Bidan (PMB)</span>
            </a>
        </li>
        <?php endif; ?>

        <?php if (is_admin() || is_bidan_pj()): ?>
        <li class="menu-header">Keamanan &amp; Audit</li>
        <li class="menu-item">
            <a href="<?= site_url('audit') ?>" class="menu-link <?= url_is('audit*') ? 'active' : '' ?>">
                <i class="fa-solid fa-clipboard-list"></i>
                <span>Catatan Audit (Log)</span>
                <span class="badge bg-success ms-auto" style="font-size: 0.68rem;">T1</span>
            </a>
        </li>
        <?php endif; ?>

        <li class="menu-header">Akun</li>
        <li class="menu-item">
            <a href="<?= site_url('logout') ?>" class="menu-link text-danger" onclick="return confirm('Apakah Anda yakin ingin logout?')">
                <i class="fa-solid fa-right-from-bracket"></i>
                <span>Keluar (Logout)</span>
            </a>
        </li>
    </ul>
</aside>
