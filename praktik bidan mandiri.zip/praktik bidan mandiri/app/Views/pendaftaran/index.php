<?php
/**
 * Data Pasien & Pencarian — porting views/pendaftaran/index.php ke CI4.
 *
 * @var array<int, array<string, mixed>> $pasienList
 * @var string                           $search
 */
$this->extend('layouts/main');
$this->section('content');
?>

<div class="card-modern mb-4">
    <div class="card-header-modern">
        <div>
            <h3 class="card-title-modern">
                <i class="fa-solid fa-address-book"></i> Data Pasien &amp; Pencarian
            </h3>
            <p class="text-muted small mb-0 mt-1">Daftar rekam medis pasien terdaftar di PMB</p>
        </div>
        <div class="d-flex gap-2">
            <a href="<?= site_url('pendaftaran/tambah') ?>" class="btn-modern btn-modern-primary">
                <i class="fa-solid fa-user-plus"></i> Pasien Baru
            </a>
            <a href="<?= site_url('pendaftaran/antrean') ?>" class="btn-modern btn-modern-success">
                <i class="fa-solid fa-ticket"></i> Daftar Antrean
            </a>
        </div>
    </div>

    <div class="p-3 bg-light border-bottom">
        <form action="<?= site_url('pendaftaran') ?>" method="GET" class="row g-2 align-items-center">
            <div class="col-md-9 col-sm-8">
                <div class="input-group">
                    <span class="input-group-text bg-white"><i class="fa-solid fa-magnifying-glass text-muted"></i></span>
                    <input type="text" name="search" class="form-control" placeholder="Cari berdasarkan No. RM, NIK, Nama Pasien, atau No. HP..." value="<?= clean($search ?? '') ?>">
                </div>
            </div>
            <div class="col-md-3 col-sm-4 d-flex gap-2">
                <button type="submit" class="btn btn-primary w-100 fw-bold">
                    <i class="fa-solid fa-filter me-1"></i> Cari Pasien
                </button>
                <?php if (! empty($search ?? '')): ?>
                    <a href="<?= site_url('pendaftaran') ?>" class="btn btn-outline-secondary" title="Reset Pencarian">
                        <i class="fa-solid fa-rotate-left"></i>
                    </a>
                <?php endif; ?>
            </div>
        </form>
    </div>

    <div class="table-responsive">
        <table class="table-modern">
            <thead>
                <tr>
                    <th style="width: 120px;">No. RM</th>
                    <th>NIK &amp; BPJS</th>
                    <th>Nama Pasien</th>
                    <th>Jenis Kelamin</th>
                    <th>Tgl Lahir / Usia</th>
                    <th>No. Telepon</th>
                    <th>Alamat</th>
                    <th class="text-center" style="width: 160px;">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($pasienList)): ?>
                    <tr>
                        <td colspan="8" class="text-center py-5 text-muted">
                            <i class="fa-solid fa-user-slash fs-2 d-block mb-2 opacity-50"></i>
                            Tidak ada data pasien yang cocok.
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($pasienList as $p): ?>
                        <tr>
                            <td>
                                <strong class="badge bg-primary-subtle text-primary border border-primary-subtle px-2 py-1 fs-6">
                                    <?= clean($p['no_rm']) ?>
                                </strong>
                            </td>
                            <td>
                                <div class="fw-semibold text-dark"><?= clean($p['nik']) ?></div>
                                <?php if (! empty($p['no_bpjs'])): ?>
                                    <span class="badge bg-success-subtle text-success-emphasis" style="font-size: 0.72rem;">
                                        BPJS: <?= clean($p['no_bpjs']) ?>
                                    </span>
                                <?php else: ?>
                                    <span class="badge bg-secondary-subtle text-secondary-emphasis" style="font-size: 0.72rem;">Non-BPJS</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <div class="fw-bold fs-6 text-dark"><?= clean($p['nama_pasien']) ?></div>
                                <small class="text-muted">Gol. Darah: <strong><?= clean($p['golongan_darah']) ?></strong></small>
                            </td>
                            <td>
                                <span class="badge <?= $p['jenis_kelamin'] === 'L' ? 'bg-primary-subtle text-primary' : 'bg-danger-subtle text-danger' ?>">
                                    <?= $p['jenis_kelamin'] === 'L' ? 'Laki-laki' : 'Perempuan' ?>
                                </span>
                            </td>
                            <td>
                                <div><?= tgl_indo($p['tanggal_lahir']) ?></div>
                                <span class="badge bg-light text-muted border" style="font-size: 0.72rem;">
                                    <?= hitung_usia($p['tanggal_lahir']) ?>
                                </span>
                            </td>
                            <td><?= clean($p['no_hp']) ?></td>
                            <td style="max-width: 220px; white-space: normal;">
                                <small class="text-secondary"><?= clean($p['alamat']) ?></small>
                            </td>
                            <td class="text-center">
                                <div class="dropdown">
                                    <button class="btn btn-sm btn-outline-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown">
                                        Pilihan
                                    </button>
                                    <ul class="dropdown-menu dropdown-menu-end shadow-sm">
                                        <?php if ($p['jenis_kelamin'] === 'P'): ?>
                                            <li>
                                                <a class="dropdown-item d-flex align-items-center gap-2 text-success fw-semibold" href="<?= site_url('anc/tambah?pasien_id=' . (int) $p['id']) ?>">
                                                    <i class="fa-solid fa-person-pregnant"></i> Periksa ANC (Ibu Hamil)
                                                </a>
                                            </li>
                                            <li><hr class="dropdown-divider"></li>
                                        <?php endif; ?>
                                        <li>
                                            <a class="dropdown-item d-flex align-items-center gap-2 text-primary" href="<?= site_url('pendaftaran/antrean?pasien_id=' . (int) $p['id']) ?>">
                                                <i class="fa-solid fa-ticket"></i> Daftarkan ke Antrean
                                            </a>
                                        </li>
                                        <li>
                                            <a class="dropdown-item d-flex align-items-center gap-2" href="<?= site_url('pendaftaran/kartu/' . (int) $p['id']) ?>" target="_blank">
                                                <i class="fa-solid fa-id-card text-info"></i> Cetak Kartu Pasien
                                            </a>
                                        </li>
                                        <li>
                                            <a class="dropdown-item d-flex align-items-center gap-2" href="<?= site_url('pendaftaran/edit/' . (int) $p['id']) ?>">
                                                <i class="fa-solid fa-pen-to-square text-warning"></i> Edit Identitas
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php $this->endSection(); ?>
