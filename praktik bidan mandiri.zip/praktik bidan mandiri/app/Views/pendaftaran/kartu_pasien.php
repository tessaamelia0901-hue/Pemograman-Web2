<?php
/**
 * Kartu Berobat Pasien (cetak) — porting views/pendaftaran/kartu_pasien.php (CI4).
 *
 * @var array<string, mixed> $pasien
 * @var array<string, mixed>|null $pengaturan
 */
$this->extend('layouts/main');
$this->section('content');

$namaInstansi  = clean($pengaturan['nama_instansi'] ?? 'Praktik Bidan Mandiri');
$alamatInstansi = clean($pengaturan['alamat_instansi'] ?? '');
?>

<div class="row justify-content-center">
    <div class="col-lg-10">
        <div class="card-modern mb-4">
            <div class="card-header-modern">
                <div>
                    <h3 class="card-title-modern">
                        <i class="fa-solid fa-id-card text-info"></i> Kartu Berobat Pasien
                    </h3>
                    <p class="text-muted small mb-0 mt-1">Kartu identitas pasien untuk keperluan kunjungan ke PMB</p>
                </div>
                <div class="d-flex gap-2">
                    <button onclick="window.print()" class="btn-modern btn-modern-info">
                        <i class="fa-solid fa-print"></i> Cetak Kartu
                    </button>
                    <a href="<?= site_url('pendaftaran') ?>" class="btn-sm-modern btn-modern-secondary text-decoration-none">
                        <i class="fa-solid fa-arrow-left me-1"></i> Kembali
                    </a>
                </div>
            </div>

            <div class="card-body-modern">
                <div id="kartuArea" class="row justify-content-center">
                    <div class="col-md-10 col-lg-8">
                        <div class="border rounded shadow-sm bg-white" style="border: 2px solid #0d6efd !important; border-radius: 16px; overflow: hidden;">
                            <!-- Header Kartu -->
                            <div class="bg-primary text-white p-3 text-center">
                                <h5 class="fw-bold mb-1">KARTU BEROBAT</h5>
                                <div class="small"><?= $namaInstansi ?></div>
                                <?php if ($alamatInstansi !== ''): ?>
                                    <div class="small mt-1"><?= $alamatInstansi ?></div>
                                <?php endif; ?>
                            </div>

                            <!-- Body Kartu -->
                            <div class="p-4">
                                <div class="row">
                                    <div class="col-md-4 text-center border-end">
                                        <img src="https://api.qrserver.com/v1/create-qr-code/?size=140x140&data=<?= urlencode($pasien['no_rm']) ?>" class="img-fluid mb-2" style="max-width: 120px;" alt="QR RM">
                                        <div class="small text-muted">No. Rekam Medis</div>
                                        <div class="fw-bold text-primary fs-6"><?= clean($pasien['no_rm']) ?></div>
                                    </div>
                                    <div class="col-md-8 ps-md-4">
                                        <table class="table table-borderless mb-0 small">
                                            <tr>
                                                <td class="text-muted" style="width: 140px;">No. Rekam Medis</td>
                                                <td class="fw-bold">: <?= clean($pasien['no_rm']) ?></td>
                                            </tr>
                                            <tr>
                                                <td class="text-muted">Nama Pasien</td>
                                                <td class="fw-bold">: <?= clean($pasien['nama_pasien']) ?></td>
                                            </tr>
                                            <tr>
                                                <td class="text-muted">Jenis Kelamin</td>
                                                <td>: <?= $pasien['jenis_kelamin'] === 'L' ? 'Laki-laki' : 'Perempuan' ?></td>
                                            </tr>
                                            <tr>
                                                <td class="text-muted">Tgl. Lahir</td>
                                                <td>: <?= tgl_indo($pasien['tanggal_lahir']) ?></td>
                                            </tr>
                                            <tr>
                                                <td class="text-muted">No. HP</td>
                                                <td>: <?= clean($pasien['no_hp']) ?></td>
                                            </tr>
                                            <tr>
                                                <td class="text-muted">Alamat</td>
                                                <td>: <?= clean($pasien['alamat']) ?></td>
                                            </tr>
                                            <tr>
                                                <td class="text-muted">Gol. Darah</td>
                                                <td>: <strong><?= clean($pasien['golongan_darah']) ?></strong></td>
                                            </tr>
                                        </table>
                                    </div>
                                </div>
                            </div>

                            <!-- Footer Kartu -->
                            <div class="bg-light border-top p-3 text-center">
                                <small class="text-muted">Dicetak pada: <strong><?= tgl_indo(date('Y-m-d')) ?> — Pukul <?= date('H:i') ?> WIB</strong></small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $this->endSection(); ?>
