<?php
/**
 * Pendaftaran Antrean Unit Layanan — porting views/pendaftaran/daftar_poli.php (CI4).
 * Pemilih pasien memakai dropdown (selalu valid, tanpa AJAX) agar bisa langsung diinput.
 *
 * @var array<string, mixed>|null        $pasienSelected
 * @var array<int, array<string, mixed>> $pasienList
 * @var array<int, array<string, mixed>> $poliList
 * @var array<int, array<string, mixed>> $dokterList
 */
$this->extend('layouts/main');
$this->section('content');
?>

<div class="row justify-content-center">
    <div class="col-lg-10">
        <div class="card-modern mb-4">
            <div class="card-header-modern">
                <div>
                    <h3 class="card-title-modern">
                        <i class="fa-solid fa-ticket text-success"></i> Pendaftaran Antrean Unit Layanan PMB
                    </h3>
                    <p class="text-muted small mb-0 mt-1">Daftarkan pasien yang sudah terdaftar ke unit layanan pemeriksaan bidan</p>
                </div>
                <a href="<?= site_url('pendaftaran') ?>" class="btn-sm-modern btn-modern-secondary text-decoration-none">
                    <i class="fa-solid fa-arrow-left me-1"></i> Kembali
                </a>
            </div>

            <div class="card-body-modern">
                <form action="<?= site_url('pendaftaran/antrean') ?>" method="POST" id="formAntrean">
                    <?= csrf_field() ?>

                    <div class="row g-3">
                        <!-- Pilih Pasien -->
                        <div class="col-12">
                            <label class="form-label-modern">Pasien <span class="required">*</span></label>
                            <select name="pasien_id" id="pasienId" class="form-select-modern" required>
                                <option value="">-- Pilih Pasien --</option>
                                <?php foreach ($pasienList as $p): ?>
                                    <option value="<?= (int) $p['id'] ?>"
                                        <?= ($pasienSelected !== null && (int) $pasienSelected['id'] === (int) $p['id']) ? 'selected' : '' ?>>
                                        <?= clean($p['no_rm']) ?> — <?= clean($p['nama_pasien']) ?>
                                        (<?= $p['jenis_kelamin'] === 'L' ? 'L' : 'P' ?>, lahir <?= tgl_indo($p['tanggal_lahir']) ?>)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <small class="text-muted">Belum terdaftar? <a href="<?= site_url('pendaftaran/tambah') ?>">Daftarkan pasien baru</a> terlebih dahulu.</small>

                            <?php if ($pasienSelected !== null): ?>
                                <div class="alert alert-success mt-2 mb-0 py-2 small">
                                    <i class="fa-solid fa-circle-check me-1"></i> Pasien terpilih: <strong><?= clean($pasienSelected['nama_pasien']) ?></strong> (<?= clean($pasienSelected['no_rm']) ?>)
                                </div>
                            <?php endif; ?>
                        </div>

                        <!-- Unit Layanan & Bidan -->
                        <div class="col-md-6">
                            <label class="form-label-modern">Unit Layanan Tujuan <span class="required">*</span></label>
                            <select name="poli_id" id="poliId" class="form-select-modern" required>
                                <option value="">-- Pilih Unit Layanan --</option>
                                <?php foreach ($poliList as $poli): ?>
                                    <option value="<?= (int) $poli['id'] ?>"><?= clean($poli['nama_poli']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="col-md-6">
                            <label class="form-label-modern">Bidan / Nakes Pemeriksa <span class="required">*</span></label>
                            <select name="dokter_id" id="dokterId" class="form-select-modern" required>
                                <option value="">-- Pilih Bidan / Nakes Pemeriksa --</option>
                                <?php foreach ($dokterList as $dokter): ?>
                                    <option value="<?= (int) $dokter['id'] ?>">
                                        <?= clean($dokter['nama_dokter']) ?> — <?= clean($dokter['nama_poli'] ?? '') ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <!-- Tipe Pendaftaran & Cara Bayar -->
                        <div class="col-md-6">
                            <label class="form-label-modern">Cara Bayar <span class="required">*</span></label>
                            <select name="cara_bayar" class="form-select-modern" required>
                                <option value="Umum">Umum (Bayar Tunai)</option>
                                <option value="BPJS">BPJS Kesehatan</option>
                            </select>
                        </div>

                        <div class="col-md-6">
                            <label class="form-label-modern">Kebutuhan Mendesak / Keluhan Awal</label>
                            <textarea name="keluhan_awal" class="form-control-modern" rows="2" placeholder="Contoh: Pemeriksaan ANC rutin 10T"></textarea>
                        </div>

                        <!-- Validasi JS -->
                        <div class="col-12">
                            <div class="alert alert-danger d-none" id="errorAntrean">
                                <i class="fa-solid fa-triangle-exclamation me-1"></i>
                                <span id="errorText"></span>
                            </div>
                        </div>
                    </div>

                    <div class="d-flex justify-content-end gap-2 mt-4">
                        <a href="<?= site_url('pendaftaran') ?>" class="btn-modern btn-modern-secondary">Batal</a>
                        <button type="submit" class="btn-modern btn-modern-success" id="btnSubmitAntrean">
                            <i class="fa-solid fa-ticket"></i> Daftarkan ke Antrean
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('formAntrean');
    const pasienIdInput = document.getElementById('pasienId');

    form.addEventListener('submit', function(e) {
        if (!pasienIdInput.value || pasienIdInput.value === '0') {
            e.preventDefault();
            document.getElementById('errorAntrean').classList.remove('d-none');
            document.getElementById('errorText').textContent = 'Anda belum memilih data pasien yang valid.';
        }
    });
});
</script>

<?php $this->endSection(); ?>
