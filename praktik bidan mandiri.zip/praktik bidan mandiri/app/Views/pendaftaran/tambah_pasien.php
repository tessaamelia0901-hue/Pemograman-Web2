<?php
/**
 * Form Pendaftaran Pasien Baru — porting views/pendaftaran/tambah_pasien.php (CI4).
 *
 * @var string                           $autoNoRm
 * @var array<int, array<string, mixed>> $poliList
 * @var array<int, array<string, mixed>> $dokterList
 */
$this->extend('layouts/main');
$this->section('content');
?>

<div class="row justify-content-center">
    <div class="col-lg-10">
        <div class="card-modern mb-4">
            <div class="card-header-modern">
                <div>
                    <h3 class="card-title-modern">
                        <i class="fa-solid fa-user-plus text-primary"></i> Pendaftaran Pasien Baru
                    </h3>
                    <p class="text-muted small mb-0 mt-1">Silakan lengkapi data identitas pasien berikut untuk membuat Rekam Medis (RM)</p>
                </div>
                <a href="<?= site_url('pendaftaran') ?>" class="btn-sm-modern btn-modern-secondary text-decoration-none">
                    <i class="fa-solid fa-arrow-left me-1"></i> Kembali
                </a>
            </div>

            <div class="card-body-modern">
                <form action="<?= site_url('pendaftaran') ?>" method="POST" id="formPasien">
                    <?= csrf_field() ?>

                    <div class="row g-3">
                        <!-- No RM Otomatis & NIK -->
                        <div class="col-md-4">
                            <label class="form-label-modern">No. Rekam Medis (Otomatis)</label>
                            <input type="text" class="form-control-modern bg-light fw-bold text-primary" value="<?= clean($autoNoRm) ?>" readonly>
                            <input type="hidden" name="no_rm" value="<?= clean($autoNoRm) ?>">
                        </div>

                        <div class="col-md-4">
                            <label class="form-label-modern">NIK (KTP 16 Digit) <span class="required">*</span></label>
                            <input type="text" class="form-control-modern" name="nik" maxlength="16" placeholder="3175010105900001" pattern="[0-9]{16}" title="NIK harus terdiri dari 16 digit angka" required>
                        </div>

                        <div class="col-md-4">
                            <label class="form-label-modern">No. Kartu BPJS <small class="text-muted">(bila ada)</small></label>
                            <input type="text" class="form-control-modern" name="no_bpjs" maxlength="16" placeholder="Nomor BPJS">
                        </div>

                        <!-- Nama Pasien & Jenis Kelamin -->
                        <div class="col-md-8">
                            <label class="form-label-modern">Nama Pasien Lengkap <span class="required">*</span></label>
                            <input type="text" class="form-control-modern" name="nama_pasien" placeholder="Nama lengkap sesuai KTP" required>
                        </div>

                        <div class="col-md-4">
                            <label class="form-label-modern">Jenis Kelamin <span class="required">*</span></label>
                            <div class="btn-group w-100" role="group">
                                <input type="radio" class="btn-check" name="jenis_kelamin" id="jkL" value="L" checked>
                                <label class="btn btn-outline-primary" for="jkL">Laki-laki (L)</label>
                                <input type="radio" class="btn-check" name="jenis_kelamin" id="jkP" value="P">
                                <label class="btn btn-outline-primary" for="jkP">Perempuan (P)</label>
                            </div>
                        </div>

                        <!-- Tanggal Lahir -->
                        <div class="col-md-3">
                            <label class="form-label-modern">Tempat Lahir <span class="required">*</span></label>
                            <input type="text" class="form-control-modern" name="tempat_lahir" placeholder="Kota kelahiran" required>
                        </div>

                        <div class="col-md-3">
                            <label class="form-label-modern">Tanggal Lahir <span class="required">*</span></label>
                            <input type="date" class="form-control-modern" name="tanggal_lahir" required>
                        </div>

                        <!-- Golongan Darah & Agama -->
                        <div class="col-md-3">
                            <label class="form-label-modern">Golongan Darah</label>
                            <select class="form-select-modern" name="golongan_darah">
                                <?php foreach (['A', 'B', 'AB', 'O', '-'] as $gd): ?>
                                    <option value="<?= $gd ?>" <?= $gd === 'A' ? 'selected' : '' ?>><?= $gd ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="col-md-3">
                            <label class="form-label-modern">Rhesus</label>
                            <select class="form-select-modern" name="rhesus">
                                <option value="+">Rh+</option>
                                <option value="-">Rh−</option>
                            </select>
                        </div>

                        <div class="col-md-6">
                            <label class="form-label-modern">Agama</label>
                            <select class="form-select-modern" name="agama">
                                <?php foreach (['Islam', 'Kristen', 'Katolik', 'Hindu', 'Buddha', 'Konghucu', 'Lainnya'] as $agm): ?>
                                    <option value="<?= $agm ?>"><?= $agm ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <!-- Alamat & Telepon -->
                        <div class="col-12">
                            <label class="form-label-modern">Alamat Lengkap <span class="required">*</span></label>
                            <textarea class="form-control-modern" name="alamat" rows="2" placeholder="Nama jalan, RT/RW, kelurahan, kecamatan, kota" required></textarea>
                        </div>

                        <div class="col-md-4">
                            <label class="form-label-modern">No. HP / Telepon <span class="required">*</span></label>
                            <input type="tel" class="form-control-modern" name="no_hp" placeholder="0812xxxx" required>
                        </div>

                        <div class="col-md-4">
                            <label class="form-label-modern">Pendidikan</label>
                            <input type="text" class="form-control-modern" name="pendidikan" placeholder="S1, SMA, dll" value="-">
                        </div>

                        <div class="col-md-4">
                            <label class="form-label-modern">Pekerjaan</label>
                            <input type="text" class="form-control-modern" name="pekerjaan" placeholder="Karyawan Swasta, IRT, dll" value="-">
                        </div>

                        <!-- Status Perkawinan -->
                        <div class="col-md-4">
                            <label class="form-label-modern">Status Perkawinan <span class="required">*</span></label>
                            <select class="form-select-modern" name="status_perkawinan" required>
                                <option value="Menikah">Menikah</option>
                                <option value="Belum Menikah">Belum Menikah</option>
                                <option value="Janda">Janda</option>
                            </select>
                        </div>

                        <!-- Penanggung Jawab -->
                        <div class="col-md-4">
                            <label class="form-label-modern">Nama Penanggung Jawab <span class="required">*</span></label>
                            <input type="text" class="form-control-modern" name="penanggung_jawab" placeholder="Nama ayah / suami / wali" required>
                        </div>

                        <div class="col-md-4">
                            <label class="form-label-modern">Hubungan Penanggung Jawab</label>
                            <input type="text" class="form-control-modern" name="hubungan_pj" placeholder="Suami / Ayah / Anak" value="Suami">
                        </div>

                        <hr class="my-3">

                        <!-- Data Suami -->
                        <div class="col-12">
                            <h6 class="fw-bold text-muted"><i class="fa-solid fa-venus-mars me-1"></i> Data Suami (khusus Pasien Perempuan / Istri)</h6>
                        </div>

                        <div class="col-md-4">
                            <label class="form-label-modern">Nama Suami</label>
                            <input type="text" class="form-control-modern" name="suami_nama" placeholder="Nama suami">
                        </div>

                        <div class="col-md-4">
                            <label class="form-label-modern">NIK Suami</label>
                            <input type="text" class="form-control-modern" name="suami_nik" maxlength="16" placeholder="16 digit angka">
                        </div>

                        <div class="col-md-4">
                            <label class="form-label-modern">Pekerjaan Suami</label>
                            <input type="text" class="form-control-modern" name="suami_pekerjaan" placeholder="Pekerjaan suami">
                        </div>

                        <input type="hidden" name="langsung_antre" value="0" id="langsungAntre">

                        <div class="col-12 mt-3 d-none" id="antreanOptions">
                            <div class="card border-success">
                                <div class="card-header bg-success text-white py-2">
                                    <i class="fa-solid fa-ticket"></i> Opsi Langsung Masuk Antrean
                                </div>
                                <div class="card-body">
                                    <div class="row g-3">
                                        <div class="col-md-6">
                                            <label class="form-label-modern">Unit Layanan</label>
                                            <select class="form-select-modern" name="poli_id">
                                                <option value="">-- Pilih Unit Layanan --</option>
                                                <?php foreach ($poliList as $poli): ?>
                                                    <option value="<?= (int) $poli['id'] ?>"><?= clean($poli['nama_poli']) ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>

                                        <div class="col-md-6">
                                            <label class="form-label-modern">Bidan / Nakes Pemeriksa</label>
                                            <select class="form-select-modern" name="dokter_id">
                                                <option value="">-- Pilih Bidan / Nakes --</option>
                                                <?php foreach ($dokterList as $dokter): ?>
                                                    <option value="<?= (int) $dokter['id'] ?>"><?= clean($dokter['nama_dokter']) ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>

                                        <div class="col-md-6">
                                            <label class="form-label-modern">Cara Bayar</label>
                                            <select class="form-select-modern" name="cara_bayar">
                                                <option value="Umum">Umum (Bayar Tunai)</option>
                                                <option value="BPJS">BPJS Kesehatan</option>
                                            </select>
                                        </div>

                                        <div class="col-md-6">
                                            <label class="form-label-modern">Keluhan Awal</label>
                                            <textarea name="keluhan_awal" class="form-control-modern" rows="2" placeholder="Keluhan utama"></textarea>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-12 mt-4 text-end">
                            <a href="<?= site_url('pendaftaran') ?>" class="btn-modern btn-modern-secondary me-2">Batal</a>
                            <button type="button" class="btn-modern btn-modern-warning me-2" id="btnAntreanToggle">
                                <i class="fa-solid fa-ticket"></i> Simpan &amp; Langsung Antrean
                            </button>
                            <button type="submit" class="btn-modern btn-modern-primary">
                                <i class="fa-solid fa-floppy-disk"></i> Simpan Data Pasien
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const btnAntrean = document.getElementById('btnAntreanToggle');
    const hidden = document.getElementById('langsungAntre');
    const opts = document.getElementById('antreanOptions');

    // Klik pertama: tampilkan pilihan antrean. Klik kedua: langsung simpan.
    btnAntrean.addEventListener('click', function() {
        if (hidden.value !== '1') {
            hidden.value = '1';
            opts.classList.remove('d-none');
            btnAntrean.innerHTML = '<i class="fa-solid fa-check"></i> Klik lagi untuk Simpan & Antrean';
            opts.scrollIntoView({ behavior: 'smooth', block: 'center' });
        } else {
            document.getElementById('formPasien').submit();
        }
    });
});
</script>

<?php $this->endSection(); ?>
