<?php
/**
 * Karcis Antrean (cetak) — porting views/pendaftaran/karcis_antrean.php (CI4).
 *
 * @var array<string, mixed> $kunjungan
 * @var array<string, mixed>|null $pengaturan
 */
$this->extend('layouts/main');
$this->section('content');

$namaInstansi = clean($pengaturan['nama_instansi'] ?? 'Praktik Bidan Mandiri');
?>

<div class="row justify-content-center">
    <div class="col-md-8 col-lg-6">
        <div class="card-modern mb-4">
            <div class="card-header-modern">
                <h3 class="card-title-modern">
                    <i class="fa-solid fa-ticket text-warning"></i> Karcis Antrean Pemeriksaan
                </h3>
                <button onclick="window.print()" class="btn-modern btn-modern-warning">
                    <i class="fa-solid fa-print"></i> Cetak Karcis
                </button>
            </div>

            <div class="card-body-modern">
                <div id="karcisArea" class="border rounded shadow-sm mx-auto bg-white" style="max-width: 380px; border: 2px dashed #ffc107 !important; border-radius: 16px; overflow: hidden;">
                    <!-- Header Karcis -->
                    <div class="bg-warning text-dark p-3 text-center">
                        <h6 class="fw-bold mb-1 text-uppercase">Karcis Antrean</h6>
                        <div class="small"><?= $namaInstansi ?></div>
                        <div class="small mt-1">Nomor Antrean Anda</div>
                    </div>

                    <!-- Nomor Antrean Besar -->
                    <div class="text-center py-4 bg-light border-bottom">
                        <div class="display-3 fw-bold text-dark" style="letter-spacing: 3px;">
                            <?= clean($kunjungan['no_antrean']) ?>
                        </div>
                        <div class="mt-2">
                            <span class="badge bg-primary text-white px-3 py-2">
                                No. Reg: <?= clean($kunjungan['no_registrasi']) ?>
                            </span>
                        </div>
                    </div>

                    <!-- Detail Kunjungan -->
                    <div class="p-3 small">
                        <table class="table table-borderless mb-0">
                            <tr>
                                <td class="text-muted" style="width: 130px;">Nama Pasien</td>
                                <td class="fw-bold">: <?= clean($kunjungan['nama_pasien']) ?></td>
                            </tr>
                            <tr>
                                <td class="text-muted">No. RM</td>
                                <td>: <?= clean($kunjungan['no_rm']) ?></td>
                            </tr>
                            <tr>
                                <td class="text-muted">Unit Layanan</td>
                                <td>: <strong><?= clean($kunjungan['nama_poli']) ?></strong></td>
                            </tr>
                            <tr>
                                <td class="text-muted">Bidan Pemeriksa</td>
                                <td>: <?= clean($kunjungan['nama_dokter']) ?></td>
                            </tr>
                            <tr>
                                <td class="text-muted">Tgl Kunjungan</td>
                                <td>: <?= tgl_indo($kunjungan['tgl_kunjungan']) ?></td>
                            </tr>
                            <tr>
                                <td class="text-muted">Cara Bayar</td>
                                <td>: <?= clean($kunjungan['cara_bayar']) ?></td>
                            </tr>
                            <tr>
                                <td class="text-muted">Status</td>
                                <td>: <span class="badge bg-warning text-dark"><?= clean($kunjungan['status_pelayanan']) ?></span></td>
                            </tr>
                        </table>
                    </div>

                    <!-- Petunjuk -->
                    <div class="bg-light border-top p-3">
                        <small class="text-muted">
                            <i class="fa-solid fa-circle-info me-1"></i>
                            <strong>Petunjuk:</strong> Harap menunggu di ruang tunggu. Panggilan antrean akan diumumkan sesuai nomor urut Anda.
                        </small>
                    </div>
                </div>

                <!-- Tombol Aksi -->
                <div class="d-flex justify-content-center gap-2 mt-4">
                    <a href="<?= site_url('pendaftaran') ?>" class="btn-modern btn-modern-secondary">
                        <i class="fa-solid fa-database"></i> Kembali ke Data Pasien
                    </a>
                    <a href="<?= site_url('pendaftaran/antrean') ?>" class="btn-modern btn-modern-success">
                        <i class="fa-solid fa-ticket"></i> Daftar Antrean Baru
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $this->endSection(); ?>
