<?php
/**
 * Form Edit Data Pasien — porting views/pendaftaran/edit_pasien.php ke CI4.
 * Form dilengkapi field rhesus/status perkawinan/suami agar tidak ada
 * kolom yang hilang saat pembaruan (menyesuaikan payload kontroler).
 *
 * @var array<string, mixed> $pasien
 */
$this->extend('layouts/main');
$this->section('content');
?>

<div class="row justify-content-center">
    <div class="col-lg-10">
        <div class="card-modern mb-4">
            <div class="card-header-modern">
                <h3 class="card-title-modern">
                    <i class="fa-solid fa-user-pen text-primary"></i> Edit Data Pasien: <?= clean($pasien['nama_pasien']) ?>
                </h3>
                <a href="<?= site_url('pendaftaran') ?>" class="btn-sm-modern btn-modern-secondary text-decoration-none">
                    <i class="fa-solid fa-arrow-left me-1"></i> Kembali
                </a>
            </div>

            <div class="card-body-modern">
                <form action="<?= site_url('pendaftaran/update') ?>" method="POST">
                    <?= csrf_field() ?>
                    <input type="hidden" name="id" value="<?= (int) $pasien['id'] ?>">

                    <div class="row g-3 mb-4">
                        <div class="col-md-4">
                            <label class="form-label-modern">No. Rekam Medis</label>
                            <input type="text" class="form-control-modern bg-light fw-bold text-primary" value="<?= clean($pasien['no_rm']) ?>" readonly>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label-modern">NIK (KTP) <span class="required">*</span></label>
                            <input type="text" class="form-control-modern" name="nik" value="<?= clean($pasien['nik']) ?>" maxlength="16" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label-modern">No. Kartu BPJS</label>
                            <input type="text" class="form-control-modern" name="no_bpjs" value="<?= clean($pasien['no_bpjs'] ?? '') ?>" placeholder="Bila ada">
                        </div>

                        <div class="col-md-6">
                            <label class="form-label-modern">Nama Pasien <span class="required">*</span></label>
                            <input type="text" class="form-control-modern" name="nama_pasien" value="<?= clean($pasien['nama_pasien']) ?>" required>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label-modern">Jenis Kelamin <span class="required">*</span></label>
                            <select class="form-select-modern" name="jenis_kelamin" required>
                                <option value="L" <?= $pasien['jenis_kelamin'] === 'L' ? 'selected' : '' ?>>Laki-laki (L)</option>
                                <option value="P" <?= $pasien['jenis_kelamin'] === 'P' ? 'selected' : '' ?>>Perempuan (P)</option>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label-modern">Golongan Darah</label>
                            <select class="form-select-modern" name="golongan_darah">
                                <?php foreach (['-', 'A', 'B', 'AB', 'O'] as $gd): ?>
                                    <option value="<?= $gd ?>" <?= $pasien['golongan_darah'] === $gd ? 'selected' : '' ?>><?= $gd ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="col-md-3">
                            <label class="form-label-modern">Rhesus</label>
                            <select class="form-select-modern" name="rhesus">
                                <?php foreach (['+', '-'] as $rh): ?>
                                    <option value="<?= $rh ?>" <?= ($pasien['rhesus'] ?? '+') === $rh ? 'selected' : '' ?>><?= $rh ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-5">
                            <label class="form-label-modern">Tempat Lahir <span class="required">*</span></label>
                            <input type="text" class="form-control-modern" name="tempat_lahir" value="<?= clean($pasien['tempat_lahir']) ?>" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label-modern">Tanggal Lahir <span class="required">*</span></label>
                            <input type="date" class="form-control-modern" name="tanggal_lahir" value="<?= clean($pasien['tanggal_lahir']) ?>" required>
                        </div>

                        <div class="col-md-4">
                            <label class="form-label-modern">No. HP / Telepon <span class="required">*</span></label>
                            <input type="tel" class="form-control-modern" name="no_hp" value="<?= clean($pasien['no_hp']) ?>" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label-modern">Status Perkawinan</label>
                            <select class="form-select-modern" name="status_perkawinan">
                                <?php foreach (['Menikah', 'Belum Menikah', 'Janda'] as $sp): ?>
                                    <option value="<?= $sp ?>" <?= ($pasien['status_perkawinan'] ?? 'Menikah') === $sp ? 'selected' : '' ?>><?= $sp ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label-modern">Agama</label>
                            <select class="form-select-modern" name="agama">
                                <?php foreach (['Islam', 'Kristen', 'Katolik', 'Hindu', 'Buddha', 'Konghucu', 'Lainnya'] as $agm): ?>
                                    <option value="<?= $agm ?>" <?= $pasien['agama'] === $agm ? 'selected' : '' ?>><?= $agm ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="col-12">
                            <label class="form-label-modern">Alamat Lengkap <span class="required">*</span></label>
                            <textarea class="form-control-modern" name="alamat" rows="2" required><?= clean($pasien['alamat']) ?></textarea>
                        </div>

                        <div class="col-md-4">
                            <label class="form-label-modern">Pendidikan</label>
                            <input type="text" class="form-control-modern" name="pendidikan" value="<?= clean($pasien['pendidikan']) ?>">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label-modern">Pekerjaan</label>
                            <input type="text" class="form-control-modern" name="pekerjaan" value="<?= clean($pasien['pekerjaan']) ?>">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label-modern">Nama Penanggung Jawab</label>
                            <input type="text" class="form-control-modern" name="penanggung_jawab" value="<?= clean($pasien['penanggung_jawab'] ?? '') ?>">
                        </div>

                        <div class="col-md-4">
                            <label class="form-label-modern">Hubungan Penanggung Jawab</label>
                            <input type="text" class="form-control-modern" name="hubungan_pj" value="<?= clean($pasien['hubungan_pj'] ?? '') ?>">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label-modern">Nama Suami</label>
                            <input type="text" class="form-control-modern" name="suami_nama" value="<?= clean($pasien['suami_nama'] ?? '') ?>">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label-modern">NIK Suami</label>
                            <input type="text" class="form-control-modern" name="suami_nik" value="<?= clean($pasien['suami_nik'] ?? '') ?>" maxlength="16">
                        </div>

                        <div class="col-md-6">
                            <label class="form-label-modern">Pekerjaan Suami</label>
                            <input type="text" class="form-control-modern" name="suami_pekerjaan" value="<?= clean($pasien['suami_pekerjaan'] ?? '') ?>">
                        </div>
                    </div>

                    <div class="d-flex justify-content-end gap-2">
                        <a href="<?= site_url('pendaftaran') ?>" class="btn-modern btn-modern-secondary">Batal</a>
                        <button type="submit" class="btn-modern btn-modern-primary">
                            <i class="fa-solid fa-floppy-disk"></i> Simpan Perubahan
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php $this->endSection(); ?>
