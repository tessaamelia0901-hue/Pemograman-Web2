<?php
/**
 * Halaman "Sedang dalam Migrasi" — ditangkap oleh route catch-all
 * untuk modul yang belum dipindahkan ke CodeIgniter 4.
 */
$this->extend('layouts/main');
$this->section('content');

$module     = $module ?? '';
$segments   = array_filter(explode('/', trim((string) $module, '/')));
$moduleName = $segments ? strtoupper(implode(' / ', $segments)) : 'MODUL';

// Pemetaan modul -> tahap pengerjaan (roadmap PRD §13)
$stageMap = [
    'pendaftaran'    => ['Tahap 1', 'Fase 1 — Autentikasi, Master Data, Pendaftaran & Pelayanan'],
    'anc'            => ['Tahap 1', 'Fase 1 — Pelayanan Antenatal & Skrining Risti'],
    'pelayanan'      => ['Tahap 1', 'Fase 1 — Rekam Medis Elektronik (SOAP)'],
    'laporan_layanan'=> ['Tahap 1', 'Fase 1 — Laporan Layanan'],
    'laporan_pasien' => ['Tahap 1', 'Fase 1 — Laporan Morbiditas & Demografi'],
    'master'         => ['Tahap 1', 'Fase 1 — Master Data & Manajemen Pengguna'],
    'audit'          => ['Tahap 1', 'Fase 1 — Catatan Audit (Audit Trail)'],
    'persalinan'     => ['Tahap 2', 'Fase 2 — Persalinan & Partograf Elektronik'],
    'nifas'          => ['Tahap 2', 'Fase 2 — Nifas (PNC) & Bayi Baru Lahir'],
    'kb'             => ['Tahap 2', 'Fase 2 — KB & Kesehatan Reproduksi'],
    'imunisasi'      => ['Tahap 2', 'Fase 2 — Imunisasi, Pertumbuhan & Perkembangan'],
    'rm'             => ['Tahap 3', 'Fase 3 — Manajemen Rekam Medis'],
    'farmasi'        => ['Tahap 3', 'Fase 3 — Farmasi, Vaksin & Logistik'],
    'kasir'          => ['Tahap 3', 'Fase 3 — Billing, Paket & Kasir'],
    'rujukan'        => ['Tahap 4', 'Fase 4 — Rujukan, Rujuk Balik & Integrasi'],
];

$key     = $segments[0] ?? '';
$stage   = $stageMap[$key][0] ?? 'Tahap Berikutnya';
$desc    = $stageMap[$key][1] ?? 'Modul ini dijadwalkan pada tahap migrasi berikutnya.';
?>
<div class="card-modern p-5 text-center">
    <div class="mb-3">
        <i class="fa-solid fa-person-digging" style="font-size: 3.2rem; color: #f59e0b;"></i>
    </div>
    <h3 class="fw-bold mb-2">Modul <span class="text-primary"><?= clean($moduleName) ?></span> Sedang dalam Migrasi</h3>
    <p class="text-muted mb-4">
        Pemindahan aplikasi ke CodeIgniter 4 dikerjakan <strong>bertahap</strong> mengikuti roadmap PRD.
        Modul ini dijadwalkan pada <span class="badge bg-warning text-dark"><?= clean($stage) ?></span>
        &mdash; <?= clean($desc) ?>.
    </p>

    <div class="row justify-content-center g-3 mb-4">
        <div class="col-md-3">
            <div class="border rounded p-3 h-100 bg-light">
                <div class="fw-bold text-success"><i class="fa-solid fa-check-circle me-1"></i>Tahap 0</div>
                <small class="text-muted">Fondasi CI4, Auth, Layout, Database</small>
            </div>
        </div>
        <div class="col-md-3">
            <div class="border rounded p-3 h-100 bg-light">
                <div class="fw-bold text-primary"><i class="fa-solid fa-shield-halved me-1"></i>Tahap 1</div>
                <small class="text-muted">Fase 1 PRD + Audit &amp; Enkripsi</small>
            </div>
        </div>
        <div class="col-md-3">
            <div class="border rounded p-3 h-100 bg-light">
                <div class="fw-bold text-warning"><i class="fa-solid fa-baby me-1"></i>Tahap 2</div>
                <small class="text-muted">Persalinan, Nifas, KB, Imunisasi</small>
            </div>
        </div>
        <div class="col-md-3">
            <div class="border rounded p-3 h-100 bg-light">
                <div class="fw-bold text-secondary"><i class="fa-solid fa-truck-medical me-1"></i>Tahap 3&ndash;4</div>
                <small class="text-muted">Logistik, Billing, RM, Rujukan</small>
            </div>
        </div>
    </div>

    <a href="<?= site_url('dashboard') ?>" class="btn btn-primary fw-bold">
        <i class="fa-solid fa-arrow-left me-1"></i> Kembali ke Dashboard
    </a>
</div>
<?php $this->endSection(); ?>
