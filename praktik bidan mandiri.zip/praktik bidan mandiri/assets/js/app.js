/**
 * SIM-RM Medika - Client Side Utilities & Interactive Logic
 * File: assets/js/app.js
 */

document.addEventListener('DOMContentLoaded', function () {
    // 1. Live Clock in Navbar
    const liveClockEl = document.getElementById('liveClock');
    if (liveClockEl) {
        function updateClock() {
            const now = new Date();
            const options = {
                weekday: 'long',
                year: 'numeric',
                month: 'short',
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit',
                second: '2-digit',
                hour12: false
            };
            liveClockEl.textContent = now.toLocaleDateString('id-ID', options);
        }
        updateClock();
        setInterval(updateClock, 1000);
    }

    // 2. Mobile Sidebar Toggle
    const toggleBtn = document.getElementById('sidebarToggle');
    const sidebar = document.querySelector('.app-sidebar');
    const backdrop = document.getElementById('sidebarBackdrop');

    if (toggleBtn && sidebar) {
        toggleBtn.addEventListener('click', function () {
            sidebar.classList.toggle('show');
            if (backdrop) backdrop.classList.toggle('show');
        });
    }

    if (backdrop && sidebar) {
        backdrop.addEventListener('click', function () {
            sidebar.classList.remove('show');
            backdrop.classList.remove('show');
        });
    }

    // 3. Automatic IMT (Indeks Massa Tubuh) Calculator
    const bbInput = document.getElementById('berat_badan');
    const tbInput = document.getElementById('tinggi_badan');
    const imtInput = document.getElementById('imt');
    const statusGiziInput = document.getElementById('status_gizi');

    function hitungIMT() {
        if (!bbInput || !tbInput || !imtInput || !statusGiziInput) return;

        const bb = parseFloat(bbInput.value);
        const tb = parseFloat(tbInput.value);

        if (bb > 0 && tb > 0) {
            const tbMeter = tb / 100;
            const imt = bb / (tbMeter * tbMeter);
            const imtRounded = imt.toFixed(2);
            imtInput.value = imtRounded;

            let status = 'Normal';
            if (imt < 18.5) {
                status = 'Kurus / Berat Badan Kurang';
            } else if (imt >= 18.5 && imt < 25.0) {
                status = 'Normal';
            } else if (imt >= 25.0 && imt < 30.0) {
                status = 'Gemuk / Overweight';
            } else {
                status = 'Obesitas';
            }
            statusGiziInput.value = status;
        }
    }

    if (bbInput && tbInput) {
        bbInput.addEventListener('input', hitungIMT);
        tbInput.addEventListener('input', hitungIMT);
    }

    // 4. Quick Table Filter
    const searchInputs = document.querySelectorAll('[data-table-search]');
    searchInputs.forEach(input => {
        const targetTableSelector = input.getAttribute('data-table-search');
        const targetTable = document.querySelector(targetTableSelector);

        if (targetTable) {
            input.addEventListener('keyup', function () {
                const term = this.value.toLowerCase().trim();
                const rows = targetTable.querySelectorAll('tbody tr');

                rows.forEach(row => {
                    const text = row.textContent.toLowerCase();
                    row.style.display = text.indexOf(term) > -1 ? '' : 'none';
                });
            });
        }
    });

    // 5. Dynamic Tindakan Rows
    const btnAddTindakan = document.getElementById('btnAddTindakan');
    const containerTindakan = document.getElementById('containerTindakan');

    if (btnAddTindakan && containerTindakan) {
        btnAddTindakan.addEventListener('click', function () {
            const template = document.getElementById('rowTindakanTemplate');
            if (template) {
                const clone = template.content.cloneNode(true);
                containerTindakan.appendChild(clone);
            }
        });

        containerTindakan.addEventListener('click', function (e) {
            if (e.target.closest('.btn-remove-row')) {
                e.target.closest('.row-tindakan').remove();
            }
        });
    }

    // 6. Dynamic Resep Obat Rows
    const btnAddObat = document.getElementById('btnAddObat');
    const containerObat = document.getElementById('containerObat');

    if (btnAddObat && containerObat) {
        btnAddObat.addEventListener('click', function () {
            const template = document.getElementById('rowObatTemplate');
            if (template) {
                const clone = template.content.cloneNode(true);
                containerObat.appendChild(clone);
            }
        });

        containerObat.addEventListener('click', function (e) {
            if (e.target.closest('.btn-remove-row')) {
                e.target.closest('.row-obat').remove();
            }
        });
    }
});

// Global Print Trigger
function printPage() {
    window.print();
}
