<?php

namespace App\Controllers;

/**
 * Home — halaman utama aplikasi Clustera.
 *
 * - index()     : landing page
 * - dashboard() : dashboard utama (data contoh, siap diganti
 *                 dengan model/database pada tahap berikutnya)
 */
class Home extends BaseController
{
    /**
     * Landing page.
     */
    public function index(): string
    {
        return view('landing', [
            'title' => 'Clustera — Aplikasi Pengolah Data Penelitian (K-Means)',
        ]);
    }

    /**
     * Dashboard utama.
     */
    public function dashboard(): string
    {
        $data = [
            'title' => 'Dashboard Utama — Clustera',

            // Dataset aktif (contoh)
            'dataset' => [
                'name' => 'dataset_contoh_penelitian.csv',
                'rows' => 150,
                'cols' => 5,
            ],

            // Ringkasan statistik
            'stats' => [
                'total_data'    => 150,
                'total_features' => 5,
                'clusters'      => 3,
                'silhouette'    => 0.62,
            ],

            // Proses terakhir
            'run' => [
                'status'     => 'Proses terakhir berhasil',
                'time'       => '22 Sep 2026, 14:32',
                'iteration'  => 12,
                'final_sse'  => 2.01,
            ],

            // Hasil metode Elbow (SSE per k)
            'elbow' => [
                ['k' => 1, 'sse' => 5.12],
                ['k' => 2, 'sse' => 3.24],
                ['k' => 3, 'sse' => 2.01],
                ['k' => 4, 'sse' => 1.47],
                ['k' => 5, 'sse' => 1.18],
                ['k' => 6, 'sse' => 0.99],
                ['k' => 7, 'sse' => 0.88],
                ['k' => 8, 'sse' => 0.79],
            ],

            // Distribusi anggota klaster
            'distribution' => [
                ['label' => 'Klaster 1 — Rendah', 'value' => 48, 'color' => '#6366f1'],
                ['label' => 'Klaster 2 — Sedang', 'value' => 61, 'color' => '#06b6d4'],
                ['label' => 'Klaster 3 — Tinggi', 'value' => 41, 'color' => '#f59e0b'],
            ],

            // Nama klaster berdasar nomornya
            'clusterNames' => [
                1 => 'Rendah',
                2 => 'Sedang',
                3 => 'Tinggi',
            ],

            // Label variabel
            'features' => ['X1', 'X2', 'X3', 'X4'],

            // Sebaran data per klaster (untuk scatter chart, skala 0–10)
            'scatter' => [
                [
                    'label'  => 'Klaster 1 — Rendah',
                    'color'  => '#6366f1',
                    'points' => [
                        [2.1, 7.8], [2.6, 8.4], [1.8, 7.1], [2.9, 8.9],
                        [2.4, 7.5], [1.6, 8.6], [3.1, 7.9], [2.2, 9.2],
                        [1.9, 8.1], [2.7, 7.2], [3.4, 8.7], [2.0, 6.9],
                    ],
                ],
                [
                    'label'  => 'Klaster 2 — Sedang',
                    'color'  => '#06b6d4',
                    'points' => [
                        [5.2, 4.6], [6.1, 5.4], [4.8, 5.1], [5.7, 4.2],
                        [6.4, 5.9], [5.0, 5.8], [5.9, 6.3], [4.5, 4.4],
                        [6.7, 4.8], [5.4, 5.2], [4.9, 6.5], [6.0, 4.0],
                    ],
                ],
                [
                    'label'  => 'Klaster 3 — Tinggi',
                    'color'  => '#f59e0b',
                    'points' => [
                        [8.1, 2.0], [8.8, 2.9], [7.6, 2.4], [9.2, 1.8],
                        [8.5, 3.3], [7.9, 1.4], [9.0, 2.6], [8.3, 2.2],
                        [7.4, 3.1], [8.9, 1.6], [9.4, 3.0], [8.0, 2.7],
                    ],
                ],
            ],

            // Metrik evaluasi
            'metrics' => [
                ['label' => 'Silhouette Score', 'value' => '0.62', 'tag' => 'Baik'],
                ['label' => 'Davies-Bouldin Index', 'value' => '0.74', 'tag' => 'Rendah = baik'],
                ['label' => 'SSE Akhir', 'value' => '2.01', 'tag' => 'Konvergen'],
                ['label' => 'Iterasi Konvergen', 'value' => '12', 'tag' => 'Efisien'],
            ],

            // 10 baris hasil klasterisasi terakhir (nilai ternormalisasi)
            'rows' => [
                ['id' => 'RESP-001', 'values' => ['X1' => '0.21', 'X2' => '0.78', 'X3' => '0.64', 'X4' => '0.32'], 'cluster' => 1, 'distance' => 0.184],
                ['id' => 'RESP-002', 'values' => ['X1' => '0.26', 'X2' => '0.84', 'X3' => '0.71', 'X4' => '0.28'], 'cluster' => 1, 'distance' => 0.152],
                ['id' => 'RESP-003', 'values' => ['X1' => '0.55', 'X2' => '0.46', 'X3' => '0.52', 'X4' => '0.58'], 'cluster' => 2, 'distance' => 0.207],
                ['id' => 'RESP-004', 'values' => ['X1' => '0.83', 'X2' => '0.22', 'X3' => '0.18', 'X4' => '0.81'], 'cluster' => 3, 'distance' => 0.163],
                ['id' => 'RESP-005', 'values' => ['X1' => '0.61', 'X2' => '0.54', 'X3' => '0.49', 'X4' => '0.51'], 'cluster' => 2, 'distance' => 0.119],
                ['id' => 'RESP-006', 'values' => ['X1' => '0.18', 'X2' => '0.71', 'X3' => '0.66', 'X4' => '0.35'], 'cluster' => 1, 'distance' => 0.241],
                ['id' => 'RESP-007', 'values' => ['X1' => '0.92', 'X2' => '0.14', 'X3' => '0.22', 'X4' => '0.88'], 'cluster' => 3, 'distance' => 0.135],
                ['id' => 'RESP-008', 'values' => ['X1' => '0.47', 'X2' => '0.52', 'X3' => '0.55', 'X4' => '0.44'], 'cluster' => 2, 'distance' => 0.098],
                ['id' => 'RESP-009', 'values' => ['X1' => '0.79', 'X2' => '0.27', 'X3' => '0.24', 'X4' => '0.76'], 'cluster' => 3, 'distance' => 0.214],
                ['id' => 'RESP-010', 'values' => ['X1' => '0.34', 'X2' => '0.69', 'X3' => '0.61', 'X4' => '0.39'], 'cluster' => 1, 'distance' => 0.176],
            ],
        ];

        return view('dashboard', $data);
    }
}
